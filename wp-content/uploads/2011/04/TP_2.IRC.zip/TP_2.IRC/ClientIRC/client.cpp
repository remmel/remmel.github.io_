#include "client.hpp"


#define CAPACITE_FILE_ATTENTE 10
#define STDIN 0 /* Descripteur de fichier pour entrée standard */ 

Client::Client(const uint16_t numPort, char *url):socket(numPort,url),
         ecran(),ensCanal(ecran.getNbLigne()-2,ecran.getNbColonne()-15)
{
	ecran.affIntro();
	erase();
	refresh();
	ecran.affInterface();
	refresh();
	noecho();//empeche affichage des caractere saisi
}

void aff(list<string> lmsg)
{
	cout<<"liste Message  ";
	list<string>::iterator iptr;
	for(iptr=lmsg.begin(); iptr!=lmsg.end();iptr++)
		cout<<*iptr<<"  ";
}

void Client::execClient()
{	   	   
	int ValRetSelect,type; 
 	struct timeval tv;
	
	tv.tv_sec = 1;
   	tv.tv_usec = 0;
	
	FD_ZERO(&ensFileDescriptorLecture);  /*initialise l'ensemble des files descriptor à surveiller en lecture à 0*/
		
	/*on ajoute le file descriptor de la socket de communication à l"ensemble des descripteurs à surveiller en lecture*/	
	FD_SET(socket.getNumSocket(), &ensFileDescriptorLecture);	
	FD_SET(STDIN, &ensFileDescriptorLecture);
		
	/* n est le numéro du plus grand descripteur des 3 ensembles, plus 1.*/
	/*select modifie les ensembles et laisse dans les ensembles les files descriptor */
	/*ayant des donnees en attente de traitement*/
	/*FD_SETSIZE est une constante*/
	/*timeout = NULL : absence de limite de temps*/
	
	if (ValRetSelect)
	{	
		ValRetSelect = select(FD_SETSIZE, &ensFileDescriptorLecture, NULL, NULL, NULL); 					
			/*Test si il y a des données en attente de lecture sur cette socket*/
			if(FD_ISSET(socket.getNumSocket(), &ensFileDescriptorLecture)) 
			{
				    Message msg;
					msg.reseauVersMessage(socket.lectureSocket());
					
					type=msg.getType();
					switch(type)
					{
					    case texte        : { 
												ensCanal.ajouteLigneBuffer(msg.getNomCanal(),msg.getContenu()); 
												if( msg.getNomCanal() == ecran.getOngletActif() )
													ecran.affZoneMessage(ensCanal);
											} break; 
											
   						case lUtilisateur : { 
												if(!ensCanal.existeCanal(msg.getNomCanal() ))
												{	
													ensCanal.ajouteCanal(msg.getNomCanal() );
													ecran.setOngletActif( msg.getNomCanal() );												
												}
												ensCanal.majListeUtilisateurs(msg.getNomCanal(),msg.getContenu() );
												if(ecran.getOngletActif() == msg.getNomCanal() )
													ecran.affListeUtilisateurs(ensCanal);
											} break;
											
						case lCanaux      : { 
												ecran.affListeCanaux(ensCanal,msg.getContenu());
											} break;
					}
			}	
			if(FD_ISSET(STDIN, &ensFileDescriptorLecture)) 	/*Test si il y a des données en attente dans stdin*/
				ecran.scrutationClavier(socket,ensCanal);
		}
}
