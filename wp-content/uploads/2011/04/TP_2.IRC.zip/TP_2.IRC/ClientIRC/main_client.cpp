#include <iostream>
#include <exception>
#include <string>
#include "socket.hpp"
#include "affichage.hpp"
#include "client.hpp"
#include "exception.hpp"


using namespace std;


#define ENTER 10 

int main(int argc, char *argv[])
{ 
  int numPort;
  char *url;
  
  try{ /*test des arguments*/
    if(argc != 3) throw ExceptionArgument();
    if(sscanf(argv[2],"%d",&numPort)!=1) throw ExceptionPasUnNombre(argv[2]);
    url=argv[1];
  }
  catch(Exception &e){  cerr << endl<<e.quoi()<<endl<<endl; exit(0);}
	
	

  try
    {
      Client client(numPort,url);
      while(1)
	{
	  client.execClient();
	}
    }
  catch(Exception e){ std::cerr << e.quoi(); }
  catch(...){ cerr << "Erreur de nature inconnue"; }
  return 0;
}
