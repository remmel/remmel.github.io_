#ifndef AFFICHAGE_HPP
#define AFFICHAGE_HPP

#include <stdlib.h>
#include <ncurses.h>
#include <iostream>
#include <exception>
#include <string>
#include <list>

#include "socket.hpp"
#include "message.hpp"
#include "canal.hpp"

/************************/
/*Gestion des Exceptions*/
/************************/
class ExceptionGestionCouleur:public Exception
{
	public:
		ExceptionGestionCouleur(){message+="Les couleurs ne sont pas supportées.\n";}
		~ExceptionGestionCouleur() throw(){}
};

using namespace std;

enum fenetreActive { fenetreMenu, fenetreBarreSaisi};

/** 
* @short La classe Affichage permet de gérer l'affichage et la saisi de 
* caractere au clavier
* Les attributs contiennent toutes les caractéristiques de l'affichage
**/
class Affichage
{
	private:
		int x;
		int nbLigne;
		int nbColonne;
		int numOnglet;
		int nbOnglet;
		string ongletActif;
		string chaineSaisi;
		int fenetreActive;
		map<int,string> listeOnglet;
		WINDOW ** popupCanaux;
		WINDOW ** menu;
		WINDOW * barreMenu;
		WINDOW * barreSaisi;
		WINDOW * barreListePseudo;
		WINDOW * zoneMessage;
		WINDOW * barreOnglets;
	
	public:
		/**
		* Affichage() est le constructeur de la classe affichage
		* Il initialise l'ecran
		* active la gestion du clavier
		* définit les paires de couleurs
		* alloue la memoire pour le menu
		*/
		Affichage();
		
		/**
		* ~Affichage() est le destructeur de la classe affichage
		* libere la memoire allouée pour le menu
		*/
		~Affichage();
	
		/**
		* affMenu() affiche le menu suite à l'appui sur F1
		* Affiche: lister les canaux
		* Affiche: sortir du canal
		* Affiche: quitter
		*/
		void affMenu();
		
		/**
		* affInterface() affiche les différentes sous fenetres de l'interface 
		* et leur eventuelle contenu de départ
		* Définit les paires de couleurs utilisés pour chaque sous-fenetre
		* Crée une sous fenetre par ligne a afficher
		*/		
		void affInterface();
		
		/**
		* affIntro() affiche un ecran au demarrage du programme
		* Cet ecran comporte TUX!!!! ainsi que les noms des auteurs et le nom du programme
		* Cet ecran est temporisée de 3 secondes
		*/
		void affIntro();
		
		/**
		* effaceMenu() efface le menu a la suite d'un deuxieme appui sur F1
		* Supprime proprement les sousFenetre du menu
		*/
		void effaceMenu();
		
		/** deplacementMenu(...) permet de se déplacer dans le menu
		* Un appui sur entrée permet de lancer le traitement associer à la ligne 
		* @param *fenetreActive est un pointeur sur le numero de la fenetre active  
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connectés
		* @param &socket est une reference vers la socket vers laquelle on aura eventuellement à envoyer un message
		*/
		void deplacementMenu(EnsCanal &ensCanal,int *fenetreActive,Socket &socket);
		
		/** scrutationClavier(...) permet de surveiller les touches saisis 
		* Suivant la fenetre active et la touche pressée,un traitement est lancé
		* @param &socket est une reference vers la socket vers laquelle on aura eventuellement à envoyer un message
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		*/
		void scrutationClavier(Socket &socket,EnsCanal &ensCanal);
		
		/** ongletPrecedent(...) permet de changer l'onglet actif pour le precedent
		* On teste si on n'essai pas d'aller dans un onglet qui n'existe pas!
		* On affiche toutes zones propres a cet onglet
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		*/
		void ongletPrecedent(EnsCanal &ensCanal);
		
		/** ongletSuivant(...) permet de changer l'onglet actif pour le suivant
		* On teste si on n'essai pas d'aller dans 9eme onglet car on peut se 
		* connecter qu'a 8 canaux max!
		* On affiche toutes zones propres a cet onglet
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		*/
		void ongletSuivant(EnsCanal &ensCanal);
		
		/** saisi(...) permet de gérer l'entrée de caractere dans barreSaisi
		* Par defaut, l'appui sur une touche affiche le caractere dans la barre 
		* de saisi et l'ajoute a une variable
		* L'appui sur entrée lance une analyse de la chaine puis un traitement 
		* L'appui sur retour efface le dernier caractere saisi
		* @param &touchePresse est une reference vers le code ASCII de la derniere touche pressée
		* @param &socket est une reference vers la socket vers laquelle on aura eventuellement à envoyer un message
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		*/		
		void saisi(const int &touchePresse,Socket &socket,EnsCanal &ensCanal);
		
		/** affBarreOnglet() affiche ou reaffiche la barre d'onglets
		* Affiche le canal actif
		* Affiche le numero de l'onglet courant et le nombre total d'onglets
		*/
		void affBarreOnglet(void);
		
		/** affZoneMessage(...) affiche les derniers messages du canal actif
		*Affiche le contenu du buffer du canal actif dans ZoneMessage
		* On decale de une ligne vers bas pour chaque nouveau message
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		*/
		void affZoneMessage(EnsCanal &ensCanal);	
		
		/** affListeUtilisateurs(...) affiche la liste des pseudos present 
		* sur le canal actif
		* On decale de une ligne vers bas pour chaque nouveau pseudo
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		*/
		void affListeUtilisateurs(EnsCanal &ensCanal);
		
		/** affListeCanaux(...) affiche la liste des canaux du serveur
		* Genere une popup 
		* On affiche chaque canal sur une ligne de la popup
		* La popup reste 5 seconde le temp de consulter et disparait
		* @param lcanaux est une chaine contenant la liste des canaux du serveur
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		*/
		void affListeCanaux(EnsCanal &ensCanal,const string lCanaux);
		
		/** analyseChaine(...) analyse une chaine et renvoi un booléen
		* Analyse si la chaine saisi est une commande(/quit,/exit,/join)
		* Si oui lance un traitement adéquate et retourne 0
		* Sinon retourne 0
		* @param chaineSaisi est la chaine saisi pa l'utilisateur et validé par entrée
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		* @param &socket est une reference vers la socket vers laquelle on aura eventuellement à envoyer un message
		* @return booleen correspondant a si une commande recherchée a été trouvée
		*/
		int analyseChaine(string chaineSaisi,EnsCanal &ensCanal,Socket &socket);
		
		
		/** quitterProgramme(...) permet de quitter proprement le programme
		* envoi /quit au serveur
		* Termine l'affichage graphique en ncurses
		* @param &socket est une reference vers la socket vers laquelle on aura eventuellement à envoyer un message
		*/
		void quitterProgramme(Socket &socket);
		
		/** quitterCanal(...) permet de quitter canal coté client/coté serveur
		* Verifie si on essaie pas de quitter l'onglet origine qui 
		* n'est pas un reelement un canal 
		* Envoi /exit au serveur avec le nom du canal
		* Supprime le canal de l'ensemble de canaux du client
		* Decremente le nombre d'onglets
		* Reaffiche la barre d'onglet
		* @param &ensCanal est une reference sur l'ensemble des canaux auquels le client est connecté
		* @param &socket est une reference vers la socket vers laquelle on aura eventuellement à envoyer un message
		*/
		void quitterCanal(EnsCanal &ensCanal,Socket &socket);
		
		/** getNbLigne(...) retourne le nombre de ligne de la fenetre
		* Accede a une atribut privé de la classe affichage
		* @return nombre de lignes de la fenetre
		*/
		int getNbLigne(){return nbLigne;}
		
		/** getNbColonne(...) retourne le nombre de colonne de la fenetre
		* Accede a une atribut privé de la classe affichage
		* @return nombre de colonne de la fenetre
		*/
		int getNbColonne(){ return nbColonne; }
		
		/** getFenetreActive(...) retourne le numero associé a la fenetre active
		* Accede a une atribut privé de la classe affichage
		* @return numero de la fenetre active
		*/
		int getFenetreActive(){return fenetreActive;}
		
		/** getNbOnglet(...) retourne le nombre d'onglet total
		* Accede a une atribut privé de la classe affichage
		* @return nombre d'onglets
		*/
		int getNbOnglet() {return nbOnglet;}
		
		/** getOngletActif(...) retourne le nom de l'onglet actif
		* Accede a une atribut privé de la classe affichage
		* @return nom de l'onglet actif
		*/
		string getOngletActif(){return ongletActif.c_str();}
		
		/** setFenetreActive(...) définit la fenetre active actuellement
		* Affecte l'entier correspondant passé en parametre
		*/
		void setFenetreActive(int numFenetre){fenetreActive=numFenetre;}
		
		/** setOngletActif(...) définit la fenetre active actuellement
		* Affecte ongletactif avec la chaine passé en parametre
		*Incremente le nombre d'onglets
		*Rafraichit la barre d'onglet
		*/
		void setOngletActif(const string Onglet);
};

#endif
