#ifndef MESSAGE_HPP
#define MESSAGE_HPP

#include <list>
#include <set>
#include <string>
#include <iostream>
using namespace std;

 /**
 * Cette enumeration permet de savoir de quelle type est le message
 */
 enum typMessage {
	 texte=1,
	 lUtilisateur,
	 lCanaux,
 };
 
 /**
 * La classe Message permet de gerer le message qui transite entre 
 * le serveur et le client et vice-verca.
 */
 class Message{
	 
	 	string nomCanal;
	 	typMessage type;
	 	string contenu;
	 public:
		 
	 	string premier(string ch);
		string reste(string ch);
		
		
			
		 /**
 		 * Construit le message
 		 * @param nomCanal nom du canal sur lequel le message va etre envoye
	 	 * @param typMessage type de message qui va etre envoye
	 	 * @param cont contenu du message qui va etre envoye
 		 */
		 Message(string nomcanal,typMessage ty,string cont);
	 
	 	 /**
 		 * Construit un message sans nom de canal, parametre et contenu.
	 	 * On remplira ce message par la suite avec la fonction: 'remplirMessage(...)'
	 	 * ou reseauVersMessage(...)
	 	 */
		 Message();
	 
	     // a supprimer ulterierement
		 Message(string chaine);
		 
		 /**
 		 * permet de s'affranchir du remplissage au moment de la creation du message
	 	 */			 
		 void remplirMessage(string nomcanal,typMessage ty,string cont);

		string getContenu();
		
		string getNomCanal();
		
		 /**
 		 * transforme le message en fichier envoyable par le reseau
	 	 */		 
	 	string messageVersReseau();
		
		 /**
 		 * transforme le fichier recu par le reseau en message
	 	 */		
		void reseauVersMessage(string ch);

		 /**
 		 * donne le type du message
	 	 */	
		typMessage getType();
		
		 /**
 		 * extrait la commande taper par l'utilisateur (attention le contenu doi
		 * etre du texte)
	 	 */
		 string extraitCmde();
		 
		 /**
 		 * extrait l'argument qu'a tape l'utilisateur apres sa commande
		 * (attention le contenu doi etre du texte)
	 	 */
		string extraitArg();
			
		 /**
 		 * pour les tests, permet d'afficher un message a l'ecran du serveur
	 	 */		
		friend ostream& operator<<(ostream &os, const Message &message){
			os<<"______________________________________________"<<endl;
			os<<"Nom du Canal: "<<message.nomCanal<<endl;
			os<<"Type: "<<message.type<<endl;
			os<<"Contenu: "<<message.contenu<<endl;
			os<<"______________________________________________"<<endl;
			return os;
		};
		

 };
 


#endif
