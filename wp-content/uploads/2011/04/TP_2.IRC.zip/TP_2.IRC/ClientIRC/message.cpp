 #include "message.hpp"
  
 

	 	string Message::premier(string ch){
			string ret="";
			for(unsigned i=0;i<ch.length();i++){
			    if(ch[i]!=' ') ret+=ch[i]; //a modifier
			    else return ret;
		      }
		      return ret; 
			}
		string Message::reste(string ch){
			string ret="";
			unsigned i=0;
			for(i=0;i<ch.length() && ch[i]!=' ';i++); //a modifier
				
			for(i=i+1;i<ch.length();i++)
				ret+=ch[i];				

			return ret;
		}
		
		
			
		
		 Message::Message(string nomcanal,typMessage ty,string cont):nomCanal(nomcanal),type(ty),contenu(cont){};
		 Message::Message():nomCanal(""),type(texte),contenu(""){};
		 //a supprimer ulterierement
		 Message::Message(string chaine){
			 nomCanal=premier(chaine);
			 contenu=reste(chaine);
		 }
			 
		 void Message::remplirMessage(string nomcanal,typMessage ty,string cont){
			 nomCanal=nomcanal;
			 type=ty;
			 contenu=cont;
		 }

		string Message::getContenu(){
			return contenu;
		}
		
		string Message::getNomCanal(){
			return nomCanal;
		}		
		 
	 	string Message::messageVersReseau(){
		 	string txt=nomCanal;
			txt+='\n';
			txt+=type;
			txt+='\n';
			txt+=contenu;
			return txt;
	 	}
		
		void Message::reseauVersMessage(string ch){
			unsigned i=0;
			while(ch[i]!='\n'){
				nomCanal+=ch[i];
				i++;
			}
		
			i+=1;
			type=(typMessage)ch[i];
			for(i=i+2;i<ch.length();i++)
			   contenu+=ch[i];
		}
		
		typMessage Message::getType(){
			return type;
		}
		
		 string Message::extraitCmde(){ //delimitateur entre message est le caractère espace
		      string ret="";
		      for(unsigned i=0;i<contenu.length();i++){
			    if(contenu[i]!=' ') ret+=contenu[i];
			    else return ret;
		      }
		      return ret; 
			}
	
		string Message::extraitArg(){
				string ret="";
				unsigned i=0;
		        if(contenu.length()==0) return ret; //la commande doit avoir au moins 1 car
		 
			   while(contenu[i]!=' '){ //on va jusqu'au premier espace
				   i++;
				   if(i==contenu.length()) return ret=""; //on est arrive a la fin du message sans trouver l'argument
				}
				
		       while(contenu[i]!=' '){ //pour enlever tous les espaces avant l'argument (exple: #iut    bonjour)
					i++;
					if(i==contenu.length()) return ret=""; //on est arrive a la fin du message sans trouver l'argument
				}
				
				for(i=i+1;i<contenu.length();i++) ret+=contenu[i]; //on retourne tout les caractères a partir de la position du dernier espace de la suite d'espace +1
				return ret;
			}
