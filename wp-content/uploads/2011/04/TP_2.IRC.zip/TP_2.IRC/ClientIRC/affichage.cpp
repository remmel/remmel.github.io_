#include "affichage.hpp"

#define ESCAPE 27
#define ENTER 10 
#define BACKSPACE 263

string suppr_dernier(string &ch)
{
  string aux="";
  int longu=ch.length();
  if(longu) for (int i=0; i<(longu-1); i++) aux+=ch[i];
  return aux;
}

Affichage::Affichage(void)
{
  ongletActif="";
  chaineSaisi="";
  x=1;
  nbOnglet=0;
  numOnglet=0;
	
  initscr(); /*initialisation de l'ecran*/
  curs_set(0); /*rend le curseur invisible*/
  keypad(stdscr,TRUE);/*On active la gestion du clavier*/
  /*on recupere le nombre de ligne et de colonne de l'ecran*/
  getmaxyx(stdscr,nbLigne,nbColonne);
  if(has_colors() == FALSE)
    throw ExceptionGestionCouleur();
  start_color(); /*Gestion de la couleur*/
  /*On définit le fond d'ecran comme étant noir et la police blanche*/
  init_pair(1,COLOR_WHITE,COLOR_BLACK); 
  init_pair(2,COLOR_BLUE,COLOR_WHITE);
  init_pair(3,COLOR_RED,COLOR_WHITE);
  init_pair(4,COLOR_BLUE,COLOR_YELLOW);
  init_pair(5,COLOR_BLACK,COLOR_WHITE);
  init_pair(6,COLOR_BLACK,COLOR_BLUE);
  /*On alloue la memoire pour le menu*/
  menu=(WINDOW **)malloc(4*sizeof(WINDOW *));
}

Affichage::~Affichage()
{
  free(menu);	
}

void Affichage::affIntro(void)
{	
  /*Affichage de l'ecran d'introduction*/
  mvprintw(0,nbColonne-45,"Realisé par: Nestelhut Damien et Remy Mellet");
	
  mvprintw(nbLigne-18,0,"          ..-''''-.");
  mvprintw(nbLigne-17,0,"         //      `\\");
  mvprintw(nbLigne-16,0,"         |,.  ,-.  |             #####  #      ###   ###### ##     # ######");
  mvprintw(nbLigne-15,0,"         |()L( ()| |            ##      #       #   #       # #    #   #   ");
  mvprintw(nbLigne-14,0,"         |,'  `'.| |           ##       #       #   #       #  #   #   #   ");
  mvprintw(nbLigne-13,0,"         |.___.',| '           ##       #       #   #####   #   #  #   #   ");
  mvprintw(nbLigne-12,0,"       .j `--'' `  `.          ##       #       #   #       #    # #   #   ");
  mvprintw(nbLigne-11,0,"      / /         `  \\          ##      #       #   #       #     ##   #   ");
  mvprintw(nbLigne-10,0,"     / /          `   `.         #####  ###### ###   ###### #      #   #   ");
  mvprintw(nbLigne-9,0,"    / /            `    .                                       ");
  mvprintw(nbLigne-8,0,"   / /              l   |                #####   #####     #####");
  mvprintw(nbLigne-7,0,"  . ,               |   |                  #     #    #   ##    ");
  mvprintw(nbLigne-6,0,"  ,||`.            .|   |                  #     #    #  ##     ");
  mvprintw(nbLigne-5,0," _.'   ``.   o     | `..-'l                #     #####   ##     ");
  mvprintw(nbLigne-4,0,"|       `.`,        |      `.              #     #   #   ##     ");
  mvprintw(nbLigne-3,0,"|         `.    __.j         )             #     #    #   ##    ");          
  mvprintw(nbLigne-2,0,"|__        |----___|      ,-''           #####   #     #   #####");
  mvprintw(nbLigne-1,0,"  `---...,+        `._,.-'' ");
  refresh(); /*Rafraichissement*/	
  sleep(3);
}

void Affichage::affInterface(void)
{	
  /*On créer une sous-fenetre pour chaque zone*/
  barreMenu=subwin(stdscr,1,10,0,0); 
  barreOnglets=subwin(stdscr,1,nbColonne-10,0,10);
  barreSaisi=subwin(stdscr,1,nbColonne,nbLigne-1,0);
  barreListePseudo=subwin(stdscr,nbLigne-2,15,1,nbColonne-15);	
  zoneMessage=subwin(stdscr,nbLigne-2,nbColonne-15,1,0);
	
  /*affichage de la barre de menu*/
  wbkgd(barreMenu,COLOR_PAIR(5));/*définit la paire par defaut*/
  waddstr(barreMenu,"Menu(F1)");/*ajoute du texte dans la sous fenetre*/
  wrefresh(barreMenu);/*rafrachit uniquement la sous fenetre*/	
	
  /*affichage de la barre de saisi*/
  wbkgd(barreSaisi,COLOR_PAIR(3));
  wrefresh(barreSaisi);
	
  /*affichage de la zone pour la liste des pseudo*/
  wbkgd(barreListePseudo,COLOR_PAIR(4));
  wrefresh(barreListePseudo);
	
  /*affichage de la zone d'affichage des messages*/
  wbkgd(zoneMessage,COLOR_PAIR(1));
  waddstr(zoneMessage,"Saisissez votre pseudo.");
  wmove(zoneMessage,2,0);
  waddstr(zoneMessage,"Ensuite connectez-vous à un canal avec: /join #nomCanal");
  wmove(zoneMessage,4,0);
  waddstr(zoneMessage,"/list : liste tous les canaux du serveur");
  wmove(zoneMessage,5,0);
  waddstr(zoneMessage,"/exit : quitte un canal");
  wmove(zoneMessage,6,0);
  waddstr(zoneMessage,"/topic : change le topic");
  wmove(zoneMessage,7,0);
  waddstr(zoneMessage,"/quit : quitte le programme");
  wmove(zoneMessage,9,0);
  waddstr(zoneMessage,"La touche F3 permet de basculer sur le canal precedent");
  wmove(zoneMessage,10,0);
  waddstr(zoneMessage,"La touche F4 permet de basculer sur le canal suivant");
	
  /*affichage de la barre d'onglets*/
  wbkgd(barreOnglets,COLOR_PAIR(2));
  wrefresh(barreOnglets);
  wrefresh(zoneMessage);
}

void Affichage::affMenu(void) 
{
  wbkgd(barreMenu,COLOR_PAIR(2));
  wrefresh(barreMenu);	
  menu[0]=newwin(10,19,1,0);/*Creation d'une nouvelle fenetre;*/
  wbkgd(menu[0],COLOR_PAIR(5));
  box(menu[0],ACS_VLINE,ACS_HLINE);
  menu[1]=subwin(menu[0],1,17,2,1);
  menu[2]=subwin(menu[0],1,17,3,1);
  menu[3]=subwin(menu[0],1,17,4,1);

  /*affichage des lignes du menu*/
  wprintw(menu[1],"Liste canaux");
  wprintw(menu[2],"Sortir canal");
  wprintw(menu[3],"Quitter");
  wrefresh(menu[0]);
}

void Affichage::effaceMenu(void)
{
  wbkgd(barreMenu,COLOR_PAIR(5));
  wrefresh(barreMenu);
  delwin(menu[0]);
  delwin(menu[1]);
  delwin(menu[2]);
  delwin(menu[3]);
	
  //Etant donné que l'appel de newwin precedent(utilisation de pointeurs) 
  //n'a pas modifié stdscr,refresh ne rafraichissant que les caractères ayant 
  //changé,il faut appeler touchwin pour forcer le rafraichissement de tout 
  //les caractères de stdscr
  touchwin(stdscr);
  refresh();
}


void Affichage::quitterProgramme( Socket &socket) /*Ferme le programme*/
{
  Message msg("",texte,"/quit");
  socket.ecritureSocket(msg.messageVersReseau());
  endwin();
  exit(0);
}

void Affichage::quitterCanal( EnsCanal &ensCanal, Socket &socket)
{
  string saveOngletActif=ongletActif;
  if(! (ongletActif == "") )
    {
      //en quittant un canal on se deplace a l'onglet precedent sauf si:
      //onglet precedent est longlet origine et si il ya des canaux aprés longlet actif
      if( ensCanal.nomCanalPrecedent(ongletActif) == "" )
	{
	  if(numOnglet == nbOnglet)
	    ongletPrecedent(ensCanal);
	  else
	    ongletSuivant(ensCanal);
	}	
      else
	ongletPrecedent(ensCanal);
		
      Message msg(saveOngletActif,texte,"/exit");
      socket.ecritureSocket(msg.messageVersReseau());
      ensCanal.supprimeCanal(saveOngletActif);
      nbOnglet--;
      affBarreOnglet();
		
    }
  else
    {
      ensCanal.ajouteLigneBuffer("","Vous ne pouvez faire /exit qu'à l'interieur d'un canal.");
      affZoneMessage(ensCanal);
    }
}

void Affichage::deplacementMenu(EnsCanal &ensCanal ,int * fenetreActive,Socket &socket)
{
  int touchePressee,lignecourante=1;
  wbkgd(menu[lignecourante],COLOR_PAIR(2));
  wrefresh(menu[lignecourante]);
	
  while(*fenetreActive == fenetreMenu)
    {
      touchePressee=getch();
      if(touchePressee == KEY_F(1))
	{	
	  *fenetreActive=fenetreBarreSaisi;
	  effaceMenu();
	}
      else
	{//On surligne la ligne active
	  if( (touchePressee == KEY_DOWN) && lignecourante < 3)
	    {
	      wbkgd(menu[lignecourante],COLOR_PAIR(5));
	      wrefresh(menu[lignecourante]);
	      lignecourante++;
	      wbkgd(menu[lignecourante],COLOR_PAIR(2));
	      wrefresh(menu[lignecourante]);
				
	    }	
	  else
	    {	
	      if( (touchePressee == KEY_UP) && lignecourante > 1)
		{
		  wbkgd(menu[lignecourante],COLOR_PAIR(5));
		  wrefresh(menu[lignecourante]);
		  lignecourante--;
		  wbkgd(menu[lignecourante],COLOR_PAIR(2));
		  wrefresh(menu[lignecourante]);

		}
	      else
		{
		  if(touchePressee == ENTER)
		    {
		      *fenetreActive=fenetreBarreSaisi;
		      effaceMenu();
		      switch(lignecourante)
			{
			case 1 : {
			  Message msg("",texte,"/list");
			  socket.ecritureSocket(msg.messageVersReseau());
			  effaceMenu();
			}break;
			case 2 : {
			  quitterCanal(ensCanal,socket);
			  effaceMenu();
			}break;
			case 3 : {
			  quitterProgramme(socket);
			  effaceMenu();
			  break;
			}
			}
		    }
		}
	    }
	}
    }
}

void Affichage::scrutationClavier(Socket &socket,EnsCanal &ensCanal)
{
  int touchePressee,fenetreActive=fenetreBarreSaisi;
  /*getch() retourne le code de la touche tapée au clavier si c'est le cas*/
  touchePressee=getch();
  if(touchePressee==KEY_F(1))
    {
      fenetreActive=fenetreMenu;
      affMenu();
    }
  else
    {
      if(touchePressee==KEY_F(3))
	ongletPrecedent(ensCanal);	
      else
	{
	  if(touchePressee==KEY_F(4))
	    ongletSuivant(ensCanal);
	}
    }
		
  if(fenetreActive==fenetreMenu)
    deplacementMenu(ensCanal,&fenetreActive,socket);
  else
    {
      if(fenetreActive==fenetreBarreSaisi && !(touchePressee==KEY_F(4) ||touchePressee==KEY_F(3)))
	saisi(touchePressee,socket,ensCanal);
    }

}

void Affichage::ongletPrecedent(EnsCanal &ensCanal)
{
  if(numOnglet>0)
    {
      numOnglet--;
      ongletActif=ensCanal.nomCanalPrecedent(ongletActif);
      affZoneMessage(ensCanal );
      affListeUtilisateurs(ensCanal);
      affBarreOnglet();
    }
}

void Affichage::ongletSuivant(EnsCanal &ensCanal)
{
  if(numOnglet<nbOnglet)
    {
      numOnglet++;
      ongletActif=ensCanal.nomCanalSuivant(ongletActif);
      affZoneMessage(ensCanal );
      affListeUtilisateurs(ensCanal);			
      affBarreOnglet();
    }				
}

void Affichage::saisi(const int &touchePressee,Socket &socket,EnsCanal &ensCanal)
{
	
  char carac[2];

  if(touchePressee == ENTER)
    {
      werase(barreSaisi);
      wrefresh(barreSaisi);
		
      //Si on ne trouve pas de commande speciale on envoi au serveur le msg
      if( analyseChaine(chaineSaisi,ensCanal,socket) )
	{
	  Message msg(ongletActif,texte,chaineSaisi);
	  socket.ecritureSocket( msg.messageVersReseau() );
	}			
      chaineSaisi="";
      x=0;
    }
  else
    {	
      if(touchePressee == BACKSPACE)
	{
	  x--;
	  wmove(barreSaisi,0,x);
	  wdelch(barreSaisi);
		
	  wrefresh(barreSaisi);
	  chaineSaisi=suppr_dernier(chaineSaisi);
	}
      else
	{	
	  carac[0]=touchePressee;
	  carac[1]='\0';
	  x++;
	  wprintw(barreSaisi, carac);
	  wrefresh(barreSaisi);
	  chaineSaisi+=*carac;
			
	}	
    }
}


int Affichage::analyseChaine(string chaineSaisi,EnsCanal &ensCanal,Socket &socket)
{
  if(chaineSaisi == "/exit" )
    {quitterCanal(ensCanal,socket);return 0;}
  else
    {
      if(chaineSaisi == "/quit")
	{quitterProgramme(socket);return 0;}
      else
	{
	  //on cherche /join dans la chaine a partir de l'indice 0(le debut)
	  //string::npos retourner si pas trouver 
	  //sinon retourne indice de position de la sous chaine
	  string::size_type loc=chaineSaisi.find("/join",0);
	  if( loc != string::npos )
	    {
	      if(nbOnglet >= 8)
		{
		  ensCanal.ajouteLigneBuffer("","Impossible de rejoindre plus de 8 canaux");
		  if(getOngletActif() == "")
		    affZoneMessage(ensCanal);
		  return 0;
		}
	    }
	}			
    }
  return 1;
}

void Affichage::affZoneMessage(EnsCanal &ensCanal)
{
  int i=0;
	
  werase(zoneMessage);
  wmove(zoneMessage,0,0);
  list<string> lmsg=ensCanal.getListeMessage(ongletActif);
  list<string>::iterator iptr;
	
  for(iptr=lmsg.begin(); iptr!=lmsg.end();iptr++)
    {
      wprintw(zoneMessage, iptr->c_str() );
      wmove(zoneMessage,i+1,0);
      i++;
    }
  wrefresh(zoneMessage);	
}
   				
void Affichage::affListeUtilisateurs(EnsCanal &ensCanal)
{
  wmove(zoneMessage,0,0);
  werase(barreListePseudo);
  string lNom= ensCanal.getListeUtilisateurs(ongletActif);
  string ch="";
  int ligne=0;
  for(unsigned i=0;i<lNom.length();i++)
    {
      if(lNom[i]=='\n')
	{
	  wprintw(barreListePseudo,ch.c_str()  );
	  ch="";
	  ligne++; //affiche un nom toutes les lignes
	  wmove(barreListePseudo,ligne-1,0);
	}
      else
	ch+=lNom[i];
    }
  wprintw(barreListePseudo,ch.c_str()  ); //affiche le dernier nom
  wrefresh(barreListePseudo);	
}

void Affichage::affListeCanaux(EnsCanal &ensCanal,const string lCanaux)
{
  int y=(nbLigne/2)-5;
  int x=(nbColonne/2)-10;
  int nbAff=7;

  int nbCanaux=0;
  
  /*popupCanaux=(WINDOW **)malloc(10*sizeof(WINDOW *));
    popupCanaux[0]=newwin(11,19,y,x);//Creation de la popup
    wbkgd(popupCanaux[0],COLOR_PAIR(2));
    box(popupCanaux[0],ACS_VLINE,ACS_HLINE);
	
    //Affichage limitée à 8 canaux(a faire evoluer avec un scrolling)
    //Les deux derniers coordonnés sont par rapport au coin de la fenetre
    popupCanaux[1]=subwin(popupCanaux[0],1,17,y+1,x+1);
    popupCanaux[2]=subwin(popupCanaux[0],1,17,y+2,x+1);
    popupCanaux[3]=subwin(popupCanaux[0],1,17,y+3,x+1);
    popupCanaux[4]=subwin(popupCanaux[0],1,17,y+4,x+1);
    popupCanaux[5]=subwin(popupCanaux[0],1,17,y+5,x+1);
    popupCanaux[6]=subwin(popupCanaux[0],1,17,y+6,x+1);
    popupCanaux[7]=subwin(popupCanaux[0],1,17,y+7,x+1);
    popupCanaux[8]=subwin(popupCanaux[0],1,17,y+8,x+1);
    popupCanaux[9]=subwin(popupCanaux[0],1,17,y+9,x+1);
    string ch="";
    int ligne=1;
    wprintw(popupCanaux[ligne],"Liste des canaux:");
    ligne++;
	
    for(unsigned i=0;i<lCanaux.length();i++)
    {
    if(lCanaux[i]=='\n')
    {
    wprintw(popupCanaux[ligne],ch.c_str());
    ch="";
    ligne++; 
    }
    else
    ch+=lCanaux[i];
    }
	
    wrefresh(popupCanaux[0]);
    sleep(5);//La popup reste afficher 5 secondes
    delwin(popupCanaux[0]);
    for(int j=0;j<=ligne;j++)
    {delwin(popupCanaux[j]);}
    free(popupCanaux);*/
  for(unsigned i=0;i<lCanaux.length();i++)
    if(lCanaux[i]=='\n') nbCanaux++;
  
  //debut scooling
  WINDOW *m=newwin(11,19,y,x);
  wbkgd(m,COLOR_PAIR(2));
  box(m,ACS_VLINE,ACS_HLINE);
  // Sans ce truc, la fenêtre ne scrolle pas!
  scrollok(m,TRUE);
  string intro="liste des canaux:\n";
  //lCanaux=intro+lCanaux;
  wprintw(m,lCanaux.c_str());
  wrefresh(m);
  for (int cpt=nbAff;cpt<nbCanaux;cpt++)
    {
      getch();
      scroll(m);
      wrefresh(m);
    }
  getch();

  // Toujours faire le ménage
  delwin(m);
  endwin();
  //Etant donné que l'appel de newwin precedent(utilisation de pointeurs) 
  //n'a pas modifié stdscr,refresh ne rafraichissant que les caractères ayant 
  //changé,il faut appeler touchwin pour forcer le rafraichissement de tout 
  //les caractères de stdscr
  touchwin(stdscr);
  refresh();

}

void Affichage::setOngletActif(const string Onglet)
{
  ongletActif=Onglet;
  nbOnglet++;
  numOnglet=nbOnglet;
  affBarreOnglet();
}

void Affichage::affBarreOnglet(void)
{
  werase(barreOnglets);
  //affiche le nom et le numero de longlet actif et le nombre d'onglets totaux
  wprintw(barreOnglets, "\t Onglet %d/%d \t\t Canal actif:",numOnglet,nbOnglet);
  wprintw(barreOnglets, ongletActif.c_str() );
  wrefresh(barreOnglets);
}
