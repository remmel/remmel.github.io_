#include "canal.hpp"
#include <ncurses.h>

/***************************************/
/*FONCTIONS RELATIVES A LA CLASSE CANAL*/
/***************************************/

Canal::Canal(int nbLigne, int nbCol):listeUtilisateurs(""){
  nvRemplissageBuffer=0;
  ligneBuffer=nbLigne;
  colBuffer=nbCol;
};   
	  
string Canal::getUtilisateur(){
  return listeUtilisateurs;
}
	
list<string> Canal::getListeMessage(){
  return lMessage;
}
	
int Canal::getNiveauDeRemplissage(){
  return nvRemplissageBuffer;
}
	
void Canal::ajouteLigneBuffer(const string &texte)
{
  lMessage.push_back(texte);
  if(nvRemplissageBuffer>(ligneBuffer-2)){ //le buffer est plein
    lMessage.erase(lMessage.begin());
  }
  else //buffer non plein
    nvRemplissageBuffer++;
}
	
void Canal::majListeUtilisateurs(const string &contenu){
  listeUtilisateurs=contenu;
}

/*******************************************/
/*FONCTIONS RELATIVES A LA CLASSE ENS_CANAL*/
/*******************************************/  
EnsCanal::EnsCanal(int ligneBuf, int colBuf){
  ligneBuffer=ligneBuf;
  colBuffer=colBuf;
  ajouteCanal(""); //canal de depart
			
  string ch="";
  map<string,Canal*>::iterator i;
  for(i=listeCanal.begin(); i!=listeCanal.end();++i)
    ch+=(i->first);
}
   
bool EnsCanal::existeCanal(const string &nomCanal)
{
  map<string,Canal*>::iterator i;
  for(i=listeCanal.begin(); i!=listeCanal.end();++i)
    if((i->first)==nomCanal) return true;
  return false;  
}
		
void EnsCanal::ajouteCanal(const string &nomCanal)
{   
  listeCanal[nomCanal]=new Canal(ligneBuffer,colBuffer);
}
		
void EnsCanal::supprimeCanal(const string &nomCanal)
{
  map<string,Canal*>::iterator i;
  for(i=listeCanal.begin(); i!=listeCanal.end();++i)
    {
      if((i->first) == nomCanal && (i->first) != "")
	{delete (i->second);listeCanal.erase(i);}
    }
}
		
void EnsCanal::ajouteLigneBuffer(const string &nomCanal, string texte)
{
  int longueur=texte.length();
  int i=0;
  while(i*colBuffer<longueur)
    {
      string ligne=string(texte,i*colBuffer,colBuffer+colBuffer*i);
      listeCanal[nomCanal]->ajouteLigneBuffer(ligne);
      i++;
    }
}
		
void EnsCanal::majListeUtilisateurs(const string &nomCanal,const string &lUtili ){
  //if(!existeCanal(nomCanal)) A enlevé testé en double dans le select
  //	ajouteCanal(nomCanal,);
  listeCanal[nomCanal]->majListeUtilisateurs(lUtili);
}
				
string EnsCanal::getListeUtilisateurs(const string &nomCanal){
  return listeCanal[nomCanal]->getUtilisateur();
}
		
list<string> EnsCanal::getListeMessage(const string &nomCanal){
  return listeCanal[nomCanal]->getListeMessage();
}
		
int EnsCanal::getNiveauDeRemplissage(const string &nomCanal){
  return listeCanal[nomCanal]->getNiveauDeRemplissage();
}
		
string EnsCanal::nomCanalSuivant(const string &nomCanal){
  if(listeCanal.empty()) return "";

  map<string,Canal*>::iterator i=listeCanal.begin();
  map<string,Canal*>::iterator isuiv;
  while(i!=listeCanal.end() && i->first!=nomCanal) //va au canal ayant le nom nomCanal ou a la fin de la liste
    ++i;
  if(i->first==nomCanal){
    i++;
    isuiv=i;
    if(isuiv!=listeCanal.end())
      return isuiv->first; //retourne le nom du canal suivant dans la liste
  }
			
  return (listeCanal.begin())->first; //retourne le nom du premier canal de la liste
}
		
string EnsCanal::nomCanalPrecedent(const string &nomCanal){
  if(listeCanal.empty()) return "";
				
  map<string,Canal*>::iterator i=listeCanal.begin();
  map<string,Canal*>::iterator iprec=listeCanal.begin();
			
  while(i!=listeCanal.end() && i->first!=nomCanal){ //va au canal ayant le nom nomCanal ou a la fin de la liste
    iprec=i;
    ++i;
  }
			
  if(i->first==nomCanal){
    return iprec->first; //retourne le nom du canal precedent dans la liste
  }
			
  return iprec->first; //retourne le nom du dernier canal de la liste
}
