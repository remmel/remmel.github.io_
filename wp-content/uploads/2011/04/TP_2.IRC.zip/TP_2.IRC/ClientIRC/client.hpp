#ifndef CLIENT_HPP
#define CLIENT_HPP

#include <list>
#include <iostream>
#include <iterator>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <string>

#include "socket.hpp"
#include "affichage.hpp"
#include "canal.hpp"

using namespace std;
/** @short La classe Client est la fonction principale du programme
* Elle possede toutes autres classes et effectue un select pour surveiller l'ensemble des file descriptor
*/
class Client
{
	private:
		char *url;
		uint16_t numPort;
		Affichage ecran;
		EnsCanal ensCanal;
		Socket socket;

	public:
		fd_set ensFileDescriptorLecture; /*ensemble de file descriptor à surveiller en lecture*/	
	
	/** Client(...) est le constructeur de la classe client
	* Affiche l'ecran d'intro
	* Affiche l'interface graphique en ncurses
	* Empeche l'affichage systématique des caracteres tapés
	*@param num_port est le numero du port sur lequel la socket se connecte au serveur
	*@param *url est un pointeur sur l'ip ou le nom de l'hote du serveur
	*/
	Client(const uint16_t num_port,char *url);
	
	/** execClient(...) est une methode permettant de surveiller le socket et stdin
	* Si on recoit un message sur la socket, un traitement spécifique est exécuté selon le type de fichier
	* Si des données sont en attente sur stdin, on appel la methode scrutationClavier(...)
	*/
	void execClient();
};
#endif
