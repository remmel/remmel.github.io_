#ifndef CANAL_HPP
#define CANAL_HPP

#include <string>
#include <iostream>
#include <map>
#include <list>
#include <string>

using namespace std;


class Canal{
	
private:
  int ligneBuffer;
  int colBuffer;
  string listeUtilisateurs;
  int nvRemplissageBuffer; //pas necessaire
  list<string> lMessage;
   
public:
  /**
   * Constructeur du canal
   * @param nbLigne nombre de ligne du buffer des message
   * @param nbCol nombre de caractere d'une ligne du buffer des message
   */
  Canal(int nbLigne, int nbCol);

  /**
   * Renvoie la liste des clients du canal sous forme de string
   * @return string
   */
  string getUtilisateur();

  /**
   * Renvoie la liste des messages du canal sous forme de list
   * @return list<string>
   */
  list<string> getListeMessage();

  
  int getNiveauDeRemplissage();

  /**
   * Permet d'ajouter une nouvelle ligne au buffer de la liste des messages
   * @param texte de type string
   */
  void ajouteLigneBuffer(const string &texte);

  /**
   * Permet de mettre a jour la liste des utilisateurs
   * @param contenu de type string etant la nouvelle liste des utilisateurs
   */
  void majListeUtilisateurs(const string &contenu);
};


class EnsCanal
{
  int ligneBuffer;
  int colBuffer;
public: map<string,Canal*> listeCanal;
	
public:
  /**
   * Constructeur de l'ensemble des canaux
   * @param ligneBuf nombre de ligne du buffer des message
   * @param colBuf nombre de caractere d'une ligne du buffer des message
   */
  EnsCanal(int ligneBuf, int colBuf);
	
  /**
   * Permet d'ajouter un canal a l'ensemble de canal
   * @param nomCanal de type string
   */
  void ajouteCanal(const string &nomCanal);

  /**
   * Teste si un canal existe
   * @param nomCanal de type string
   */
  bool existeCanal(const string &nomCanal);

  /**
   * supprime un canal
   * @param nomCanal de type string
   */
  void supprimeCanal(const string &nomCanal);

  /**
   * Ajoute d'un message a la liste des messages d'un canal
   * @param nomCanal de type string
   * @param texte de type string
   */
  void ajouteLigneBuffer(const string &nomCanal,string texte);

  /**
   * Permet de mettre a jour la liste des utilisateurs d'un canal
   * @param contenu de type string etant la nouvelle liste des utilisateurs
   */
  void majListeUtilisateurs(const string &nomCanal,const string &lUtili );	
  /**
   * Renvoie la liste des utilisateurs d'un canal sous forme de string
   * @return string
   */	
  string getListeUtilisateurs(const string &nomCanal);

  /**
   * Renvoie la liste des messages d'un canal sous forme de list
   * @return list<string>
   */
  list<string> getListeMessage(const string &nomCanal);

  int getNiveauDeRemplissage(const string &nomCanal);

  /**
   * Retourne le nom du canal suivant d'un canal donne en argument
   * si il y en a un, sinon retourne le nom du canal lui-meme
   * Le canal retourné est le canal join juste avant le canal donné en argument
   * @param nomCanal de depart
   * @return nomCanal d'arrivée
   */
  string nomCanalSuivant(const string &nomCanal);
  /**
   * Retourne le nom du canal precedant d'un canal donne en argument
   * si il y en a un, sinon retourne le nom du canal lui-meme
   * Le canal retourné est le canal join juste apres le canal donné en argument
   * @param nomCanal de depart
   * @return nomCanal d'arrivée
   */
  string nomCanalPrecedent(const string &nomCanal);

};
   
#endif
