#ifndef SOCKET_HPP
#define SOCKET_HPP

#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include <netinet/in.h>
#include <iostream>
#include <exception>
#include <string>

#include <ncurses.h>

#include "exception.hpp"

using namespace std;

/*********************/
/*GESTION DES ERREURS*/
/*********************/


/**
 * classe ExceptionSocket: classe heritant de la classe exception permet
 * de gerer toutes les erreurs due aux sockets du programme
 */

class ExceptionSocket: public Exception
{
	public:
		ExceptionSocket(){message+="de socket: "; }
		~ExceptionSocket() throw(){}
};
	
/**
 * classe ExceptionNew: classe heritant de la classe ExceptionSocket permet
 * de gerer l'erreur due a la creation d'une nouvelle socket
 */
class ExceptionNew:public ExceptionSocket
{
	public:
		ExceptionNew(){ message +="impossible de créer la nouvelle socket\n"; }
		~ExceptionNew() throw(){}
};

/**
 * classe ExceptionEcriture: classe heritant de la classe ExceptionSocket permet
 * de gerer toutes les erreurs lie a la l'ecriture dans une socket de communication
 */
class ExceptionEcriture:public ExceptionSocket
{
	public:
		ExceptionEcriture() {message +="impossible d'ecrire sur la socket\n"; }
		~ExceptionEcriture() throw(){}
};

/**
 * classe ExceptionLecture: classe heritant de la classe ExceptionSocket permet
 * de gerer toutes les erreurs lie a la lecture d'une socket de communication
 */
class ExceptionLecture:public ExceptionSocket
{
	public:
		ExceptionLecture(){ message+="impossible de lire dans la socket\n";}
		~ExceptionLecture() throw(){}
};


/**
 * classe ExceptionConnecter: classe heritant de la classe ExceptionSocket permet
 * de gerer toutes les erreurs lie a la connexion d'une socket de communication
 */
class ExceptionConnecter:public ExceptionSocket
{
	public:
		ExceptionConnecter(){ message+="impossible de connecter la socket\n";}
		~ExceptionConnecter() throw(){}
};



/**
 * classe ExceptionFermer: classe heritant de la classe ExceptionSocket permet
 * de gerer l'erreur lie a la fermeture d'une socket
 */
class ExceptionFermer:public ExceptionSocket
{
	public:
		ExceptionFermer() {message+="impossible de fermer la socket\n";}
		~ExceptionFermer() throw(){}
};

/**
 * classe ExceptionHoteInconnu: classe heritant de la classe ExceptionSocket permet
 * de gerer l'erreur lie au fait que le nom de l'hote est inconnu
 */
class ExceptionHoteInconnu:public ExceptionSocket
{
	public:
		ExceptionHoteInconnu(){ message +="impossible de trouver l'hote\n"; }
		~ExceptionHoteInconnu() throw(){}
};

	
	
class Socket
{
private:
  struct sockaddr_in inisock;
  int numSocket;
  
public:

  /**
   * Constructeur d'une socket
   * @param num_port est un entier indiquant le numero du port
   * @param url est un char* et contient l'url du serveur
   */
  Socket(uint16_t num_port, char *url);

  ~Socket();
  
  /**
   * retourne le file descriptor de cette socket
   * @return fd de type int
   */
  int getNumSocket();

  /**
   * Permet d'ecrire une donnee sur une socket
   * @param chaint de type string etant la donnee a envoyer
   */
  void ecritureSocket(string chaine);
  
  /**
   * Permet de lire des donnees sur une socket
   * @return returne la chaine lu de type string
   */
  string lectureSocket();
};

#endif
