
#include "socket.hpp"

Socket::Socket(uint16_t num_port, char *url)
{
  printf("cree le socket de communication");
  if((numSocket=socket(PF_INET,SOCK_STREAM,0))==-1) throw ExceptionNew();
	
  inisock.sin_family = AF_INET;  /* remplie la structure qui sera liée au socket*/
  inisock.sin_port=htons(num_port);
		
  struct hostent *hostinfo;
  if( (hostinfo = gethostbyname (url)) ==NULL) throw ExceptionHoteInconnu();
  inisock.sin_addr = *(struct in_addr *) hostinfo->h_addr; /* Le dernier champs de la structure est garni */
		   
  if( connect(numSocket, (struct sockaddr*) &inisock, sizeof(inisock)) == -1)
    throw ExceptionConnecter();
}
	
Socket::~Socket()
{
  printf("ferme le socket de communication\n");
  if(close(numSocket)==-1) 
    throw ExceptionFermer();
}
	 
	
int Socket::getNumSocket(){
  return numSocket;
}
	  
string Socket::lectureSocket()
{
  char buf[512]; //version avec reception de message limite
  int tailleLu;
  if((tailleLu=read(numSocket, buf, 512))<0) throw ExceptionLecture();
  buf[tailleLu]=0;
  return buf;
}
	
	
	
void Socket::ecritureSocket(string chaine)
{
  int taille=chaine.length();
  if(write(numSocket, chaine.c_str(), taille ) != taille )
    throw ExceptionEcriture();
}
