#include "message.hpp"
  
 

string Message::premier(string ch){
  string ret="";
  for(unsigned i=0;i<ch.length();i++){
    if(ch[i]!=' ') ret+=ch[i]; //a modifier
    else return ret;
  }
  return ret; 
}
string Message::reste(string ch){
  string ret="";
  unsigned i=0;
  for(i=0;i<ch.length() && ch[i]!=' ';i++); //a modifier
				
  for(i=i+1;i<ch.length();i++)
    ret+=ch[i];				

  return ret;
}
		
		
			
		
Message::Message(string nomcanal,typMessage ty,string cont):nomCanal(nomcanal),
             type(ty),contenu(cont){};
Message::Message():nomCanal(""),type(texte),contenu(""){};
			 
void Message::remplirMessage(string nomcanal,typMessage ty,string cont){
  nomCanal=nomcanal;
  type=ty;
  contenu=cont;
}

string Message::getContenu(){
  return contenu;
}
		
string Message::getNomCanal(){
  return nomCanal;
}		
		 
string Message::messageVersReseau(){
  string txt=nomCanal;
  txt+='\n';
  txt+=(char)type;
  txt+='\n';
  txt+=contenu;
  //txt+='\0';
  return txt;
}
		
void Message::reseauVersMessage(string ch){
  unsigned i=0;
  while(ch[i]!='\n' && i!=ch.length()){
    nomCanal+=ch[i];
    i++;
  }
			
  if(i+2<ch.length()) ExceptionMessage();
		
  i+=1;
  type=(typMessage)ch[i];
  for(i=i+2;i<ch.length();i++)
    contenu+=ch[i];
}
		
typMessage Message::getType(){
  return type;
}

/*delimitateur entre message est le caractère espace*/
string Message::extraitCmde(){ 
  string ret="";
  for(unsigned i=0;i<contenu.length();i++){
    if(contenu[i]!=' ') ret+=contenu[i];
    else return ret;
  }
  return ret; 
}
	
string Message::extraitArg(){
  string ret="";
  unsigned i=0;
	
  /*la commande doit avoir au moins 1 car*/
  if(contenu.length()==0) return ret;
	
  /*on va jusqu'au premier espace*/
  while(contenu[i]!=' '){
    i++;
	  
	/*on est arrive a la fin du message sans trouver l'argument*/
    if(i==contenu.length()) return ret=""; 
  }
  
  /*pour enlever tous les espaces avant l'argument (exple: #iut    bonjour)*/	
  while(contenu[i]!=' '){ 
    i++;
	  
	/*on est arrive a la fin du message sans trouver l'argument*/
    if(i==contenu.length()) return ret=""; 
  }
	
  /* on retourne tout les caractères a partir de la position du dernier
   * espace de la suite d'espace +1 */  
  for(i=i+1;i<contenu.length();i++) ret+=contenu[i];
  return ret;
}
