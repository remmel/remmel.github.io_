#ifndef CANAL_HPP
#define CANAL_HPP

#include <list>
#include <string>
#include <set>
#include <map>
#include "imgClient.hpp"
using namespace std;

/**
 * La classe Canal permet de gérer un canal, c'est a dire d'ajouter/supprimer
 * un utilisateur, de changer un topic, d'envoyer un message a tous les
 * utilisateurs du canal, de lister tous les utilisateurs de ce canal...
 */
class Canal{
  string nomCanal; /*redondance d'info. Mais facilite la tache*/
  string topicCanal;
  unsigned nbClient;
  set<ptr_ImgClient> lClientNormal;
  set<ptr_ImgClient> lClientOperateur;
   
public:



  /** 
   * Constructeur du canal
   * @param nomCanal de type string
   * @param ptr_Clt de type ptr_ImgClient indiquant le client operateur de ce
   * canal
   */
  Canal(const string &canal,ptr_ImgClient ptr_Clt);
   
  /**
   * Permet d'avoir le topic du canal
   * @return topic de type string
   */
  string getTopic(void);

  /**
   * Permet d'avoir le nombre de client du canal
   * @return nbClient de type unsigned
   */ 
  unsigned nombreClient(void);
   
  /**
   * Permet de modifier le topic du canal
   * @param topic de type string
   */
  void setTopic(const string &ch);
   
  /**
   * Permet de savoir si un client est connecte au canal
   * @param ptr_Clt
   */
  bool existeClient(ptr_ImgClient ptr_Clt);
   
  /**
   * Permet de savoir si un client est operateur du canal
   * @param ptr_Clt
   */
  bool clientOperateur(ptr_ImgClient ptr_Clt);

  /**
   * Permet de savoir si un client est n'operateur du canal
   * @param ptr_Clt
   */
  bool clientNormal(ptr_ImgClient ptr_Clt);	
   
  /**
   * Permet d'ajouter un client au canal
   * @param ptr_Clt
   * @param operateur indique si il sera operateur de ce canal
   */
  void ajouteClient(ptr_ImgClient ptr_Clt,const bool &operateur);

  /**
   * Permet de supprimer un client au canal
   * @param ptr_Clt
   */
  void supprimeClient(ptr_ImgClient ptr_Clt);
  
  /**
   * Retourne la liste des clients du canal
   * @return lUtili de type string
   */
  string listerUtilisateur();

  /**
   * Envoie un message a tous les clients du canal
   * @param msg de type Message
   */
  void envoieMessageMultiple(const Message &msg);
   
};

typedef Canal *ptr_Canal;

/**
 * La classe EnsCanal permet de gérer un ensemble de canaux (dans notre
 * programme IRC, tous les canaux du serveur). Pour cela, il peut supprimer
 * un utilisateur de l'ensemble de canaux, ajouter un utilisateur a un canal,
 * modifier un topic d'un canal, lister tous les canaux...
 * @short Classe gerant plusieurs canaux
 */
class EnsCanal{
  map<string,Canal*> lCanal;
	
public:
  
  /**
   * Permet de modifier le topic d'un canal
   * @param ptr_Clt
   */						
  void setTopic(const string &nomCanal);
  
  /**
   * Permet d'avoir le topic d'un canal
   * @param nomCanal
   */ 
  string getTopic(const string &nomCanal);

  /**
   * Permet de supprimer un client de tous les canaux
   * @param ptr_Clt
   */
  void supprimeClient(ptr_ImgClient ptr_Clt);

  /**
   * Permet de supprimer un client d'un canal   
   * @param nomCanal
   * @param ptr_Clt
   */
  void supprimeClientCanal(const string &nomCanal,ptr_ImgClient ptr_Clt);

  /**
   * Permet d'ajouter un client au canal
   * @param nomCanal
   * @param ptr_Clt
   * @param operateur indique si il sera operateur de ce canal
   */
  void ajouteClient(const string &nomCanal,ptr_ImgClient ptr_Clt,bool op);

  /**
   * Permet de savoir si un client est operateur d'un canal
   * @param nomCanal
   * @param ptr_Clt
   */
  bool clientOperateur(const string &nomCanal,ptr_ImgClient ptr_Clt);
	
  /**
   * Fait les actions liee a la commande topic
   * @param nomCanal
   * @param ptr_Clt
   * @param txtTopic
   */
  void cmdeTopic(const string &nomCanal, ptr_ImgClient ptr_Clt, const string &txttopic);

  /**
   * Fait les actions liee a la commande Join
   * @param nomCanal
   * @param ptr_Clt
   */
  void cmdeJoin(const string &nomCanal, ptr_ImgClient ptr_Clt);

  /**
   * Fait les actions liee a la commande List
   * @param nomCanal
   * @param ptr_Clt
   */
  void cmdeList(const string &nomCanal, ptr_ImgClient ptr_Clt);

  /**
   * Fait les actions liee a une commande non connu
   * @param nomCanal
   * @param ptr_Clt
   */
  void cmdeInconnu(const string &nomCanal, ptr_ImgClient ptr_Clt);

  /**
   * Envoie un message a tous les clients du canal
   * @param nomCanal
   * @param msg de type Message
   */		
  void envoieMessageMultipleTxt(const string &nomCanal,string txt);

  /**
   * Ajoute un canal a la liste des canaux
   * @param nomCanal
   * @param ptr_Clt
   */
  void ajouteCanal(const string &nomCanal,ptr_ImgClient ptr_Clt);

  /**
   * Teste si un canal existe
   * @param nomCanal
   * @return bool
   */
  bool existeCanal(const string &nomCanal);

  /**
   * Retroune la liste des canaux
   * @return string
   */
  string listerCanal();

  /**
   * Supprime un canal a la liste des canaux
   * @param nomCanal
   */
  void supprimeCanal(const string &nomCanal);

	
  ~EnsCanal();
		
		
};
   
#endif
