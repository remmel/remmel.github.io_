#ifndef IMGCLIENT_HPP
#define IMGCLIENT_HPP

#include <string>
#include "socketCom.hpp"
#include "socket.hpp"
#include <map>
#include <set>
#include <list>
#include "message.hpp"

class ExceptionClientInexistant: public Exception{
public:
  ExceptionClientInexistant(){message+=": Impossible de trouver le client"; }
  ~ExceptionClientInexistant() throw(){}
};


/**
 * classe ImgClient: permet de gerer un utilisateur. Cette classe possede
 * le pseudo de l'utilisateur et connait (pointeur) son socket
 * Cette classe permet aussi d'envoyer un message au client concerne
 * @short Classe gerant un client
 */	
class ImgClient{
	
  SocketCom *Sock;
  string Pseudo;

public:
  /**
   * Constructeur d'une image client
   * @param SocketCom* pointeur sur socket de communication
   */
  ImgClient(SocketCom *ptrS);

  /**
   * Permet de modifier le pseudo d'un client
   * @param ch qui est de type string
   */
  void SetPseudo(const string &ch);

  /**
   * Permet d'avoir le pseudo d'un client
   * @return nom de type string
   */
  string GetPseudo();

  /**
   * Permet d'avoir un pointeur sur la socket d'un client
   * @return ptrSocketCom de type SocketCom*
   */
  SocketCom* GetPtrSocket();

  /**
   * Permet d'envoyer un message (deja construit) a un client
   * @param message de type Message
   */
  void envoieMessage(const Message &msg);

  /**
   * Permet d'envoyer un message texte a un client
   * @param nomcanal de type string
   * @param mess de type string etant le texte a envoyer
   */
  void envoieMessageTxt(const string &nomcanal,const string &mess);
};

typedef ImgClient *ptr_ImgClient;





/**
 * classe EnsImgClient: permet de gerer tous les utilisateur connecte au
 * serveur. Cette classe permet d'ajouter supprimer et rechercher un utilisateur
 * @short Classe gerant un ensemble de clients
 */	
class EnsImgClient{
private:
  list<ImgClient> lClient;
		
public:
	
  /**
   * permet d'ajouter un client au serveur
   * @param ptr_Sock de type SocketComs
   */
  void ajouteClient(SocketCom* ptr_Sock);
	
  /**
   * permet de supprimer un client du serveur
   * @param nom du client a supprimer
   */
  void supprimeClient(string nom);

  /**
   * recherche un client sur le serveur de par son file descriptor
   * @param fd file descriptor du client rechercher
   * @return ImgClient* pointeur sur le client
   */  
  ImgClient* rechercherClient(int fd);

  /**
   * recherche un client sur le serveur de par son nom
   * @param nom du client rechercher
   * @return ImgClient* pointeur sur le client
   */  
  ImgClient* rechercherClient(string nom);
	
	
};


#endif
