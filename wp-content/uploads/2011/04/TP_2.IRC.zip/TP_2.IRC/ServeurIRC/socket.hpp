#ifndef SOCKET_HPP
#define SOCKET_HPP

#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <exception>
#include <string>
#include "exception.hpp"
using namespace std;

/************************/
/*GESTION DES EXCEPTIONS*/
/************************/


/**
 * classe ExceptionSocket: classe heritant de la classe exception permet
 * de gerer toutes les erreurs due aux sockets du programme
 */		
class ExceptionSocket: public Exception{
public:
  ExceptionSocket(){message+="de socket: "; }
  ~ExceptionSocket() throw(){}
};

/**
 * classe ExceptionNew: classe heritant de la classe ExceptionSocket permet
 * de gerer l'erreur due a la creation d'une nouvelle socket
 */	
class ExceptionNew:public ExceptionSocket{
public:
  ExceptionNew(){ message +="impossible de créer la nouvelle socket\n"; }
  ~ExceptionNew() throw(){}
};

/**
 * classe ExceptionClose: classe heritant de la classe ExceptionSocket permet
 * de gerer l'erreur lie a la fermeture d'une socket
 */	
class ExceptionClose : public ExceptionSocket{
public:
  ExceptionClose() { message +="Impossible de fermer la socket."; }
  ~ExceptionClose() throw() {}		
};


/**
 * classe Socket: socket generaliste non utilisable tel quelle
 */	
class Socket{
protected:
  struct sockaddr_in inisock;
  int numSocket;
		
public:	
  /**
   * retourne le file descriptor de cette socket
   * @return fd de type int
   */	
  int getNumSocket();
	
  Socket();	
  ~Socket(); 

};

#endif
