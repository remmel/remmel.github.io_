#include <iostream>
#include "socket.hpp"
#include "socketService.hpp"
#include "socketCom.hpp"
#include "serveur.hpp"
#include <exception>
#include <string>
#include "message.hpp"

using namespace std;


int main(int argc,char * argv[])
{
  int numPort;

  try{ /*test des arguments*/
    if(argc != 2) throw ExceptionArgument();
    if(sscanf(argv[1],"%d",&numPort)!=1) throw ExceptionPasUnNombre(argv[1]);
  }
  catch(Exception &e){  cerr << e.quoi()<<endl; exit(0); }
	
  try
    {
      Serveur serveur(numPort);
      cout<<"ServeurIRC"<<endl;
      cout<<"Realise par Remy Mellet et Damien Nestelhut"<<endl;
      cout<<"Lancement du serveur... "<< endl;
      while(!serveur.finServeur()){
	serveur.execSelect();
      }
    }
  catch(Exception &e){ cerr << e.quoi()<<endl; }
  catch(...){ cerr << "Erreur de nature inconnue"<<endl; }
	
	
  return 0;
}
