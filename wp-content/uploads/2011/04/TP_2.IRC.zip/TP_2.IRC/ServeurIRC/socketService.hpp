#ifndef SOCKETSERV_HPP
#define SOCKETSERV_HPP

#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <exception>
#include <string>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include "socket.hpp"
#include "exception.hpp"

using namespace std;

/**
 * classe SocketCom: classe heritant de la classe Socket.
 * elle permet de gerer la socket de service
 */	
class SocketService : public Socket
{
public:

  /**
   * Constructeur de la socket de communication
   * @param numPort numero du port sur lequel on veut communiquer
   */
  SocketService(uint16_t numPort); 

  /**
   * Permet d'accepter une communication
   * @return numSocket le numero de la socket
   */
  int Accept();

  /**
   * Attend une connexion sur la socket
   * @param n longueur de la file d'attente
   */
  void Listen(int n);
	 
};

/************************/
/*GESTION DES EXCEPTIONS*/
/************************/


/**
 * classe ExceptionBind: classe heritant de la classe ExceptionSocket permet
 * de gerer l'erreur liee au parametrage de la socket de service
 */	
class ExceptionBind : public ExceptionSocket
{
public:
  ExceptionBind(){ message+="Impossible de lier la structure au socket\n";}
  ~ExceptionBind() throw(){}
};

/**
 * classe ExceptionCretionSocket: classe heritant de la classe ExceptionSocket
 * permet de gerer l'erreur liee a la creation d'une socket
 */	
class ExceptionCreationSocket:public ExceptionSocket
{
public:
  ExceptionCreationSocket(){message+="Impossible de créer la socket.\n";}
  ~ExceptionCreationSocket() throw(){}
};

/**
 * classe ExceptionAccept: classe heritant de la classe ExceptionSocket permet
 * de gerer l'erreur liee au refu de connexion d'une socket
 */	
class ExceptionAccept:public ExceptionSocket
{
public:
  ExceptionAccept(){ message +="Connexion refusée sur la socket\n"; }
  ~ExceptionAccept() throw(){}
};

/**
 * classe ExceptionCretionSocket: classe heritant de la classe ExceptionSocket
 * permet de gerer l'erreur liee a l'impossibilite d'ecouter la socket
 */	
class ExceptionListen:public ExceptionSocket{
public:
  ExceptionListen(){ message +="impossible d'ecouter sur le port spécifier\n"; }
  ~ExceptionListen() throw(){}
};

#endif
