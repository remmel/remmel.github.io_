#ifndef EXCEPTION_HPP
#define EXCEPTION_HPP

#include <iostream>
#include <string>
using namespace std;


/**
 * classe Exception: classe generaliste permettant de gerer toutes les
 * exceptions du programme
 * le nom de l'erreur ainsi que le texte associe a cette erreur est
 * memorise dans la chaine 'message'
 */	
class Exception{
protected:
  /**
   * message contient le message associe a l'erreur
   */
  string message;
public:
	
  /**
   * Constucteur de l'exception.
   * Initialistion du message d'erreur a "Erreur"
   */
  Exception(): message("Erreur "){}
	  
  /**
   * Cette méthode virtuelle renvoie le message lié a l'erreur
   * @return le message de l'erreur de type string
   */
  virtual string quoi() const { return message; }
  
  virtual ~Exception() throw(){}
};


 /**
 * classe ExceptionPasUnNombre: classe heritant de la classe exception permet
 * de gerer l'erreur lié au fait que l'utilisateur entre une chaine de
 * caractere plutot qu'un nombre
 */		
class ExceptionPasUnNombre: public Exception{
public:
  ExceptionPasUnNombre(char* ch){
    message+="d'argument, ";
    message+=ch;
    message+=" n'est pas un nombre";
  }
  ~ExceptionPasUnNombre() throw(){}
};

 /**
 * classe ExceptionArgument: classe heritant de la classe exception permet
 * de gerer l'erreur lié au fait que l'utilisateur n'entre pas le bon
 * nombre d'arguments
 */	
class ExceptionArgument: public Exception{
public:
   ExceptionArgument(){
	   message+=": mauvais argument\nUSAGE: ServeurIRC <Numero du Port>";
   }
  ~ExceptionArgument() throw(){}
};

#endif
