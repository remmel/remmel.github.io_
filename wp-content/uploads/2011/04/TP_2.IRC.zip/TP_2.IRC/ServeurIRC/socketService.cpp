#include "socketService.hpp"

using namespace std;

SocketService::SocketService(uint16_t numPort):Socket()
{ 
  printf("Service\n");
  if((numSocket=socket(PF_INET,SOCK_STREAM,0))==-1)
    throw ExceptionCreationSocket();
  
  /* remplie la structure qui sera liée au socket*/
  inisock.sin_family = AF_INET;  
  inisock.sin_port=htons(numPort);
  inisock.sin_addr.s_addr=htonl(INADDR_ANY);
  
  /*initialise le socket (lie la structure au socket)*/
  if(bind(numSocket,(struct sockaddr*)&inisock,sizeof(inisock))==-1) 
    throw ExceptionBind();
}
	  
int SocketService::Accept()
{
  int numSocketService;
  socklen_t length_ptr=sizeof(struct sockaddr);
  numSocketService=accept(numSocket,(struct sockaddr*)&inisock,&length_ptr);
  if(numSocketService == -1)
    throw ExceptionAccept();
  return numSocketService;
}
   
void SocketService::Listen(int n) 
{
  if(listen(numSocket,n) == -1)
    throw ExceptionListen();
}
