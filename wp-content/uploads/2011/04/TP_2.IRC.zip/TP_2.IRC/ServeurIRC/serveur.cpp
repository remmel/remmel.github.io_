#include "serveur.hpp"


using namespace std;

#define CAPACITE_FILE_ATTENTE 10

Serveur::Serveur(uint16_t numPort):socketService(numPort),fin(false){
	
  /*Declaration des variables */
  tv.tv_sec = 20;
  tv.tv_usec = 0;
	
}

void Serveur::execSelect(){
  int ValRetSelect; 
  string messageLu;
  SocketCom *sockNvClient;
  list<SocketCom>::iterator it;/*liste d'objet ou liste de pointeurs*/
	
  /*initialise l'ensemble des files descriptor à surveiller en lecture à 0*/
  FD_ZERO(&ensFileDescriptorLecture);
  /*initialise l'ensemble des files descriptor à surveiller en ecriture à 0*/
  FD_ZERO(&ensFileDescriptorEcriture);
	
  /*ajout du fd à l"ensemble des descripteurs à surveiller en lecture*/	
  FD_SET(socketService.getNumSocket(), &ensFileDescriptorLecture);
		
  for(it=listePointeurSocketCom.begin();it != listePointeurSocketCom.end();++it)
    { 
	  /*ajoute un file descriptor à l'ensemble des fileDescriptor à surveiller en lecture*/
      FD_SET(it->getNumSocket(), &ensFileDescriptorLecture);
	  /*ajoute un file descriptor à l'ensemble des fileDescriptor à surveiller en ecriture*/		
      FD_SET(it->getNumSocket(), &ensFileDescriptorEcriture);
	}	

  /*timeout = NULL : absence de limite de temps*/
  ValRetSelect = select(FD_SETSIZE, &ensFileDescriptorLecture, &ensFileDescriptorEcriture, NULL, &tv); 
  if (ValRetSelect)
    {
      if(FD_ISSET(socketService.getNumSocket(),&ensFileDescriptorLecture))
	{
	  /*File d'attente de connexion */
	  socketService.Listen(CAPACITE_FILE_ATTENTE);
	  /*connexion acceptée+Creation d'une socket de communication */
	  sockNvClient=ajouterSocketCom(socketService.Accept() );
	  lesClients.ajouteClient(sockNvClient);
	}
	  /*Parcours de la liste de pointeurs avec un iterateur */
      for(it=listePointeurSocketCom.begin();it != listePointeurSocketCom.end();++it) 
	{
      /*Test si il y a des données en attente d'écriture sur cette socket*/		
	  if(FD_ISSET(it->getNumSocket(), &ensFileDescriptorEcriture)) 
	    { 
	      //printf("traitement ecriture socket \n");
	      
	    }

	  /*Test si il y a des données en attente de lecture sur cette socket*/		
	  if(FD_ISSET(it->getNumSocket(), &ensFileDescriptorLecture)){
	    string ch="";
	    ch=(it->lectureSocket());
	    Message mess;
	    mess.reseauVersMessage(ch);
	    evalueMessage(mess,it->getNumSocket());
		
		/*un client veut se deconnecter-> supprimer le fd*/		  
	    if(mess.getContenu()=="/quit"){
	      FD_CLR(it->getNumSocket(), &ensFileDescriptorLecture);
	      listePointeurSocketCom.erase(it);
	      it=listePointeurSocketCom.end();
	    }
					
					
	  }

	}
    }
}


SocketCom* Serveur::ajouterSocketCom(int numSocketCom)
{
  /*Creation d'une socket de communication(appel constructeur)*/
  SocketCom *ptr_socketCom = new SocketCom(numSocketCom);
  if(ptr_socketCom == NULL)
    throw ExceptionNew();
  /*ajout du pointeur sur la socket dans la liste*/
  listePointeurSocketCom.push_front(*ptr_socketCom);
  return ptr_socketCom;
}




void Serveur::evalueMessage(Message &leMsgduClient, int fd){
				
  /*recupere un pointeur sur le client*/
  ImgClient* ptrClt=lesClients.rechercherClient(fd);
	
  if(!ptrClt){ /*le client n'existe pas*/
    cout<<"impossible, fd client inconnu!"<<endl;
    return;
  }
  else
    cout<<"le client "<<ptrClt->GetPseudo()<<" a envoye la cmde: ";
    cout<<leMsgduClient.getContenu()<<" au canal "<<leMsgduClient.getNomCanal()<<endl;
  	   
    if(ptrClt->GetPseudo()==""){
	/*le client vient de se connecter, il na pas encore envoyé son pseudo*/
    cout<<"Modification du pseudo"<<endl;
    if( leMsgduClient.getContenu()=="") {
		ptrClt->envoieMessageTxt("","pseudo sans lettre");  return; 
	}
    if( lesClients.rechercherClient(leMsgduClient.getContenu())!=NULL ){
	  /*pseudo existant*/
      cout<<"nom "<<leMsgduClient.getContenu()<<"deja existant"<<endl;
      ptrClt->envoieMessageTxt("","erreur, pseudo deja existant");
    }
    else{ /*pseudo non existant*/
      ptrClt->SetPseudo(leMsgduClient.getContenu());
      ptrClt->envoieMessageTxt("","vous etes connecte au serveur");
    }
    return;
  }
			
			
  /*traitement du message crée par le systeme client*/
			
  bool sansCanal=(!lesCanaux.existeCanal(leMsgduClient.getNomCanal()));
  if(sansCanal && leMsgduClient.getNomCanal().length()){
    ptrClt->envoieMessageTxt(leMsgduClient.getNomCanal(),"erreur, le canal "+leMsgduClient.getNomCanal()+" n'existe pas!");
    cout<<"canal inexistant"<<endl;
  }
  /*traitement du message tapé par l'utilisateur*/
  string cmde=leMsgduClient.extraitCmde();
  string arg=leMsgduClient.extraitArg();
  cout<<"commande: "<<cmde<<" argument: "<<arg<<" fin "<<endl;
		
  if(cmde[0]=='/'){
	
    cout<<"commande"<<endl;	  
    if(cmde=="/join" && arg.length()>=2 && arg[0]=='#'){
      lesCanaux.cmdeJoin(arg,ptrClt);
      return;
    }
    if(leMsgduClient.getContenu()=="/exit" && !sansCanal){ /*sort d'un canal*/
      lesCanaux.supprimeClientCanal(leMsgduClient.getNomCanal(),ptrClt);
      return;
    }
		   
    if(leMsgduClient.getContenu()=="/quit"){ /*quit le programme*/
      lesCanaux.supprimeClient(ptrClt);
      lesClients.supprimeClient(ptrClt->GetPseudo());
      return;
    }
		   
    if(leMsgduClient.getContenu()=="/list"){ /*liste tous les canaux*/
      lesCanaux.cmdeList(leMsgduClient.getNomCanal(),ptrClt);
      return;
    }

    if(leMsgduClient.getContenu()=="/diediedie"){
	  /*stoppe le serveur en urgence*/
      fin=true;
      return;
    }
			   
    if(cmde=="/topic" && !sansCanal && arg.length() ){
	  /*modifie le topic du canal*/
      lesCanaux.cmdeTopic(leMsgduClient.getNomCanal(),ptrClt,arg);
      return;
    }
			
    ptrClt->envoieMessageTxt(leMsgduClient.getNomCanal(),"erreur, commande inconnu ou mauvaise utilisation");
  }
  else
    if(!sansCanal)
      lesCanaux.envoieMessageMultipleTxt(leMsgduClient.getNomCanal(),ptrClt->GetPseudo()+" a dit: "+leMsgduClient.getContenu());
    else 
      ptrClt->envoieMessageTxt(leMsgduClient.getNomCanal(),"erreur, commande inconnu ou mauvaise utilisation");
}

bool Serveur::finServeur(){
  return fin;
}
