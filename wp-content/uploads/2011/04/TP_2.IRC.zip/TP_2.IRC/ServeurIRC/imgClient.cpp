#include "imgClient.hpp"

ImgClient::ImgClient(SocketCom *ptrS):Sock(ptrS),Pseudo(""){
}
	
void ImgClient::SetPseudo(const string &ch){
  Pseudo=ch;
}
string ImgClient::GetPseudo(){
  return Pseudo;
}
SocketCom* ImgClient::GetPtrSocket(){
  return Sock;
}
	
void ImgClient::envoieMessage(const Message &msg){
  Message copy(msg);
  string mess=copy.messageVersReseau();
  Sock->ecritureSocket(mess);
}
	
void ImgClient::envoieMessageTxt(const string &nomcanal,const string &mess){
  Message a(nomcanal,texte,mess);
  envoieMessage(a);
}
	
	
	
	
	
/*______________________IMGCLIENT_________________________*/
	
ImgClient* EnsImgClient::rechercherClient(string nom){
  list<ImgClient>::iterator i;
  for(i=lClient.begin(); i!=lClient.end();i++){
    if(i->GetPseudo()==nom)
      return &(*i);
  }
  return NULL;
}
		
		
void EnsImgClient::ajouteClient(SocketCom* ptr_Sock){ 
  ImgClient a(ptr_Sock);
  lClient.push_back(a);
}
	
void EnsImgClient::supprimeClient(string nom){
  list<ImgClient>::iterator i;
  bool clientSuppr=false;
  for(i=lClient.begin(); i!=lClient.end() && !clientSuppr;i++){
    if(i->GetPseudo()==nom){
      lClient.erase(i);
      clientSuppr=true;
    }
  }
  if(!clientSuppr) throw ExceptionClientInexistant();
}
	
ImgClient* EnsImgClient::rechercherClient(int fd){
  list<ImgClient>::iterator i;
  for(i=lClient.begin(); i!=lClient.end();++i)
    if(((i->GetPtrSocket())->getNumSocket()) == fd)
      return &(*i);
  return NULL;
}
