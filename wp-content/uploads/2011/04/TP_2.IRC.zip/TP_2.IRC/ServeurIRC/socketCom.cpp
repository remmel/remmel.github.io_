#include "socketCom.hpp"

SocketCom::SocketCom(int numSocketCom):Socket(){
  printf(" de communication\n");
  numSocket=numSocketCom;
}

string SocketCom::lectureSocket(){
  char buf[512];
  int tailleLu;
  if((tailleLu=read(numSocket, buf, 511))<0) throw ExceptionLecture();
  buf[tailleLu]=0;
  return buf;
}
	
void SocketCom::ecritureSocket(string &msg){
  Message a;
  a.reseauVersMessage(msg);
  cout<<a<<endl;
  int taille=msg.length();
  if(write(numSocket, msg.c_str(), taille) !=  taille)throw ExceptionEcriture();
}
