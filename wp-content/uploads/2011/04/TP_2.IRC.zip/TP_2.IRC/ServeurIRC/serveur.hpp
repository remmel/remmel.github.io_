#ifndef SELECT_HPP
#define SELECT_HPP

#include <list>
#include <iostream>
#include <iterator>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <string>
#include <list>
#include "socket.hpp"
#include "socketService.hpp"
#include "socketCom.hpp"
#include "canal.hpp"
#include "imgClient.hpp"
#include "message.hpp"



using namespace std;
 
/**
 * La classe serveur permet de recevoir ,puis d'evaluer un message et en
 * fonction du contenu ajouter/supprimer un canal, un client, envoyer
 * la reponse a un client...
 * C'est cette classe qui possede tous les canaux et tous les clients
 * @short classe permet de gerer un serveur
 * @author Mellet Remy & Nestelhut Damien
 */ 
class Serveur
{
  private:
  /**
   * Ensemble de tous les clients connecté au serveur
   * (nom + pointeur sur socket...)
   */
  EnsImgClient lesClients;
	
  /**
   * Ensemble de tous les canaux cree sur le serveur
   */
  EnsCanal lesCanaux;
 
  struct timeval tv;
  SocketService socketService;/*creation de la socket de Service*/

  /*ensemble de file descriptor à surveiller en lecture*/
  fd_set ensFileDescriptorLecture;
  /*ensemble de file descriptor à surveiller en ecriture*/	  
  fd_set ensFileDescriptorEcriture;
  /*liste de pointeurs sur des sockets de communication */
  list<SocketCom> listePointeurSocketCom; 
  bool fin;
	
public:	
		
  /**
   * ajouterSocketCom permet d'ajouter une socket a la liste des sockets
   * puis retourne un pointeur sur cette socket
   * @param numSocketCom est le numero de la nouvelle socket a ajouter a la
   * liste de socket
   */
  SocketCom* ajouterSocketCom(int numSocketCom);
	
  /**
   * constructeur du select
   * @param numPort est le numero du port
   */
  Serveur(uint16_t numPort);
	
  /**
   * a chaque lancement de cette methode, l'ensemble des sockets est scrute
   * une fois en lecture si une socket a recu un message, execSelect enverra
   * le message a traitement
   */
  void execSelect();

  /**
   * Methode evaluant le message
   * @param Message le message que le serveur a recu d'un client
   * @param fd le file descriptor du client qui a envoyé le message
   */	
  void evalueMessage(Message &leMsgduClient, int fd);

  bool finServeur();
};









#endif
