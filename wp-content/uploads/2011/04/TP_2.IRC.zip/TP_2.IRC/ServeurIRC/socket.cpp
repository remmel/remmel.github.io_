	
#include "socket.hpp"	
	
Socket::Socket()
{
  printf("cree le socket ");
}

/*On peut lancer cette interruption car ici le cycle de destruction
  ne pourra pas s'interrompre*/
Socket::~Socket()  
{
  cout<<"ferme le socket";
  if(close(numSocket) == -1)
    throw ExceptionClose ();		
}
		
int Socket::getNumSocket()
{
  return numSocket;
}
