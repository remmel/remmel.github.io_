#include "canal.hpp"


#define OPERATEUR true

   
Canal::Canal(const string &canal,ptr_ImgClient ptr_Clt):nomCanal(canal),
  topicCanal("Bienvenu sur le canal "+canal){
  nbClient=1;
  lClientOperateur.insert(ptr_Clt);
}
   
   
string  Canal::getTopic(){
  return topicCanal;
}
   
unsigned Canal::nombreClient(){
  return nbClient;
}
   
void Canal::setTopic(const string &ch){
  topicCanal=ch;
}
   
   
bool Canal::existeClient(ptr_ImgClient ptr_Clt){
  return (clientNormal(ptr_Clt) || clientOperateur(ptr_Clt));
}

/*teste si la personne est un operateur*/
bool Canal::clientOperateur(ptr_ImgClient ptr_Clt){
  set<ptr_ImgClient>::const_iterator i = lClientOperateur.find(ptr_Clt);
  if (i != lClientOperateur.end()) return true;
  else return false;
}
	
/*teste si la personne n'est pas un operateur*/
bool Canal::clientNormal(ptr_ImgClient ptr_Clt){
  set<ptr_ImgClient>::const_iterator i = lClientNormal.find(ptr_Clt);
  if (i != lClientNormal.end()) return true;
  else return false;
}
	
	
   
void Canal::ajouteClient(ptr_ImgClient ptr_Clt,const bool &operateur){
  if(operateur)
    lClientOperateur.insert(ptr_Clt);
  else
    lClientNormal.insert(ptr_Clt);
  nbClient++;
  Message msg(nomCanal,lUtilisateur,listerUtilisateur());
  envoieMessageMultiple(msg); 
}
   
void Canal::supprimeClient(ptr_ImgClient ptr_Clt){
  set<ImgClient*>::const_iterator i;
	   
  if(clientNormal(ptr_Clt)){
    i=lClientNormal.find(ptr_Clt);
    lClientNormal.erase(i);
  }
  else{
    i=lClientOperateur.find(ptr_Clt);
    lClientOperateur.erase(i);
  }
  Message msg(nomCanal,lUtilisateur,listerUtilisateur());
  envoieMessageMultiple(msg); 
	   
  nbClient--;
}
   
   
string Canal::listerUtilisateur(){
  set<ptr_ImgClient>::const_iterator i;
  string lTotalUtilisateur="";
  for(i = lClientOperateur.begin(); i != lClientOperateur.end();++i)
    lTotalUtilisateur+=("@"+(*i)->GetPseudo()+'\n');
	
  for(i = lClientNormal.begin(); i != lClientNormal.end();++i)
    lTotalUtilisateur+=('\n'+(*i)->GetPseudo() );
	   
  return lTotalUtilisateur;
	   
}

   
void Canal::envoieMessageMultiple(const Message &msg){
  set<ImgClient*>::const_iterator i;
  for(i = lClientNormal.begin();i != lClientNormal.end();++i)    
    (*i)->envoieMessage(msg);
	   
  for(i = lClientOperateur.begin(); i != lClientOperateur.end();++i)    
    (*i)->envoieMessage(msg);
}
   
/*_________________ classe EnsCanal _____________________________________*/
   
		
void EnsCanal::supprimeClientCanal(const string &nomCanal,ptr_ImgClient ptr_Clt){
  if(lCanal[nomCanal]->existeClient(ptr_Clt)){
    lCanal[nomCanal]->supprimeClient(ptr_Clt);
    if(lCanal[nomCanal]->nombreClient()==0) supprimeCanal(nomCanal);
  }
}
		
void EnsCanal::supprimeClient(ptr_ImgClient ptr_Clt){
  map<string,Canal*>::iterator i;
  for(i=lCanal.begin(); i!=lCanal.end();++i){
    if((i->second)->existeClient(ptr_Clt)){
      (i->second)->supprimeClient(ptr_Clt);/*supp client de la liste du canal*/
      if((i->second)->nombreClient()==0){ /*supp canal car plus de client*/
	delete (i->second); /*supprime le canal*/
	lCanal.erase(i); /*supprime le contenaire contenant l'obj canal et string*/
      }
    }
				  
  }
}
 		
void EnsCanal::ajouteClient(const string &nomCanal,ptr_ImgClient ptr_Clt,bool op){
  lCanal[nomCanal]->ajouteClient(ptr_Clt,op);
}
		
void EnsCanal::cmdeTopic(const string &nomCanal, ptr_ImgClient ptr_Clt, const string &txttopic){

  if(lCanal[nomCanal]->clientOperateur(ptr_Clt)){ /*client operateur*/
    lCanal[nomCanal]->setTopic(txttopic);
    Message msg(nomCanal,texte,"Topic changé, nouveau topic: "+txttopic);
    lCanal[nomCanal]->envoieMessageMultiple(msg);
  }
  else{ /*client non operateur*/
    Message msg(nomCanal,texte,"Impossible de changer le topic, vous n'etes pas opérateur");
    ptr_Clt->envoieMessage(msg);
  }
			  
}
		
void EnsCanal::cmdeJoin(const string &nomCanal, ptr_ImgClient ptr_Clt){
 
  /*message a envoyer au canal correspondant*/	
  Message msg;    
	
  /*message a envoyer "canal sans nom"(canal indiquant les (de)connexions...)*/
  Message msgSys; 
  bool msg_utilise=true; /*indique si le message msg va etre utiliser*/
			
  if(!(this->existeCanal(nomCanal))){ /*le canal n'existe pas alors on le cree*/
    ajouteCanal(nomCanal,ptr_Clt);
	  
	/*message contenant la liste des utilisateurs de ce canal*/
    Message msg_listUtili(nomCanal,lUtilisateur,lCanal[nomCanal]->listerUtilisateur());
    ptr_Clt->envoieMessage(msg_listUtili);
					
    msgSys.remplirMessage("",texte,"Vous avez cree le canal: "+nomCanal); 
    msg.remplirMessage(nomCanal,texte,"Le topic: "+lCanal[nomCanal]->getTopic());
  }
  else{ /*le canal existe*/
    if(lCanal[nomCanal]->existeClient(ptr_Clt)){
      msgSys.remplirMessage(nomCanal,texte,"Vous etes deja connecte au canal "+nomCanal);
      msg_utilise=false;
    }
    else{
      ajouteClient(nomCanal,ptr_Clt,!OPERATEUR);
      msgSys.remplirMessage("",texte,"Vous avez rejoint au canal: "+nomCanal);
      msg.remplirMessage(nomCanal,texte,"Le topic: "+lCanal[nomCanal]->getTopic());
    }
				 
  }
				 
  if(msg_utilise) { ptr_Clt->envoieMessage(msg); sleep(1); }
  
  /*dans tous les cas on envoie un message d'etat*/
  ptr_Clt->envoieMessage(msgSys);
				
}
			 
			 
void EnsCanal::cmdeList(const string &nomCanal, ptr_ImgClient ptr_Clt){
  Message msg;
  msg.remplirMessage(nomCanal,lCanaux,listerCanal());
  ptr_Clt->envoieMessage(msg);
}
			 
bool EnsCanal::existeCanal(const string &nomCanal){
  map<string,Canal*>::iterator i;
  for(i=lCanal.begin(); i!=lCanal.end();++i)
    if((i->first)==nomCanal) return true;
  return false;  
}
		
string EnsCanal::getTopic(const string &nomCanal){
  return lCanal[nomCanal]->getTopic();
}
		
void EnsCanal::ajouteCanal(const string &nomCanal,ptr_ImgClient ptr_Clt){
  lCanal[nomCanal]=new Canal(nomCanal,ptr_Clt);
}
		
bool EnsCanal::clientOperateur(const string &nomCanal,ptr_ImgClient ptr_Clt){
  return lCanal[nomCanal]->clientOperateur(ptr_Clt);
}
		
		
void EnsCanal::envoieMessageMultipleTxt(const string &nomCanal,string txt){
  Message msg(nomCanal,texte,txt);
  lCanal[nomCanal]->envoieMessageMultiple(msg);
			    
}
		
string EnsCanal::listerCanal(){
  string ch="";
  map<string,Canal*>::iterator i;
  for(i=lCanal.begin(); i!=lCanal.end();++i){
    ch+=(i->first);
    ch+="\n";
  }
  return ch;
}
		
void EnsCanal::supprimeCanal(const string &nomCanal){
  map<string,Canal*>::iterator i;
  for(i=lCanal.begin(); i!=lCanal.end();++i){
    if(nomCanal==i->first){
      delete (i->second);
      lCanal.erase(i);
    }
  }
}
			
EnsCanal::~EnsCanal(){
  map<string,Canal*>::iterator i;
  for(i=lCanal.begin(); i!=lCanal.end();++i)
    delete (i->second);
}
