#ifndef SOCKETCOM_HPP
#define SOCKETCOM_HPP

#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <exception>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <iostream>
#include "socket.hpp"
#include "message.hpp"
#include "exception.hpp"

using namespace std;


/**
 * classe SocketCom: classe heritant de la classe Socket.
 * elle permet de gerer la socket de communication
 */	
class SocketCom: public Socket
{
public:	
  /**
   * Constructeur de la socket de communication
   * @param numSocketCom numero de la socket
   */
  SocketCom(int numSocketCom);

  /**
   * Renvoie le texte lu dans la socket
   * @return string
   */
  string lectureSocket();

  /**
   * Ecrit du texte dans la socket
   * @param msg de type string
   */
  void ecritureSocket(string &msg);
};

/************************/
/*GESTION DES EXCEPTIONS*/
/************************/


/**
 * classe ExceptionLecture: classe heritant de la classe ExceptionSocket permet
 * de gerer toutes les erreurs lie a la lecture d'une socket de communication
 */	
class ExceptionLecture: public ExceptionSocket
{
public:
  ExceptionLecture() { message +="Impossible de lire sur la socket."; }
  ~ExceptionLecture() throw() {}		
};

/**
 * classe ExceptionEcriture: classe heritant de la classe ExceptionSocket
 * permet de gerer toutes les erreurs lie a la l'ecriture dans une socket
 * de communication
 */
class ExceptionEcriture: public ExceptionSocket 
{
public:
  ExceptionEcriture() { message +="Impossible d'ecrire sur la socket."; }
  ~ExceptionEcriture() throw() {}		
};


#endif
