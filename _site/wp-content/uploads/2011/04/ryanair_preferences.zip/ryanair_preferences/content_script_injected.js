//automatically accept Ryanair term
if(!$("#termsAccept").attr('checked'))
  $("#termsAccept").click();

var storage;

/* script injected in Ryanair webpage */

chrome.extension.sendRequest({ action: "getLocalStorage"});
chrome.extension.onRequest.addListener(function(request, sender, sendResponse){
  if(request.action){
    storage = request.localStorage;
    
    synchronizeValue("#GroupServices_PassengerInputServices_TextBoxFirstName_1", "firstname");
    synchronizeValue("#GroupServices_PassengerInputServices_TextBoxLastName_1", "lastname");
    synchronizeValue("#GroupServices_PassengerInputServices_DropDownListTitle_1", "title");
    
    $("#SSRCode_PASSENGERCOUNT_0_SSRCOUNT_0").val("BAG0");
    $("#pb_rd_0_0").click(); //receive a mobile message
    $("#GroupServices_PassengerInputServices_DropDownListResidentCountry_1").val("ZQ"); //no insurance
    $("#GroupServices_SmsOptionServices_smsNoConfirmation").attr('checked',true);
    //$("#smsntR0").attr('checked',true);
    $("#smsntR0").click();
    $("#GroupServices_AgreementInputServices_CheckBoxAgreement").click();
    
    //validate form 1
    //$("#GroupServices_ButtonSubmit").click();
    //form rentacar
    //$("#CarHireFullControl_ButtonCancel").click();

    //form payment
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_TextBoxEmailAddress", "email");
    //TODO auto fill email confirmation when the email is filled
    $("#email_conf").val(storage['email']);
    
    synchronizeValue("#alt_phone_a",'phone-a');
    synchronizeValue("#alt_phone_b",'phone-b');
    synchronizeValue("#alt_phone_c",'phone-c');

    //$("#PaymentLayoutView_PaymentInputCCFRPaymentView_TextBoxACCTNO").val("01234567890");
    //$("#PaymentLayoutView_PaymentInputCCFRPaymentView_DropDownListEXPDAT_Month").val("06");
    //$("#PaymentLayoutView_PaymentInputCCFRPaymentView_DropDownListEXPDAT_Year").val("2014");
    //$("#PaymentLayoutView_PaymentInputCCFRPaymentView_TextBoxCC__VerificationCode").val("123");

    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_DropDownListTitle", "cc-title");
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_TextBoxFirstName", "cc-firstname");
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_TextBoxLastName", "cc-lastname");
    
    //if credit card name not set, use passenger name
    if($("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_DropDownListTitle").val()=="")
      $("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_DropDownListTitle").val(storage['title']);
      
    if($("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_TextBoxFirstName").val()=="")
      $("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_TextBoxFirstName").val(storage['firstname']);
    
    if($("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_TextBoxLastName").val()=="")
      $("#PaymentLayoutView_PaymentInputCCFRPaymentView_ContactInputViewPaymentView_TextBoxLastName").val(storage['lastname']);
    
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_TextBoxADDR1", "address-1");
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_TextBoxADDR2", "address-2");
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_TextBoxADDR3", "address-3");
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_TextBoxCITY", "address-city");
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_TextBoxPOSTAL", "address-postal");
    synchronizeValue("#PaymentLayoutView_PaymentInputCCFRPaymentView_TextBoxCOUNTRY", "address-country");

    $("#PaymentLayoutView_PaymentInputCCFRPaymentView_DropDownListPaymentMethodCode").val("ExternalAccount:MP").change();
  }
});

function synchronizeValue(webpageId, storageName){
  $(webpageId).val(storage[storageName]);
  $(webpageId).change(function(){
    chrome.extension.sendRequest({ action: "setLocalStorage", variable: storageName, value: this.value});
  });
}