/****************************************************************************
** QFenPrincipale meta object code from reading C++ file 'qfenprincipale.h'
**
** Created: Tue Jan 23 17:49:22 2007
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.6   edited Mar 8 17:43 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../qfenprincipale.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *QFenPrincipale::className() const
{
    return "QFenPrincipale";
}

QMetaObject *QFenPrincipale::metaObj = 0;
static QMetaObjectCleanUp cleanUp_QFenPrincipale( "QFenPrincipale", &QFenPrincipale::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString QFenPrincipale::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QFenPrincipale", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString QFenPrincipale::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QFenPrincipale", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* QFenPrincipale::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = FenPrincipale::staticMetaObject();
    static const QUMethod slot_0 = {"ajoutMultiple", 0, 0 };
    static const QUMethod slot_1 = {"nettoyer", 0, 0 };
    static const QUMethod slot_2 = {"showApropos", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "ajoutMultiple()", &slot_0, QMetaData::Protected },
	{ "nettoyer()", &slot_1, QMetaData::Protected },
	{ "showApropos()", &slot_2, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"QFenPrincipale", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_QFenPrincipale.setMetaObject( metaObj );
    return metaObj;
}

void* QFenPrincipale::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "QFenPrincipale" ) )
	return this;
    return FenPrincipale::qt_cast( clname );
}

bool QFenPrincipale::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: ajoutMultiple(); break;
    case 1: nettoyer(); break;
    case 2: showApropos(); break;
    default:
	return FenPrincipale::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool QFenPrincipale::qt_emit( int _id, QUObject* _o )
{
    return FenPrincipale::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool QFenPrincipale::qt_property( int id, int f, QVariant* v)
{
    return FenPrincipale::qt_property( id, f, v);
}

bool QFenPrincipale::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
