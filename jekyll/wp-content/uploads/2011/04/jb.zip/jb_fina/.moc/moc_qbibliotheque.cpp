/****************************************************************************
** QBibliotheque meta object code from reading C++ file 'qbibliotheque.h'
**
** Created: Tue Jan 23 17:49:21 2007
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.6   edited Mar 8 17:43 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../qbibliotheque.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *QBibliotheque::className() const
{
    return "QBibliotheque";
}

QMetaObject *QBibliotheque::metaObj = 0;
static QMetaObjectCleanUp cleanUp_QBibliotheque( "QBibliotheque", &QBibliotheque::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString QBibliotheque::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QBibliotheque", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString QBibliotheque::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QBibliotheque", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* QBibliotheque::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = WBibliotheque::staticMetaObject();
    static const QUMethod slot_0 = {"languageChange", 0, 0 };
    static const QUMethod slot_1 = {"genererBibliotheque", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "languageChange()", &slot_0, QMetaData::Protected },
	{ "genererBibliotheque()", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"QBibliotheque", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_QBibliotheque.setMetaObject( metaObj );
    return metaObj;
}

void* QBibliotheque::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "QBibliotheque" ) )
	return this;
    if ( !qstrcmp( clname, "Collection" ) )
	return (Collection*)this;
    return WBibliotheque::qt_cast( clname );
}

bool QBibliotheque::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: languageChange(); break;
    case 1: genererBibliotheque(); break;
    default:
	return WBibliotheque::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool QBibliotheque::qt_emit( int _id, QUObject* _o )
{
    return WBibliotheque::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool QBibliotheque::qt_property( int id, int f, QVariant* v)
{
    return WBibliotheque::qt_property( id, f, v);
}

bool QBibliotheque::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
