#include "qfenprincipale.h"


QFenPrincipale::QFenPrincipale( QWidget* parent, const char* name, WFlags fl):FenPrincipale(parent,name,fl){

  apropos=new About(this,"about");

  /* connecte les double clique pour ajouter un morceau */
  connect( bibliotheque->listView, SIGNAL( doubleClicked ( QListViewItem*) ), lecteur, SLOT( ajoutMorceau(QListViewItem*) ) );
  connect( bibliotheque->nonGroupe, SIGNAL( doubleClicked ( QListViewItem*) ), lecteur, SLOT( ajoutMorceau(QListViewItem*) ) );

  /* connect le bouton d'ajout multiple */
  connect(bibliotheque->buttonAjout, SIGNAL( clicked(void) ), this, SLOT( ajoutMultiple() ) );

  /* connect le bouton nettoyer*/
  connect(Nettoyer, SIGNAL( activated(void) ), this, SLOT( nettoyer() ) );

  /* connect le bouton d'ouverture de la boite apropos*/
  connect( aproposOK, SIGNAL( activated() ), this, SLOT( showApropos() ) );

}

void QFenPrincipale::scannerMorceau( QListViewItem* item){

  QMorceau*  qmorceau;
  while(item){
    qmorceau=dynamic_cast<QMorceau*>(item);
    if(qmorceau && qmorceau->isSelected()){
      lecteur->ajoutMorceau(qmorceau);
    }
    item=item->itemBelow(); 
  }
}

void QFenPrincipale::ajoutMultiple(){
  if(bibliotheque->classeur->currentPageIndex()==0){
    
    
  }
  if(bibliotheque->classeur->currentPageIndex()==1){ //liste nonGroupe
    QListViewItem* item;
    item=bibliotheque->nonGroupe->firstChild();
    scannerMorceau(item);
    
  }
  if(bibliotheque->classeur->currentPageIndex()==0){ //liste artiste/album
    QListViewItem* item;
    item=bibliotheque->listView->firstChild();
    scannerMorceau(item);

  }
}

void QFenPrincipale::nettoyer(){
  bibliotheque->clear();
  bibliotheque->generer();
  lecteur->clear();
} 


void QFenPrincipale::showApropos(){
  apropos->show();
}
