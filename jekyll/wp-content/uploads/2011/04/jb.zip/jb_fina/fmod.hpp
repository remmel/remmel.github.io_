/***************************************************************************
 *  fichier: fmod.hpp
 *  
 *  Tue Jan  2 14:36:50 2007
 *  Copyright  2007  User
 *  Auteur: Nestelhut Damien/Remy Mellet
 *  Email: serial01@free.fr
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
 
#ifndef FMOD_HPP
#define FMOD_HPP
 
#include "./api_fmod/inc/fmod.hpp"
#include "./api_fmod/inc/fmod_errors.h"

#include <string>
#include <stdlib.h>
#include <iostream>
#include <list>

using namespace std;

class Fmod 
{
	private:
		FMOD::System *system;
		FMOD::Sound *morceau;//dernier morceau lu
		FMOD::Channel *canal;//dernier canal utilisé
		
		//attributs pour lecture de flux
		unsigned int pourcentageDsBuffer;
		int balance;
		bool lectureEnCours;
		float volume;
		bool mute;
		pthread_t thread;
		FMOD_OPENSTATE  etatOuverture;//etat d'ouverture: connecting..etc
		
		bool famine;//"etat de famine": si le buffer est vide(lecture 
							  //plus rapide que remplissage buffer)
		FMOD_RESULT valRetour;
		FMOD_MODE mode;//mode de lecture utile????? voir cas du flux web
	
	public:
		Fmod();
		~Fmod();
		void verifErreur();//pas vraiment une methode.....
		void play(string chemin);
		void pause();
		bool getPauseActive();
		void stop();
		void augmenterVolume(const float pourcentage);
		void reduireVolume(const float pourcentage);
		void setVolume(const float niveauVolume);
		int  getVolume();
		bool getLectureActive();
		bool setLectureActive();
		FMOD::Channel * getCanal(){return canal;}
		void muet();
		void setHpBalance(int balance);
		int getBalance();
		list<string> chargerPlaylist(string chemin);
		unsigned int getInfoMorceau(string chemin, unsigned int info);
		string getTagInfo(string chemin,unsigned int info);
		
		void setPositionIndicateur(unsigned int position);
		unsigned int getPositionIndicateur();
	
		//fonction relative au flux web

		void playFluxWeb(string url);
		string affEtatOuverture();
		unsigned int affPourcentageDsBuffer();
		string affFamine();
		
		//visualisation OpenGL
		void visualisation();
		
		
};

//void exceptionFMOD(){ }

#endif
