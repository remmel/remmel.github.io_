#include "ensPtrMorceau.hpp"
#include <functional>
#define LISTE vector

bool estUnFichierDeMusique(const string &chemin, bool fichier_m3u){

  if(chemin.length() >= 5)
    {
      string extension(chemin,chemin.length()-4);

      //upper(ext)

      if(fichier_m3u)
	return (extension == ".m3u" );
      else{
	
	if
	  (
	   extension == ".mp3"  || extension == ".ogg"    || 
	   extension == ".MP3"  || extension == ".OGG"    ||
	   extension == ".aiff" || extension == ".AIFF"   ||
	   extension == ".asf"  || extension == ".ASF"    || 
	   extension == ".asx"  || extension == ".ASX"    ||
	   extension == ".dls"  || extension == ".DLS"    ||
	   extension == ".fsb"  || extension == ".FSB"    || 
	   extension == ".it"   || extension == ".IT"     ||
	   extension == ".mid"  || extension == ".MID"    || 
	   extension == ".mod"  || extension == ".MOD"    ||
	   extension == ".mp2"  || extension == ".MP2"    ||
	   extension == ".pls"  || extension == ".PLS"    ||
	   extension == ".raw"  || extension == ".RAW"    ||
	   extension == ".s3M"  || extension == ".S3M"    ||
	   extension == ".vag"  || extension == ".VAG"    || 
	   extension == ".wax"  || extension == ".WAX"    ||
	   extension == ".wav"  || extension == ".WAV"    ||
	   extension == ".xm"   || extension == ".XM"     
	   )
	  return true;
	
      }
    }
  return false;  
}



/****************************** ENSPTRMORCEAU ***************/


void EnsPtrMorceau::supprimeTout(){
  while(ensMorceau.begin()!=ensMorceau.end())
    ensMorceau.erase(ensMorceau.begin());

}

void EnsPtrMorceau::ajouterMorceau(Morceau* ptrMorceau){
  if(!existeMorceau(ptrMorceau))
    ensMorceau.push_back(ptrMorceau);
}
/*Morceau* EnsPtrMorceau::trouverMorceau(int i){
  return ensMorceau[i];
  }*/

bool EnsPtrMorceau::existeMorceau(Morceau* m){
  int nbMorceau=nombreDeMorceau();
  for(int i=0;i<nbMorceau;i++)
    if( (*m)==(*(ensMorceau[i])) )
      return true;

  return false;

}


void EnsPtrMorceau::sauvegarderM3U(const string &chemin){
  FILE* fd=fopen (chemin.c_str(), "w");
  if(fd==NULL) return; /* erreur lors de l'ouverture du fichier */
  Morceau *m;
  string com;
  int nb=nombreDeMorceau();
  com="#EXTM3U\n";
  for(int i=0;i<nb;i++){
    com+="#JB:";
    m=(*this)[i];
    com+=m->getTitre()+"#";
    com+=m->getNomAlbum()+"#";
    com+=m->getNomAuteur()+"#";
    com+='\n'+m->getChemin()+'\n';
    if(fwrite(com.c_str(),com.length(),1,fd)!=1) /* erreur */
      return;
    com="";
  }
  fclose(fd); //exception
}


int EnsPtrMorceau::nombreDeMorceau(){
  CompteMorceau nb;
  nb=for_each(ensMorceau.begin(),ensMorceau.end(),nb);
  return nb.comptage;
}

void EnsPtrMorceau::supprimerMorceau(int i){
  LISTE<Morceau*>::iterator it=ensMorceau.begin();
  for(int j=0;j!=i || it!=ensMorceau.end();j++)
    it++;
  if(it!=ensMorceau.end())
    ensMorceau.erase(it);
  else cout<<"rang trop grand\n";
}

void EnsPtrMorceau::afficheNomMorceau(){
  LISTE<Morceau*>::iterator it=ensMorceau.begin();
  for(it=ensMorceau.begin();it!=ensMorceau.end();it++)
    cout<<(*it)->getTitre()<<endl;
}

/********************************* ENSMORCEAU **************/

void EnsMorceau::ajouterMorceau(const string &chemin){
    
  Morceau *m=new Morceau(chemin);
  m->chargerTAG(); // a mettre dans collection
  EnsPtrMorceau::ajouterMorceau(m);
}

void EnsMorceau::ajouterMorceau(const string &chemin,const string &titre, const string &auteur, const string &album){
  Morceau *m=new Morceau(chemin,titre,auteur,album);
  EnsPtrMorceau::ajouterMorceau(m);
}

void EnsMorceau::ajouterM3U(const string &chemin){
  FILE* fd=fopen (chemin.c_str(), "r");
  if(fd==NULL) return; /* erreur lors de l'ouverture du fichier*/
  char ligne[200];	    
  
  string titre="";
  string album="";
  string artiste="";
  bool lignePerso=false; //indique si il y a une ligne personnalisee
  if( (fgets(ligne,200,fd)!=NULL)){
    if( (strcmp(ligne,"#EXTM3U\n")==0) ){ //c'est bien un fichier m3u
    while(fgets(ligne,200,fd)!=NULL){ /* tant qu'il y a une ligne a lire*/
      if(strlen(ligne)>4){
	if(ligne[0]=='#'){

	  if(strncmp(ligne,"#JB:",4)==0){ //il s'agit d'une ligne personnalise propre a ce jukebox
	    lignePerso = true;
	    int longueur=strlen(ligne);
	    titre="";
	    album="";
	    artiste="";
	    string tmp="";
	    for(int i=4;i<longueur;i++){
	      if(ligne[i]!='#')
		tmp+=ligne[i];
	      else{
		if(titre=="") titre=tmp, tmp="";
		else if(album=="") album=tmp,tmp="";
		else if(artiste=="") artiste=tmp,tmp="";
	      }
	    }
	  }

	}else{ //ligne[0]!='#'
	  string chemin(ligne,strlen(ligne)-1); //on enleve le saut final
	  if(lignePerso)
	    ajouterMorceau(chemin,titre,artiste,album);
	  else
	    ajouterMorceau(chemin);
	  
	  lignePerso=false;
	}
	
      }
    }
   }
  }
  fclose(fd);

  

}

struct Nettoie : public unary_function<Morceau*,bool>{
  bool operator()(Morceau* m){
    FILE *fd=fopen (m->getChemin().c_str(),"r");
    if(fd==NULL) return true;
      
    fclose(fd);
    return false;
  }
};


void EnsMorceau::nettoyer(){
  Nettoie n;
  vector<Morceau*>::iterator it;
  while( (it=find_if(ensMorceau.begin(),ensMorceau.end(),n)) != ensMorceau.end() ){
    delete *it;
    ensMorceau.erase(it);
  }
}

EnsMorceau::~EnsMorceau(){
  vector<Morceau*>::iterator it;
  while( (it=ensMorceau.begin()) != ensMorceau.end() ){
    delete *it;
    //ensMorceau.erase(it);
  }

  
}





int EnsMorceau::genererListe(string chemin)
{
  struct dirent *ptrEntreeRep;
  DIR *ptrRep;
  static unsigned int idFichier;

  if( (ptrRep=opendir(chemin.c_str()) ) == NULL )
    {perror("ERREUR lors du parcours. Le repertoire est introuvable");return -1;}//faire message erreur graphique...exception????

  while((ptrEntreeRep=readdir(ptrRep)) != NULL)//readdir permet le passage a l'entrée suivante
    {	
      //Si l'entree est un repertoire on le parcours
      if(strcmp(ptrEntreeRep->d_name,".") && strcmp(ptrEntreeRep->d_name ,"..") )
	{
	  if( (ptrEntreeRep->d_type == DT_DIR))
	    {
	      string cheminSousRep=chemin+ptrEntreeRep->d_name+"/";	
	      genererListe(cheminSousRep);
	    }
	  else
	    {	
	      string chaineTMP=(ptrEntreeRep->d_name);
	      if(chaineTMP.length() >= 5)
		{
		  string extension(chaineTMP,chaineTMP.length()-4);
		  if(extension == ".mp3" || extension == ".ogg" || extension == ".MP3" ||extension == ".OGG" )
		    {	
		      ajouterMorceau(chemin+ptrEntreeRep->d_name);
		      idFichier++;
		    }
		}
	    }
	}
    }
  closedir(ptrRep);
  return idFichier;
}



/********************************* PLAYLIST ***************/

PlayList::PlayList():rang(0){};
	



void PlayList::lireMorceau()
{
  play( ensMorceau[rang]->getChemin());
}

void PlayList::lireMorceau(int num){
  if(num>=0 && num <=nombreDeMorceau())
    {
      rang=num;
      lireMorceau();
    }


}


void PlayList::pisteSuivante(){
  /*if( getLectureActive() )
    stop();*/
  if( rang+1 < nombreDeMorceau()){
      rang++;
      lireMorceau();
    }
}

void PlayList::pistePrecedente(){
  /*if(getLectureActive() )
    stop();*/
  
  if( rang-1 > 0  ){
      rang--;
      lireMorceau();
    }

}

void PlayList::pause(){

  if(getLectureActive())
    Fmod::pause();

}

string PlayList::getCheminMorceauCourant()
{
  return ensMorceau[rang]->getChemin();
}

/********************************ALBUM**********************/

 Album::Album(const string &nom){
    nomAlbum=nom;
  }

  string Album::getNomAlbum(){
    return nomAlbum;
  }







/******************************** AUTEUR *******************/

void Auteur::ajouterMorceauAlbum(Morceau * ptrMorceau, const string &nomAlbum){
  //chercher l'album
  Album *album=rechercherPtrAlbum(nomAlbum);

  //s'il n'existe pas on le cree
  if(album==NULL){
    ajouterAlbum(nomAlbum);
    album=rechercherPtrAlbum(nomAlbum);
  }
  
  //ajouter le morceau a l'Album
  album->ajouterMorceau(ptrMorceau);
  
}


void Auteur::ajouterAlbum(const string &nom){
  Album *ptrAlbum=new Album(nom);
  ensAlbum.push_back(ptrAlbum);
}

int Auteur::nombreDAlbum(){
  CompteAlbum nb;
  nb=for_each(ensAlbum.begin(),ensAlbum.end(),nb);
  return nb.comptage;
}
Album* Auteur::rechercherPtrAlbum(const string &nomAlbum){
  BonNomAlbum bonNom(nomAlbum);
  LISTE<Album*>::iterator it_album;
  it_album=find_if(ensAlbum.begin(),ensAlbum.end(),bonNom);// pb ne marche pas!
  if(it_album==ensAlbum.end()) return NULL;
  else return *it_album;
}

Auteur::~Auteur(){
  LISTE<Album*>::iterator it_album;
  while( (it_album=ensAlbum.begin()) != ensAlbum.end() ){
    delete *it_album;
    ensAlbum.erase(it_album);
  }
}

void Auteur::supprimeTout(){
  LISTE<Album*>::iterator it_album;
  while( (it_album=ensAlbum.begin()) != ensAlbum.end() ){
    delete *it_album;
    ensAlbum.erase(it_album);
  }
}


/****************************** COLLECTION ***************/

void Collection::generer(EnsMorceau *ptrEnsMorceau){
  supprimeTout(); /* on regenere TOUT donc on supprime l'ancienne collection*/
  Morceau *m;
  int nbMorceau=ptrEnsMorceau->nombreDeMorceau();
  for(int rang=0;rang<nbMorceau;rang++){
    m=(*ptrEnsMorceau)[rang];
    if(m==NULL){
      cout<<"erreur inconnu, ptr null"<<endl;
      exit(0);
    }
    ajouterMorceauAuteur(m,m->getNomAuteur());
  }
}
    

void Collection::ajouterMorceauAuteur(Morceau *ptrMorceau,const string& nomAuteur){
  Auteur *auteur=rechercherPtrAuteur(nomAuteur);
  if(auteur==NULL){
    ajouterAuteur(nomAuteur);
    auteur=rechercherPtrAuteur(nomAuteur);
  }

  //on ajoute a un auteur donnee son morceau
  auteur->ajouterMorceauAlbum(ptrMorceau,ptrMorceau->getNomAlbum());
}


void Collection::ajouterAuteur(const string &nom){
  Auteur *ptrAuteur=new Auteur(nom);
  ensAuteur.push_back(ptrAuteur);
}


Auteur* Collection::rechercherPtrAuteur(const string &nomAuteur){
  BonNomAuteur bonNom(nomAuteur);
  LISTE<Auteur*>::iterator it_auteur;
  it_auteur=find_if(ensAuteur.begin(),ensAuteur.end(),bonNom);
  
  if(it_auteur==ensAuteur.end()) return NULL;
  else return *it_auteur;
}

int Collection::nombreDAuteur(){
  CompteAuteur nb;
  nb=for_each(ensAuteur.begin(),ensAuteur.end(),nb);
  return nb.comptage;
}

Collection::~Collection(){
  LISTE<Auteur*>::iterator it_auteur;
  while( (it_auteur=ensAuteur.begin()) != ensAuteur.end() ){
    delete *it_auteur;
    ensAuteur.erase(it_auteur);
  }
}

void Collection::supprimeTout(){
  LISTE<Auteur*>::iterator it_auteur;
  while( (it_auteur=ensAuteur.begin()) != ensAuteur.end() ){
    delete *it_auteur;
    ensAuteur.erase(it_auteur);
  }
}
