#ifndef QBIBLIOTHEQUE_H
#define QBIBLIOTHEQUE_H


#include "wbibliotheque.h"
#include "ensPtrMorceau.hpp"
#include "wabout.h"
#include "qlecteur.h"
#include <qvariant.h>
#include <qpushbutton.h>
#include <qheader.h>
#include <qlistview.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qvbox.h>
#include <qlistbox.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <qapplication.h>
#include <qtextview.h>
#include <qfileinfo.h>
#include <qfile.h>
#include <qtextstream.h>
#include <qhbox.h>
#include <qspinbox.h>
#include <qlabel.h>
#include <qmultilineedit.h>
#include <qheader.h>
#include <qevent.h>
#include <qpainter.h>
#include <qpopupmenu.h>
#include <qpushbutton.h>
#include <qtoolbutton.h>
#include <qfile.h>
#include <qtextstream.h>
#include <qtooltip.h>
#include <qfiledialog.h>
#include <qtabwidget.h>

class QBibliotheque : public WBibliotheque, public Collection
{
  Q_OBJECT
    EnsMorceau lesMorceaux;
  

 public:
  QBibliotheque( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );

  /**
   * Nettoie tout: supprime toute la bibliotheque
   */
  void clear();
  /**
   * a partir de l'ensemble de morceaux et de la collection,
   * cette fonction permet de creer graphiquement la collection
   */
  void generer();
 
  protected slots:
    virtual void languageChange(){};


  public slots:

    /**
     * slot permettant d'ouvrir une boite de dialogue pour indiquer
     * quel dossier nous voulons scanner
     */
    virtual void genererBibliotheque();
 
 
 
};



#endif
