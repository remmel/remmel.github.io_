#ifndef MORCEAU_HPP
#define MORCEAU_HPP

#include <string>
#include <iostream>
#include "fmod.hpp"
using namespace std;


/**
 * la classe morceau represente un morceau, donc elle possede
 * le chemin du morceau ainsi que ses principaux tags
 */
class Morceau{
  string titre;
  string artiste;
  string album;
  string chemin;
  string annee;
  string genre;
  string commentaire;

public:
  /**
   * construit un morceau a partir de son chemin
   */
  Morceau(const string &a);
  string getTitre();
  string getNomAlbum();
  string getNomAuteur();
  string getChemin(){
    return chemin;
  }
  
  /**
   * charge les tags du morceau
   */
  void chargerTAG();
  
  /*void affiche(){
    cout<<"titre: "<<titre<<endl;
    cout<<"artiste: "<<artiste<<endl;
    cout<<"album: "<<album<<endl;
    cout<<"annee: "<<annee<<endl;
    }*/

  /**
   * affiche un morceau
   */
  friend ostream &operator <<(ostream &os, Morceau m){
    os<<"titre: "<<m.titre<<"  | artiste: "<<m.artiste<<" | album: "<<m.album<<" | annee: "<<m.annee<<endl;
    return os;
    }

  /**
   * permet de comparer un morceau, 2 morceaux sont
   * egaux s'ils ont le meme chemin
   */
  bool operator==(Morceau &m){
    return ( (m.getChemin()) == (getChemin()) );
  }

  /**
   * construit un morceau a partir du nom mais evite de charger
   * ses tags un indiquant en parametre son titre, son auteur
   * et son album
   */
  Morceau(const string &a, const string &tit, const string &aut, const string &alb){
    chemin=a;
    titre=tit;
    artiste=aut;
    album=alb;    
    }


};


#endif
