/***************************************************************************
 *            fmod.cpp
 *
 *  Tue Jan  2 14:36:36 2007
 *  Copyright  2007  User
 *  Email
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
 

#include "fmod.hpp"
#include "./sdglutils_lib/sdlglutils.h"
//#include "sdlglutils.h"
#include "/usr/include/pthread.h"
//#include <pthread.h>
#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>

enum {TITRE,ARTISTE,ALBUM,ANNEE,STYLE,COMMENTAIRE,TAGTYPE};
enum {DUREE,DEBIT,ECHANTILLONNAGE};


Fmod::Fmod()
{
	lectureEnCours=false;
	volume=100;
	balance=0;
	mute=false;
	//Creation de l'objet principal system de FMOD
	valRetour=FMOD::System_Create(&system);
	verifErreur();
	//Prend en argument taux échantillonnage,nb canaux max et effets DirectX 
	valRetour=system->init(1,FMOD_INIT_NORMAL,0);     
	verifErreur();

	mode=FMOD_SOFTWARE | FMOD_2D; //FMOD_SOFTWARE pour pouvoir faire la visualisation
}

Fmod::~Fmod()
{
    system->release();//Libere toutes les ressources allouées par fmod
	verifErreur();
}

void Fmod::verifErreur()
{
	if(valRetour != FMOD_OK)
	{
		cout << "erreur fmod: "<<FMOD_ErrorString(valRetour)<<endl;exit(-1);
		//throw exceptionFMOD(void);
	}
}

void Fmod::play(string chemin)//rajouter mode lecture en argument
{	
	FILE * fd=fopen(chemin.c_str(),"r");
	if(fd != NULL)
	{
		//Charge dans le buffer le debut du morceau
		valRetour=system->createStream(chemin.c_str(),mode,NULL,&morceau);
		verifErreur();
		
		//lance la lecture, 
		//1er argument canal choisi pour la lecture, FMOD_CHANNEL_FREE -> aleatoire
		//2eme argument definit le flag relatif a la pause...
		//3eme argument canal de lecture,FMOD_CHANNEL_REUSE reutilise dernier canal
		valRetour=system->playSound(FMOD_CHANNEL_FREE,morceau,false,&canal);
		verifErreur();
		
		lectureEnCours=true;
		setVolume(volume);
		setHpBalance(balance);
		
		valRetour=canal->setMute(mute);
		verifErreur();	

	}
	fclose(fd);
}


bool Fmod::getLectureActive()
{
	return lectureEnCours;
}

void Fmod::pause()
{
	if(getLectureActive())
	{
		bool etat;
		valRetour=canal->getPaused(&etat);
		verifErreur();
		valRetour=canal->setPaused(!etat);
		verifErreur();
	}
}


bool Fmod::getPauseActive()
{
	if(getLectureActive())
	{
		bool etat;
		valRetour=canal->getPaused(&etat);
		verifErreur();
		
		return etat;
	}
	return false;
}


void Fmod::stop()
{
	if(getLectureActive())
	{
		lectureEnCours=false;
		//if(visualisationActiver == 1)
			pthread_join(thread,NULL);

		valRetour=canal->stop();// Arrêt de la lecture
		verifErreur();
		
		morceau->release();//liberation des ressources alloué pour le morceau
		verifErreur();

	}
}


void Fmod::augmenterVolume(float pourcentage)
{
	volume+=pourcentage;
	if(volume > 100)
		volume=100;
	if(getLectureActive())	
	{
		valRetour=canal->setVolume(volume/100);
		verifErreur();
	}
		
}

void Fmod::reduireVolume(float pourcentage)
{
	volume-=pourcentage;
	if(volume <0)
		volume=0;
	if(getLectureActive())	
	{
		valRetour=canal->setVolume(volume/100);
		verifErreur();
	}
}

void Fmod::setVolume(float niveauVolume)
{
	volume=niveauVolume;
	if(getLectureActive())	
	{
		if(volume > 0 || volume < 100)
		{
			valRetour=canal->setVolume(volume/100);
			verifErreur();
		}
	}
}

int Fmod::getVolume()
{
	return (int)volume;
}

list<string> Fmod::chargerPlaylist(string chemin)
{
	FMOD::Sound *playlist;
	FMOD_TAG tag;
	list<string> listeCheminMorceau;
	int numMorceau,nbMorceaux;
	char *ptrChaine=NULL,*ptrChaineTMP=NULL;
	char * cheminTMP= (char *)malloc(256*sizeof(char));
	
	valRetour=system->createStream(chemin.c_str(),FMOD_DEFAULT,NULL,&playlist); //ou CREATESOUND A VOIR
	verifErreur();
	
	valRetour=playlist->getNumTags(&nbMorceaux,NULL);
	verifErreur();
	
	
	cheminTMP=strcpy(cheminTMP,chemin.c_str());
	ptrChaineTMP=strtok(cheminTMP,"/");
	
	while((ptrChaineTMP=strtok(NULL,"/")) != NULL)
		ptrChaine=ptrChaineTMP;
	printf("souschaine: %s\n",ptrChaine);
	
	//chemin est maintenant égale au chemin du dossier contenant la playlist
	chemin.erase(chemin.find(ptrChaine),strlen(ptrChaine));

	for(numMorceau=0;numMorceau<nbMorceaux;numMorceau++)
	{
		valRetour=playlist->getTag("FILE",numMorceau,&tag);
		verifErreur();
		chemin=chemin+(char *)tag.data;
		listeCheminMorceau.push_back(chemin);
	}
	playlist->release();
	
	return listeCheminMorceau;
}

string Fmod::getTagInfo(string chemin,unsigned int info)
{
	int numTags;
	FMOD_TAG tag;
	tag.data=NULL;
	FMOD::Sound *morceau_;
	
	valRetour=system->createStream(chemin.c_str(),FMOD_DEFAULT,NULL,&morceau_);
	//pas de test d'erreur car ce ne serait pas des erreurs critiques
	
	valRetour=morceau_->getNumTags(&numTags,NULL);
	//pas de test d'erreur car ce ne serait pas des erreurs critiques
	
	if(numTags != 0)//evite un grand nombre d'acces disque
	{
		switch(info)
		{
			case TITRE:   		 valRetour=morceau_->getTag("TITLE",0,&tag);break;
			case ARTISTE: 		 valRetour=morceau_->getTag("ARTIST",0,&tag);break;
			case ALBUM:   		 valRetour=morceau_->getTag("ALBUM",0,&tag);break;
			case ANNEE:    		 valRetour=morceau_->getTag("YEAR",0,&tag);break;
			case STYLE:			 valRetour=morceau_->getTag("GENRE",0,&tag);break;
			case COMMENTAIRE:    valRetour=morceau_->getTag("COMMENT",0,&tag);break;
			//case TAGTYPE: 		 
		}
		//on ne teste pas le code de retour car une sortie serait declenché dés 
		//le 1er tag abscent
	}
	
	morceau_->release();
	
	if(tag.data == NULL)
		return "";
	else
		return (char *) tag.data;
}

unsigned int Fmod::getInfoMorceau(string chemin,unsigned int info)
{
	FMOD::Sound *morceau_;
	unsigned int valeur=0;
	
	valRetour=system->createStream(chemin.c_str(),FMOD_DEFAULT,NULL,&morceau_);
	verifErreur();
	
	switch(info)
	{
		case DUREE: 
		{
			valRetour=morceau_->getLength(&valeur,FMOD_TIMEUNIT_MS);
			valeur=valeur/1000;
			break;
		}
		case DEBIT: valeur=0;break;//A FINIR

		case ECHANTILLONNAGE: valeur=0;break;//A FINIR
		//case TYPE: morceau->getFormat()
	}
	verifErreur();
	morceau_->release();
	return valeur;
}

// egale 0.0, tout a gauche -1.0 a droite 1.0
void Fmod::setHpBalance(int balance_)
{
	if(getLectureActive())
	{
 		valRetour = canal->setPan((float)balance_/100);
		verifErreur();
	}
		balance=balance_;
}

//retourne balance hp
int Fmod::getBalance()
{
	return balance;
}

//Coupe/retablit le son
void Fmod::muet()
{
	if(getLectureActive())
	{
		valRetour=canal->setMute(!mute);
		verifErreur();	
	}
	mute=!mute;
	
}

//definit a cb de seconde s'effectue la lecture
void Fmod::setPositionIndicateur(unsigned int position)
{
	valRetour=canal->setPosition(position*1000,FMOD_TIMEUNIT_MS);
	verifErreur();
}

//retourne cb de secondes sont ecoulés depuis le debut du morceau
unsigned int Fmod::getPositionIndicateur()
{
	unsigned int position;
	valRetour=canal->getPosition(&position,FMOD_TIMEUNIT_MS);
	verifErreur();
	return position/1000;
}

//////////////////////////////////////////////
//FONCTION SPECIFIQUE A LA LECTURE DE FLUX WEB
//////////////////////////////////////////////

void Fmod::playFluxWeb(string url)
{
	
	//On crée un buffer afin d'eviter les lags
	valRetour = system->setStreamBufferSize(64*1024, FMOD_TIMEUNIT_RAWBYTES);
   	verifErreur();
	
	//FMOD_CREATESTREAM: decompression en temps reel
    valRetour = system->createSound(url.c_str(),FMOD_HARDWARE | FMOD_2D | FMOD_CREATESTREAM | FMOD_NONBLOCKING,0,&morceau);
   	verifErreur();
	
	valRetour = system->playSound(FMOD_CHANNEL_FREE, morceau, false, &canal);
	verifErreur();
}

string Fmod::affEtatOuverture()
{
	string etat;
	valRetour = morceau->getOpenState(&etatOuverture, NULL, NULL);
	verifErreur();
	
	switch(etatOuverture)
	{
		case FMOD_OPENSTATE_READY: 		etat="Pret";break;
		case FMOD_OPENSTATE_LOADING:    etat="Chargement en cours...";break;
		case FMOD_OPENSTATE_ERROR:		etat="Erreur";break;
		case FMOD_OPENSTATE_CONNECTING: etat="Connexion en cours...";break;
		case FMOD_OPENSTATE_BUFFERING:  etat="Remplissage du buffer...";break;
		case FMOD_OPENSTATE_SEEKING:    etat="Nettoyage du buffer...";break;
		default: etat="???";break;
	}
	return etat;
}

unsigned int Fmod::affPourcentageDsBuffer()
{
	valRetour = morceau->getOpenState(NULL, &pourcentageDsBuffer, NULL);
	verifErreur();
	return pourcentageDsBuffer;
}

string Fmod::affFamine()
{
	valRetour = morceau->getOpenState(NULL, NULL, &famine );
	verifErreur();
	if(famine)
		return "Rupture de flux!";
	else
		return "";
}


////////////////////////////////////////////
//////VISUALISATION OPEN GL
////////////////////////////////////////////

void visuHistogramme2D(float spectre[],GLuint idTexture[])
{
		unsigned int i,x;
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
		glMatrixMode( GL_MODELVIEW );
		glLoadIdentity( );//reinitialisation de la matrice
	
	
		gluLookAt(6, 2, 3, 0, 0, 0, 0, 0, 1); //positionne la camera et l'oriente
	
		for(i=0; i<4;++i)
		{
			if(i==0)
				x=-2.5;
			else 
			{
				if(i==1)
					x=-1;
				else 
				{
					if(i==2)
					 	x=0.5;
				 	else
						x=2;
				}
			}
					
			glBegin(GL_QUADS);	
			glColor3ub(255,0,255); glTexCoord2d(0,1); glVertex3d(x+1,x+0.5,spectre[i]);
			glColor3ub(255,0,255); glTexCoord2d(0,0); glVertex3d(x+1,x+0.5,-1);
			glColor3ub(255,0,255); glTexCoord2d(1,0); glVertex3d(x,x+0.5,-1);
			glColor3ub(255,0,255); glTexCoord2d(1,1); glVertex3d(x,x+0.5,spectre[i]);
			glEnd();
			
			glBegin(GL_QUADS);
			glColor3ub(255,0,0); glTexCoord2d(0,1); glVertex3d(x+1,x-0.5,spectre[i]);//haut-gauche   
			glColor3ub(255,0,0); glTexCoord2d(0,0); glVertex3d(x+1,x-0.5,-1);//bas-gauche
			glColor3ub(255,0,0); glTexCoord2d(1,0); glVertex3d(x+1,x+0.5,-1);//bas-droite
			glColor3ub(255,0,0); glTexCoord2d(1,1); glVertex3d(x+1,x+0.5,spectre[i]);//haut-droit
			glEnd();
			
			glBegin(GL_QUADS);
			glColor3ub(255,125,255); glTexCoord2d(0,1); glVertex3d(x,x-0.5,spectre[i]);
			glColor3ub(255,125,255); glTexCoord2d(0,0); glVertex3d(x,x-0.5,-1);
			glColor3ub(255,125,255); glTexCoord2d(1,0); glVertex3d(x+1,x-0.5,-1);
			glColor3ub(255,125,255); glTexCoord2d(1,1); glVertex3d(x+1,x-0.5,spectre[i]);
			glEnd();
			
			glBegin(GL_QUADS); 
			glColor3ub(125,255,255); glTexCoord2d(0,1); glVertex3d(x,x+0.5,spectre[i]);
			glColor3ub(125,255,255); glTexCoord2d(0,0); glVertex3d(x,x+0.5,-1);
			glColor3ub(125,255,255); glTexCoord2d(1,0); glVertex3d(x,x-0.5,-1);
			glColor3ub(125,255,255); glTexCoord2d(1,1); glVertex3d(x,x-0.5,spectre[i]);
			glEnd();
			
			glBegin(GL_QUADS);
			glColor3ub(255,255,125); glTexCoord2d(0,1); glVertex3d(x+1,x+0.5,-1);
			glColor3ub(255,255,125); glTexCoord2d(0,0); glVertex3d(x+1,x-0.5,-1);
			glColor3ub(255,255,125); glTexCoord2d(1,0); glVertex3d(x,x-0.5,-1);
			glColor3ub(255,255,125); glTexCoord2d(1,1); glVertex3d(x,x+0.5,-1);
			glEnd();
			
			glBegin(GL_QUADS);
			glColor3ub(125,125,255); glTexCoord2d(0,1); glVertex3d(x+1,x-0.5,spectre[i]);
			glColor3ub(125,125,255); glTexCoord2d(0,0); glVertex3d(x+1,x+0.5,spectre[i]);
			glColor3ub(125,125,255); glTexCoord2d(1,0); glVertex3d(x,x+0.5,spectre[i]);
			glColor3ub(125,125,255); glTexCoord2d(1,1); glVertex3d(x,x-0.5,spectre[i]);
			glEnd();
		}
}

void visuHistogramme3D(float spectre[],GLuint idTexture[])
{
			//vaire variation aléatoire de couleur
			glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//Nettoyage des buffers

			glMatrixMode( GL_MODELVIEW );
			glLoadIdentity( );//reinitialisation de la matrice
	
			gluLookAt(3, 4, 2, 0, 0, 0, 0, 0, 1); //positionne la camera et l'oriente
			//gluLookAt( camX, camY, camZ, cibleX, cibleY, cibleZ, vertX, vertY, vertZ );
			
			glRotated(spectre[1]*50,0,0,1);//rotation autour de l'axe Z
			glRotated(spectre[2]*50,1,0,0);//rotation autour de l'axe X
			glRotated(spectre[3]*50,0,1,0);//rotation autour de l'axe Y
			
			glBindTexture(GL_TEXTURE_2D, idTexture[3]);
													   //on change de texture a l'exterieur du bloc glbegin,glend
			glBegin(GL_QUADS);						   //car il est impossible dele faire au cours du dessin de la vertice
			glColor3ub(255,255,255); glTexCoord2d(0,1); glVertex3d(1,1,1);
			glColor3ub(255,255,255); glTexCoord2d(0,0); glVertex3d(1,1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,0); glVertex3d(-1,1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,1); glVertex3d(-1,1,1);
			glEnd();
			
			//Face avant-gauche
			
			glBindTexture(GL_TEXTURE_2D, idTexture[1]);

			glBegin(GL_QUADS);
			glColor3ub(255,255,255); glTexCoord2d(0,1); glVertex3d(1,-1,1);    
			glColor3ub(255,255,255); glTexCoord2d(0,0); glVertex3d(1,-1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,0); glVertex3d(1,1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,1); glVertex3d(1,1,1);
			glEnd();
			
			glBindTexture(GL_TEXTURE_2D, idTexture[5]);
			
			glBegin(GL_QUADS);
			glColor3ub(255,255,255); glTexCoord2d(0,1); glVertex3d(-1,-1,1);
			glColor3ub(255,255,255); glTexCoord2d(0,0); glVertex3d(-1,-1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,0); glVertex3d(1,-1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,1); glVertex3d(1,-1,1);
			glEnd();
			
			glBindTexture(GL_TEXTURE_2D, idTexture[4]);
			
			glBegin(GL_QUADS); 
			glColor3ub(255,255,255); glTexCoord2d(0,1); glVertex3d(-1,1,1);
			glColor3ub(255,255,255); glTexCoord2d(0,0); glVertex3d(-1,1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,0); glVertex3d(-1,-1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,1); glVertex3d(-1,-1,1);
			glEnd();
			
			glBindTexture(GL_TEXTURE_2D, idTexture[2]);
			
			glBegin(GL_QUADS);
			glColor3ub(255,255,255); glTexCoord2d(0,1); glVertex3d(1,1,-1);
			glColor3ub(255,255,255); glTexCoord2d(0,0); glVertex3d(1,-1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,0); glVertex3d(-1,-1,-1);
			glColor3ub(255,255,255); glTexCoord2d(1,1); glVertex3d(-1,1,-1);
			glEnd();
			
			glBindTexture(GL_TEXTURE_2D, idTexture[0]);
			
			glBegin(GL_QUADS);
			glColor3ub(255,255,255); glTexCoord2d(0,1); glVertex3d(1,-1,1);
			glColor3ub(255,255,255); glTexCoord2d(0,0); glVertex3d(1,1,1);
			glColor3ub(255,255,255); glTexCoord2d(1,0); glVertex3d(-1,1,1);
			glColor3ub(255,255,255); glTexCoord2d(1,1); glVertex3d(-1,-1,1);
			glEnd();
}

void *threadVisuOpenGL(void *arg)
{
		
	unsigned int tempsTotal=0;
	unsigned int dureeAffImage=0;
	unsigned int tempsTotalDerniereBoucle=0;
	unsigned int mode=0;
	unsigned int precision=64;//puissance de 2 definissant la precision de l'analyse
	float spectre[precision];//tableau ou sont placés les valeurs de l'analyse
	//FMOD_DSP_FFT_WINDOW_TRIANGLE est la methode de calcul du spectre
	atexit(SDL_Quit);
		
	Fmod *ptrFmod = static_cast<Fmod *>(arg);//converti adresse sur classe fmod en adresse de l'instance de fmod existante

	bool continuer = true;
   	SDL_Event event;
   	SDL_Init(SDL_INIT_VIDEO);
  	SDL_WM_SetCaption("Visualisation",NULL);//titre de la fenetre
	
	SDL_EnableKeyRepeat(10,10);//vitesse de scan des touches..
	SDL_SetVideoMode(640, 480, 32, SDL_OPENGL);//initialise le mode vidéo:resolution + couleurs

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity( );//reinitialisation de la matrice
	gluPerspective(70,(double)640/480,1,1000);
	glEnable(GL_DEPTH_TEST); //active le Z-buffer: definit le modele placé a l'avnat plan
	//angle de 70°,ratio,ozne proche,zone lointaine
	
	//Chargement des textures
	GLuint idTexture[6];
	
	idTexture[0] = loadTexture("./textures/Tux.png");
	idTexture[1] = loadTexture("./textures/tux-matrix.png");
	idTexture[2] = loadTexture("./textures/Tux_Prof.png");
	idTexture[3] = loadTexture("./textures/tux-mixer.gif");
	idTexture[4] = loadTexture("./textures/tux-sangoku.png");
	idTexture[5] = loadTexture("./textures/Tux-faucheur.png");	


   	 for(unsigned int nbImages;continuer;++nbImages)
   	 {
		ptrFmod->getCanal()->getSpectrum(spectre,precision,0,FMOD_DSP_FFT_WINDOW_TRIANGLE);
		
		if(mode==0)
			visuHistogramme2D(spectre,idTexture);//on dessine un histogramme 2D
		else
		{
			if(mode==1)
				visuHistogramme3D(spectre,idTexture);//On dessine un cube 3D
		}
		if(SDL_PollEvent(&event)) //On entre ds ce segment de code seulement si un evenement est apparu
		{
			switch(event.type)
			{
				case SDL_QUIT:
				{
					continuer = false;
					break;
				}
				case SDL_KEYDOWN: //touche enfoncée
				{	
					switch (event.key.keysym.sym)
				  	{
						case SDLK_ESCAPE:
							{continuer = false;break;}
	
						case SDLK_LEFT:
							{					
								mode=0;
								glDisable(GL_TEXTURE_2D);
	
								break;
							}
	
						case SDLK_RIGHT:
							{
								glEnable(GL_TEXTURE_2D);
								mode=1;
								break;
							}

						default:
								break;
					}			
				}
			}

		//on limite l'affichage a 50 FPS
		tempsTotal=SDL_GetTicks();//compteur de temps
		dureeAffImage=tempsTotal-tempsTotalDerniereBoucle;
		if(dureeAffImage <20)
			SDL_Delay(20 - dureeAffImage);
		tempsTotalDerniereBoucle=tempsTotal;
      	  }

		glFlush();//s'assure que toutes les commandes opengl ont été executé
		SDL_GL_SwapBuffers();//????????????????????
		if(!ptrFmod->getLectureActive())
		{
			SDL_Quit();
   			pthread_exit(NULL);
		}
    }
    SDL_Quit();
    pthread_exit(NULL);
}

void Fmod::visualisation()
{
	if(pthread_create(&thread,NULL,threadVisuOpenGL,this) < 0)
		{perror("ERREUR lors de la creation du thread dédié à la visualisation OpenGL\n");exit(-1);}
}
