#ifndef ENSPTRMORCEAU_HPP
#define ENSPTRMORCEAU_HPP

#include "morceau.hpp"
#include "fmod.hpp"
#include <vector>
#include <string>
#include <iostream>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
using namespace std;


#define LISTE vector


/**
 * fonction permettant de tester si un chemin donnee
 * correspond a un fichier de musique
 * ou un fichier m3u
 */
bool estUnFichierDeMusique(const string &chemin, bool fichier_m3u=false);





/**
 * Classe permettant de stocker et generer des pointeurs sur morceau
 * Elle ne sera pas directement instanciee (elle est la classe mere
 * des classes EnsMorceau, Album et Collection )
 */
class EnsPtrMorceau{

protected:
  LISTE<Morceau*> ensMorceau;
   
public:

  /**
   * permet d'ajout une 'connaissance' a la liste,
   * la liste connait un nouveau morceau
   */
  void ajouterMorceau(Morceau* ptrMorceau);

  /**
   * supprime le pointeur sur le ieme morceau
   */
  void supprimerMorceau(int i);

  void afficheNomMorceau();

  /**
   * compte le nombre de morceau present dans la liste
   */
  int nombreDeMorceau();

  /**
   * supprime tous les pointeurs sur morceau de la liste
   */
  void supprimeTout();

  /**
   * teste si un morceau existe dans l'ensemble
   */
  bool existeMorceau(Morceau* m);

  /**
   * retourne un pointeur sur le ieme morceau de l'ensemble
   */
  Morceau*  operator[](int i){
    return ensMorceau[i];
  }

  /**
   * permet de sauvergarder dans le format m3u l'ensemble
   * donc il sauvegarde le chemin mais en plus le titre,
   * l'auteur et l'album
   */
  void sauvegarderM3U(const string &chemin);

  /**
   * affiche les morceaux de l'ensemble
   */
  friend ostream &operator <<(ostream &os, EnsPtrMorceau &ensm){
    int nbMorceau=ensm.nombreDeMorceau();
    for(int i=0;i<nbMorceau;i++)
      os<<i<<". "<<*(ensm[i])<<endl;
    return os;
  }
			   
};


/**
 * La playlist contient une liste de pointeur sur les morceaux
 * selectionne par l'utilisateur et herite d'EnsPtrMorceau et de Fmod
 * En plus d'etre un liste, c'est une liste jouable (play list)
 */
class PlayList : public EnsPtrMorceau,public Fmod
{
private:

  /**
   * rang du morceau courant
   */
  int rang;
	
public:
  PlayList();

  /**
   * permet de lire le morceau courant
   */
  void lireMorceau();

  /**
   * permet de lire le ieme morceau de l'ensemble
   */
  void lireMorceau(int num);
  string getCheminMorceauCourant();

  /**
   * passe au morceau suivant (le rang du morceau courant 
   * est decremente)
   */
  void pistePrecedente();

  /**
   * passe au morceau suivant (le rang du morceau courant 
   * est incremente)
   */
  void pisteSuivante();

  /**
   * met en pause le morceau courant si il est joue
   */
  void pause();
 
};


/**
 * classe permettant de representer un album!
 * ainsi elle connait plusieurs morceaux
 * donc elle herite de ensPtrMorceau
 * la seule chose qu'elle possede en plus de sa
 * classe dont elle herite est le fait qu'elle
 * possede un nom d'album
 */
class Album : public EnsPtrMorceau {
  string nomAlbum;
  
public:
  /**
   * construit l'album a partir du nom de l'album
   */
  Album(const string &nomAlbum);

  string getNomAlbum();

  friend ostream &operator <<(ostream &os, Album &album){
    LISTE<Morceau*> ensMorceau=album.ensMorceau;
    os<<"Album "<<album.nomAlbum<<endl;
        
    int nbMorceau=album.nombreDeMorceau();
    for(int i=0;i<nbMorceau;i++)
      os<<"     "<<i<<". "<<(ensMorceau[i]->getTitre())<<endl;

    return os;
  }

};




/**
 * La classe Auteur possede un ensemble d'album
 *
 */
class Auteur {
  LISTE<Album*> ensAlbum;
  string nomAuteur;
  
public:

  /**
   * la classe se construit a partir du nom de l'auteur
   */
  Auteur(const string &nom){
    nomAuteur=nom;
  }

  string getNomAuteur(){
    return nomAuteur;
  }
  void ajouterMorceauAlbum(Morceau * ptrMorceau, const string &nomAlbum);

  void ajouterAlbum(const string &nom);

  /**
   * foncteur permettant de tester si le nom de l'album est egal
   * a la chaine entree en paramettre
   */
  struct BonNomAlbum : public unary_function<Album*,bool>{
    string nom;
    BonNomAlbum(const string &n):nom(n){};
    
    bool operator()(Album* album){
      return (album->getNomAlbum() == nom);
    };
  };

  /**
   * retourne l'album correspondant a un nom d'album donne
   */
  Album* rechercherPtrAlbum(const string &nomAlbum);

  /**
   * compte le nombre d'album
   */
  int nombreDAlbum();


  friend ostream &operator <<(ostream &os, Auteur &auteur){
    LISTE<Album*> ensAlbum=auteur.ensAlbum;
    LISTE<Album*>::iterator it_Album;
    os<<"Artiste "<<auteur.nomAuteur<<endl;
    for(it_Album=ensAlbum.begin();it_Album!=ensAlbum.end();it_Album++)
      os<<"  "<<**it_Album<<endl;
    return os;
  }

  /**
   * retourne le ieme album
   */
  Album*  operator[](int i){
    return ensAlbum[i];
  }

  /**
   * supprime tout les albums de l'ensemble
   */
  void supprimeTout();

  ~Auteur();


};


/**
 * La classe EnsMorceau est la classe qui possedent physiquement
 * morceaux
 *
 */

class EnsMorceau : public EnsPtrMorceau {
public:

  /**
   * Cette fonction creer le morceau, charge ses tags et
   * ajoute le morceau dans la liste des morceaux
   */
  void ajouterMorceau(const string &chemin);

  /* cette fonction le morceau et
   * ajoute le morceau dans la liste des morceaux
   * mais ne charge pas ses tags car ils sont indiques
   * dans les parametres
   */
  void ajouterMorceau(const string &chemin,const string &titre, const string &auteur, const string &album);

  /**
   * a partir d'un repertoire, cette fonction permettant
   * d'ajouter tous les morceaux appartenant au repertoire ou
   * a des sous-repertoires
   */
  int genererListe(string chemin);

  /**
   * cette fonction permet d'ajouter un fichier m3u a l'ensemble
   */
  void ajouterM3U(const string &chemin);


  /**
   * Supprimer tout les morceaux non present physiquement
   */
  void nettoyer();


  ~EnsMorceau();
};



/**
 * La classe Collection permet de socker des pointeurs sur morceau
 * par Artiste puis par Album
 *
 */
class Collection{
protected:
  LISTE<Auteur*> ensAuteur;
  
public:
  /**
   * generer la collection a partir d'un ensemble de morceau
   */
  void generer(EnsMorceau *ptrEnsMorceau);

  /**
   * ajoute un morceau a la collection
   */
  void ajouterMorceau(Morceau *m);

  /**
   * ajoute un morceau a un auteur donnee
   */
  void ajouterMorceauAuteur(Morceau * ptrMorceau, const string &nomAuteur);

  /**
   * ajoute un auteur a la collection
   */
  void ajouterAuteur(const string &nom);

  /**
   * foncteur permettant de savoir si le nom de l'auteur
   * est celui que l'on veut
   */
  struct BonNomAuteur : public unary_function<Auteur*,bool>{
    string nom;
    BonNomAuteur(const string &n):nom(n){};
    
    bool operator()(Auteur* auteur){
      return (auteur->getNomAuteur() == nom);
    };
  };

  /**
   * retourne un pointeur sur l'auteur en fonction
   * de son nom
   */
  Auteur* rechercherPtrAuteur(const string &nomAuteur);

  /**
   * compte le nom d'auteur present dans la collection
   */
  int nombreDAuteur();

  /**
   * affiche la collection
   */
  friend ostream &operator <<(ostream &os, Collection &col){
    LISTE<Auteur*> ensAuteur=col.ensAuteur;
    LISTE<Auteur*>::iterator itAuteur;
    os<<"Votre collection"<<endl;
    for(itAuteur=ensAuteur.begin();itAuteur!=ensAuteur.end();itAuteur++)
      os<<" "<<**itAuteur<<endl;
    return os;
  }

  /**
   * retourne le ieme auteur de la collection
   */
  Auteur*  operator[](int i){
    return ensAuteur[i];
  }

  ~Collection();

  void supprimeTout();

};

/**
 * foncteur permettant de compter le nombre de morceau
 */
struct CompteMorceau : public unary_function<Morceau*,void>{
  int comptage;
  CompteMorceau():comptage(0){};
  void operator()(Morceau* m){
    m=NULL; //pour enlever warning
    comptage++;
  }
};

/**
 * foncteur permettant de compter le nombre d'album
 */
struct CompteAlbum : public unary_function<Album*,void>{
  int comptage;
  CompteAlbum():comptage(0){};
  void operator()(Album* m){
    m=NULL; //pour enlever warning
    comptage++;
  }
};

/**
 * foncteur permettant de compter le nombre d'auteur
 */
struct CompteAuteur : public unary_function<Auteur*,void>{
  int comptage;
  CompteAuteur():comptage(0){};
  void operator()(Auteur* m){
    m=NULL; //pour enlever warning
    comptage++;
  }
};


#endif
