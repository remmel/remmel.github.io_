#ifndef QFENPRINCIPALE_H
#define QFENPRINCIPALE_H

#include <qvariant.h>
#include <qpixmap.h>
#include <qmainwindow.h>
#include "fenprincipale.h"
#include "qbibliotheque.h"
#include "qlecteur.h"

class QFenPrincipale : public FenPrincipale
{
  Q_OBJECT

    QDialog *apropos;

 public:
  QFenPrincipale( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );



  /**
   * fonction etant servie uniquement dans ajoutMultiple,
   * elle permet d'ajouter a la playlist tous les morceaux
   * surligner (selectionne)
   */
  void scannerMorceau( QListViewItem* item);

  public slots:


 protected:

  protected slots:

    /**
     * fonction permettant d'ajouter les morceaux surligne (= selectionne)
     * de la bibliotheque dans la playlist
     */
    void ajoutMultiple();

  /**
   * fonction permettant de mettre a jour la bibliotheque
   */
  void nettoyer();



  /**
   * slot permettant d'afficher la boite de dialogue a propos
   */
  void showApropos();




  /*
    virtual void ajoutDansPlayList(){
    QFileDialog* fd = new QFileDialog( this, "Choississez vos musiques", TRUE );
    fd->setMode( QFileDialog::ExistingFiles );
    QString fileName;
    if ( fd->exec() == QDialog::Accepted ){
    fileName = fd->selectedFile();
    //lesMorceaux.generer(fd->selectedFile());
    //lesMorceaux.genererListe(fd->selectedFile());
    //generer();
    }
    }*/

  /*QStringList list = myFileDialog.selectedFiles();
    QStringList::Iterator it = list.begin();
    while( it != list.end() ) {
    myProcessing( *it );
    ++it;
    }*/


};

#endif // FENPRINCIPALE_H
