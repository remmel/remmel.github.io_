#ifndef QLECTEUR_H
#define QLECTEUR_H


#include "wlecteur.h"
#include "jukebox.hpp"
#include <qvariant.h>
#include <qpushbutton.h>
#include <qheader.h>
#include <qlistview.h>
#include <qlabel.h>
#include <qstring.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qvbox.h>
#include <qtimer.h>
#include <iostream>
#include <qslider.h>
using namespace std;


enum {TITRE,ARTISTE,ALBUM,ANNEE,STYLE,COMMENTAIRE,TAGTYPE};
enum {DUREE,DEBIT,ECHANTILLONNAGE};

/*
 *  Constructs a Interface as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 */
class QLecteur : public WLecteur,public Jukebox
{
  Q_OBJECT

    private:
	QTimer* timer;
	unsigned int positionSeconde;
	unsigned int nbSecondeMorceau;
    public:
  QLecteur( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 ) : WLecteur(parent,name,fl)
  {
      QString chaineTMP;
      timer= new QTimer();
      positionSeconde=0;
      LABEL_Volume->setText(chaineTMP.setNum(moteurSon.getVolume()));
      
      connect( BTN_Play, SIGNAL( clicked(void) ), this, SLOT( play() ) );
      connect( BTN_Pause, SIGNAL( clicked(void) ), this, SLOT( pause() ) );
      connect( BTN_Stop, SIGNAL( clicked(void) ), this, SLOT( stop() ) );
      connect( BTN_Precedent, SIGNAL( clicked(void) ), this, SLOT( precedent() ) );
      connect( BTN_Suivant, SIGNAL( clicked() ), this, SLOT( suivant() ) );
      connect( BTN_VolumePlus, SIGNAL( clicked() ), this, SLOT( volumePlus() ) );
      connect( BTN_VolumeMoins, SIGNAL( clicked() ), this, SLOT( volumeMoins() ) );
      connect( BTN_Muet, SIGNAL( clicked() ), this, SLOT( volumeMuet() ) );
      connect( (QObject*)POTENTIO_Balance, SIGNAL( valueChanged(int) ), this, SLOT( balance(int) ) );
      connect((QObject*)timer, SIGNAL(timeout()), this,SLOT(affichagePosition() ));
      connect((QObject*)SLIDER_Position, SIGNAL(sliderMoved(int)), this,SLOT(modifierPosition(int) ));
  }
  
  ~QLecteur( )
  {
      delete(timer);
  }

      signals:

  
  
  protected slots:
    virtual void languageChange(){}
    
    virtual void play()
    {	
	QString chaine=" / ",chaineTMP;
	unsigned int minute=0,seconde,heure=0;

	if(moteurSon.getLectureActive())
	    stop();
	
	nbSecondeMorceau=moteurSon.getInfoMorceau("/tmp/1.mp3",DUREE);
	SLIDER_Position->setMaxValue(nbSecondeMorceau);
	
	if(nbSecondeMorceau >=60)
	    minute=(nbSecondeMorceau/60);
	if(minute>=60)
	{
	    heure=minute/60;
	    minute-=heure*60;
	}
	seconde=(nbSecondeMorceau-minute*60);
	
	if(heure !=0)
	    chaine+=chaineTMP.setNum(heure)+" : ";
	chaine+=chaineTMP.setNum(minute)+" : ";
	chaine+=chaineTMP.setNum(seconde);  
	
	LABEL_AffDuree->setText(chaine);
	LABEL_Artiste->setText(moteurSon.getTagInfo("/tmp/1.mp3",ARTISTE));
	LABEL_Titre->setText(moteurSon.getTagInfo("/tmp/1.mp3",TITRE));
	
	timer->start(1000);//timer declencher toutes les secondes
	moteurSon.play("/tmp/1.mp3");

     }
    
        virtual void pause()
       {
	    if( moteurSon.getLectureActive() )
	    {
		if(moteurSon.getPauseActive())
		    timer->start(1000);
		else
		    timer->stop();
	    	 moteurSon.pause();
	     }
      }
		
       virtual void stop()
       {
	    if( moteurSon.getLectureActive() )
	    {
		timer->stop();
		positionSeconde=0;
		affichagePosition();
		moteurSon.stop();
	    }
      }
       
       virtual void suivant()
       {
	    if( moteurSon.getLectureActive() )
		stop();
	    qWarning("suivant");
	    //play( morceau suivant playlist);
	    
      }
	      
	      virtual void precedent()
       {
                    if( moteurSon.getLectureActive() )
		stop();
	    qWarning("precedent");
	   //play( morceau precedent playlist);
      }
	      
	     virtual void balance(int valeur)
       {	 
	  moteurSon.setHpBalance(valeur);
	          
      }

	     virtual void affichagePosition()
       {	 
	QString chaine,chaineTMP;
	unsigned int minute=0,seconde,heure=0;
	
	
	 SLIDER_Position->setValue(positionSeconde);
	
	if(positionSeconde >=60)
	    minute=(positionSeconde/60);
	if(minute>=60)
	    heure=minute/60;
	seconde=(positionSeconde-minute*60);
	if(heure !=0)
	    chaine=chaineTMP.setNum(heure)+" : ";
	chaine+=chaineTMP.setNum(minute)+" : ";
	chaine+=chaineTMP.setNum(seconde);

	 LABEL_AffPosition->setText(chaine);
	 if(positionSeconde >= nbSecondeMorceau)
	     stop();
	 positionSeconde++;
      }
	     
	     virtual void modifierPosition(int position)
       {	 
	if(moteurSon.getLectureActive())
	{
	    moteurSon.setPositionIndicateur(position);
	    positionSeconde=position;
	}
	 
      } 

	     virtual void volumePlus()
       {	 
	  QString chaineTMP;
	  moteurSon.augmenterVolume(10);   
	  LABEL_Volume->setText(chaineTMP.setNum(moteurSon.getVolume()));
      }
		     
	  virtual void volumeMoins()
       {	 
	  QString chaineTMP;
	  moteurSon.reduireVolume(10);
	  LABEL_Volume->setText(chaineTMP.setNum(moteurSon.getVolume()));
	          
      }
			     
	 virtual void volumeMuet()
       {	 
	   QString chaineTMP;
	  static bool etat=false;
	  moteurSon.muet();
	  etat=!etat;
	  if(etat)
	       LABEL_Volume->setText("Muet");
	  else
	       LABEL_Volume->setText(chaineTMP.setNum(moteurSon.getVolume()));
	          
      }
  
};




#endif
