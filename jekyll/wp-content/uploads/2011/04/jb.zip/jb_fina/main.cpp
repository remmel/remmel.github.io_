#include <iostream>
#include <string>
#include "ensPtrMorceau.hpp"
#include <deque>
#include <list>
#include <qapplication.h>
#include "fenprincipale.h"
#include "qfenprincipale.h"

//pour tester si le fichier est un repertoire
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main( int argc, char * argv[] )
{
	int i;
	bool fichierCharge=false;
    if(argc ==2)
    {
		if(strcmp(argv[1],"-g") == 0)
		{
		  QApplication a( argc, argv );
		  QFenPrincipale w;
		  w.show();
		  a.connect(&a,SIGNAL(lastWindowClosed()),&a,SLOT(quit()));			
		  return a.exec();
		}
		
		if(strcmp(argv[1],"-t") == 0)
		{
			EnsMorceau lesMorceaux;
			PlayList playlist;
			char car;
			  cout<<"############################################################"<<endl;
			  cout<<"#####################   Jukebox V1.0   #####################"<<endl;
			  cout<<"############################################################"<<endl;
			  cout<<"######  Réalisé par: Nestelhut Damien et Mellet Remy   #####"<<endl;
			  cout<<"############################################################"<<endl<<endl;
			  cout<<"Liste des commandes:"<<endl;
			  cout<<"p - pause/play   a - affiche la playlist"<<endl; 
			  cout<<"b - precedent    c - charger un morceau ou une playlist"<<endl;
			  cout<<"n - suivant      s - stop"<<endl;
			  cout<<"q - quitter"<<endl;
			do
			{
				cout<<">";
				cin>>car;
				if(car=='c')
				{
				  string chemin;
				  
				  cout<<"rentrez le chemin du morceau ou de la playlist"<<endl;
				  cin>>chemin;
				  
				int fd=open(chemin.c_str(),0);
				if(fd!=-1)
				{
					fichierCharge=true;
					close(fd);
					fd=open(chemin.c_str(), O_DIRECTORY);
					if(fd!=-1)//le chemin represente un repertoire
					{
					  cout<<"ajout d'un repertoire..."<<endl;
					  lesMorceaux.genererListe(chemin);
					}
					else//le chemin represente un fichier
					{ 
						close(fd);
						if(estUnFichierDeMusique(chemin))
						{
							cout<<"ajout d'un morceau..."<<endl;
							lesMorceaux.ajouterMorceau(chemin);
						}
						if(estUnFichierDeMusique(chemin,true))//si le fichier est une m3u
						{ 
							cout<<"ajout de la playlist..."<<endl;
							list<string> listeChemin;
							//listeChemin=playlist.chargerPlaylist(chemin);
							//list<string>::iterator it=listeChemin.begin();
							//for(it=listeChemin.begin();it!=listeChemin.end();it++)
							//  lesMorceaux.ajouterMorceau(*it);
						}
					}
					 
					int nbMorceau=lesMorceaux.nombreDeMorceau(); 
					//playlist.viderEnsemble();
					for(int i=0;i<nbMorceau;i++)
					  playlist.ajouterMorceau(lesMorceaux[i]); 
					}
				}
				
				if(car=='p')
				{
					if(fichierCharge)
					{
						if(playlist.getLectureActive())
							playlist.pause();
						else
						{
							cout<<"Indice du morceau souhaité:"<<endl;
							
							cin>>i;
							cout<<"lecture..."<<endl;
							playlist.lireMorceau(i);
						}
					}
					else
						cout<<"Ajoutez d'abord un morceau."<<endl;
				}
				if(car=='a')
				  cout<<playlist<<endl;
				
				if(car=='s')
				{
					playlist.stop();	
				}	

				if(car=='b')
				{
					if(fichierCharge)
					{
						cout<<"Morceau precedent..."<<endl;
						playlist.pistePrecedente();
					}
				}		
				
				
				if(car=='n')
				{
					if(fichierCharge)
					{
						cout<<"Morceau Suivant..."<<endl;
						playlist.pisteSuivante();
					}
				}	
			}
			while(car != 'q');
		}
	}
	else
	{
		cout<<"Jukebox V1.0"<<endl;
 		cout<<" - pour lancer le jukebox en mode texte tapez jb -t"<<endl;
  		cout<<" - pour lancer le jukebox en mode graphique tapez jb -g"<<endl;		
	}
  	return 0;
}
