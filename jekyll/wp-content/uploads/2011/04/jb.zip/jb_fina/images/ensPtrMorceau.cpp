#include "ensPtrMorceau.hpp"
#define LISTE vector


/****************************** ENSPTRMORCEAU ***************/

void EnsPtrMorceau::ajouterMorceau(Morceau* ptrMorceau){
  ensMorceau.push_back(ptrMorceau);
}

Morceau* EnsPtrMorceau::trouverMorceau(int i){
  return ensMorceau[i];
}

int EnsPtrMorceau::nombreDeMorceau(){
  CompteMorceau nb;
  nb=for_each(ensMorceau.begin(),ensMorceau.end(),nb);
  return nb.comptage;
}

void EnsPtrMorceau::supprimerMorceau(int i){
  LISTE<Morceau*>::iterator it=ensMorceau.begin();
  for(int j=0;j!=i || it!=ensMorceau.end();j++)
    it++;
  if(it!=ensMorceau.end())
    ensMorceau.erase(it);
  else cout<<"rang trop grand\n";
}

void EnsPtrMorceau::afficheNomMorceau(){
  LISTE<Morceau*>::iterator it=ensMorceau.begin();
  for(it=ensMorceau.begin();it!=ensMorceau.end();it++)
    cout<<(*it)->getTitre()<<endl;
}


/********************************* ENSMORCEAU **************/

void EnsMorceau::ajouterMorceau(const string &chemin){
    
  Morceau *m=new Morceau(chemin);
  m->chargerTAG(); // a mettre dans collection
  EnsPtrMorceau::ajouterMorceau(m);
}

int EnsMorceau::genererListe(string chemin)
{
	struct dirent *ptrEntreeRep;
	DIR *ptrRep;
	static unsigned int idFichier;

	if( (ptrRep=opendir(chemin.c_str()) ) == NULL )
		{perror("ERREUR lors du parcours. Le repertoire est introuvable");return -1;}//faire message erreur graphique...exception????

	while((ptrEntreeRep=readdir(ptrRep)) != NULL)//readdir permet le passage a l'entrée suivante
	{	
		//Si l'entree est un repertoire on le parcours
		if(strcmp(ptrEntreeRep->d_name,".") && strcmp(ptrEntreeRep->d_name ,"..") )
		{
			if( (ptrEntreeRep->d_type == DT_DIR))
			{
				string cheminSousRep=chemin+ptrEntreeRep->d_name+"/";	
				genererListe(cheminSousRep);
			}
			else
			{	
				string chaineTMP=(ptrEntreeRep->d_name);
				if(chaineTMP.length() >= 5)
				{
					string extension(chaineTMP,chaineTMP.length()-4);
					if(extension == ".mp3" || extension == ".ogg" || extension == ".MP3" ||extension == ".OGG" )
					{	
						cout<<chemin<<ptrEntreeRep->d_name<<endl;
						ajouterMorceau(chemin+ptrEntreeRep->d_name);
						idFichier++;
					}
				}
			}
		}
	}
	closedir(ptrRep);
	return idFichier;
}



/********************************* PLAYLIST ***************/

PlayList::PlayList():rang(0){};
	



/*GetMorceauActuel();*/

void PlayList::lireMorceau()
{
		play( ensMorceau[rang]->getChemin());
}

unsigned int PlayList::getRang()
{
	return rang;
}

void PlayList::setRang(unsigned int rang_)
{
	rang=rang_;
}

string PlayList::getCheminMorceauCourant()
{
	return ensMorceau[rang]->getChemin();
}

/******************************** AUTEUR *******************/

void Auteur::ajouterMorceauAlbum(Morceau * ptrMorceau, const string &nomAlbum){
  //chercher l'album
  Album *album=rechercherPtrAlbum(nomAlbum);

  //s'il n'existe pas on le cree
  if(album==NULL){
    ajouterAlbum(nomAlbum);
    album=rechercherPtrAlbum(nomAlbum);
    }
  
  //ajouter le morceau a l'Album
  album->ajouterMorceau(ptrMorceau);
  
}

void Auteur::ajouterAlbum(const string &nom){
  Album *ptrAlbum=new Album(nom);
  ensAlbum.push_back(ptrAlbum);
}

int Auteur::nombreDAlbum(){
  CompteAlbum nb;
  nb=for_each(ensAlbum.begin(),ensAlbum.end(),nb);
  return nb.comptage;
}
Album* Auteur::rechercherPtrAlbum(const string &nomAlbum){
  BonNomAlbum bonNom(nomAlbum);
  LISTE<Album*>::iterator it_album;
  it_album=find_if(ensAlbum.begin(),ensAlbum.end(),bonNom);// pb ne marche pas!
  if(it_album==ensAlbum.end()) return NULL;
  else return *it_album;

  /*for(it_album=ensAlbum.begin();it_album!=ensAlbum.end();it_album++){
    cout<<"ok"<<endl;
    if(((*it_album)->getNomAlbum())==nomAlbum){
      cout<<"trouve album"<<endl;
      return *it_album;
      }
      }
      return NULL;
*/
  
}


/****************************** COLLECTION ***************/

void Collection::generer(EnsMorceau *ptrEnsMorceau){
 
  Morceau *m;
  int nbMorceau=ptrEnsMorceau->nombreDeMorceau();
  for(int rang=0;rang<nbMorceau;rang++){
    m=ptrEnsMorceau->trouverMorceau(rang);
    if(m==NULL){
      cout<<"erreur inconnu, ptr null"<<endl;
      exit(0);
    }

    Morceau p(*m);
    //cout<<m->getNomAuteur()<<endl;
    ajouterMorceauAuteur(m,m->getNomAuteur());
  }
}
    

void Collection::ajouterMorceauAuteur(Morceau *ptrMorceau,const string& nomAuteur){
  cout<<nomAuteur<<endl;
  Auteur *auteur=rechercherPtrAuteur(nomAuteur);
  if(auteur==NULL){
    ajouterAuteur(nomAuteur);
    auteur=rechercherPtrAuteur(nomAuteur);
    }

  //on ajoute a un auteur donnee son morceau
  auteur->ajouterMorceauAlbum(ptrMorceau,ptrMorceau->getNomAlbum());
}


void Collection::ajouterAuteur(const string &nom){
  Auteur *ptrAuteur=new Auteur(nom);
  ensAuteur.push_back(ptrAuteur);
}


Auteur* Collection::rechercherPtrAuteur(const string &nomAuteur){
  BonNomAuteur bonNom(nomAuteur);
  LISTE<Auteur*>::iterator it_auteur;
  it_auteur=find_if(ensAuteur.begin(),ensAuteur.end(),bonNom);
  /*for(it_auteur=ensAuteur.begin();it_auteur!=ensAuteur.end();it_auteur++){
cout<<"i"<<endl;
}*/
  //return NULL;
  if(it_auteur==ensAuteur.end()) return NULL;
    else return *it_auteur;
  //return NULL;
}

int Collection::nombreDAuteur(){
  CompteAuteur nb;
  nb=for_each(ensAuteur.begin(),ensAuteur.end(),nb);
  return nb.comptage;
}
