#ifndef ENSPTRMORCEAU_HPP
#define ENSPTRMORCEAU_HPP

#include "morceau.hpp"
#include "fmod.hpp"
#include <vector>
#include <string>
#include <iostream>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
using namespace std;


#define LISTE vector




/**
 * Classe permettant de stocker et generer des pointeurs sur morceau
 * Elle ne sera pas directement instanciee (elle est la classe mere
 * des classes EnsMorceau, Album et Collection )
 */
class EnsPtrMorceau{

protected:
  LISTE<Morceau*> ensMorceau;
   
public:
  void ajouterMorceau(Morceau* ptrMorceau);

  Morceau* trouverMorceau(int i);

  void supprimerMorceau(int i);

  void afficheNomMorceau();
  int nombreDeMorceau();

  Morceau*  operator[](int i){
    return ensMorceau[i];
  }

  friend ostream &operator <<(ostream &os, EnsPtrMorceau &ensm){
    int nbMorceau=ensm.nombreDeMorceau();
    for(int i=0;i<nbMorceau;i++)
      os<<i<<". "<<(ensm[i])<<endl;
    return os;
  }
			   
};

/**
 * La playlist contient une liste de pointeur sur les morceaux
 * selectionne par l'utilisateur
 *
 */
class PlayList : public EnsPtrMorceau,public Fmod
{
private:
	unsigned int rang;
	
public:
  PlayList();
  /*GetMorceauActuel();*/
  unsigned int getRang();
  void setRang(unsigned int rang_); 
  void lireMorceau();
  string getCheminMorceauCourant();

   //void ajouterAlbum(Album*);
   //void ajouterAuteur(Auteur*);

};


class Album : public EnsPtrMorceau 
{
  string nomAlbum;
  
public:
  Album(const string &nom){
     nomAlbum=nom;
  }

  string getNomAlbum(){
    return nomAlbum;
  }

  friend ostream &operator <<(ostream &os, Album &album)
  {
    LISTE<Morceau*> ensMorceau=album.ensMorceau;
    os<<"Album "<<album.nomAlbum<<endl;
        
    int nbMorceau=album.nombreDeMorceau();
    for(int i=0;i<nbMorceau;i++)
      os<<"     "<<i<<". "<<(ensMorceau[i]->getTitre())<<endl;

    return os;
  }



};




/**
 * classe Auteur
 *
 */
class Auteur {
  LISTE<Album*> ensAlbum;
  string nomAuteur;
  
public:

  Auteur(const string &nom){
     nomAuteur=nom;
  }

  string getNomAuteur(){
    return nomAuteur;
  }
  void ajouterMorceauAlbum(Morceau * ptrMorceau, const string &nomAlbum);

  void ajouterAlbum(const string &nom);

  struct BonNomAlbum : public unary_function<Album*,bool>{
    string nom;
    BonNomAlbum(const string &n):nom(n){};
    
    bool operator()(Album* album){
      return (album->getNomAlbum() == nom);
    };
  };

  Album* rechercherPtrAlbum(const string &nomAlbum);

  int nombreDAlbum();


  friend ostream &operator <<(ostream &os, Auteur &auteur){
    LISTE<Album*> ensAlbum=auteur.ensAlbum;
    LISTE<Album*>::iterator it_Album;
    os<<"Artiste "<<auteur.nomAuteur<<endl;
    for(it_Album=ensAlbum.begin();it_Album!=ensAlbum.end();it_Album++)
      os<<"  "<<**it_Album<<endl;
    return os;
  }

  Album*  operator[](int i){
    return ensAlbum[i];
  }


};


/**
 * La classe EnsMorceau est la classe qui possedent physiquement
 * morceaux
 *
 */

class EnsMorceau : public EnsPtrMorceau {
  public:

  /**
   * Cette fonction creer le morceau, charge ses tags et
   * ajoute le morceau dans la liste des morceaux
   */
  void ajouterMorceau(const string &chemin);
  int genererListe(string chemin);
};

/**
 * La classe Collection permet de socker des pointeurs sur morceau
 * par Artiste puis par Album
 *
 */
class Collection{
protected:
  LISTE<Auteur*> ensAuteur;
  
public:
  void generer(EnsMorceau *ptrEnsMorceau);
  void ajouterMorceau(Morceau *m);

  void ajouterMorceauAuteur(Morceau * ptrMorceau, const string &nomAuteur);

  void ajouterAuteur(const string &nom);

  struct BonNomAuteur : public unary_function<Auteur*,bool>{
    string nom;
    BonNomAuteur(const string &n):nom(n){};
    
    bool operator()(Auteur* auteur){
      return (auteur->getNomAuteur() == nom);
    };
  };

  Auteur* rechercherPtrAuteur(const string &nomAuteur);

 int nombreDAuteur();

  friend ostream &operator <<(ostream &os, Collection &col){
    LISTE<Auteur*> ensAuteur=col.ensAuteur;
    LISTE<Auteur*>::iterator itAuteur;
    os<<"Votre collection"<<endl;
    for(itAuteur=ensAuteur.begin();itAuteur!=ensAuteur.end();itAuteur++)
      os<<" "<<**itAuteur<<endl;
    return os;
  }

  Auteur*  operator[](int i){
    return ensAuteur[i];
  }

};


struct CompteMorceau : public unary_function<Morceau*,void>{
  int comptage;
  CompteMorceau():comptage(0){};
  void operator()(Morceau* m){
    comptage++;
  }
};

struct CompteAlbum : public unary_function<Album*,void>{
  int comptage;
  CompteAlbum():comptage(0){};
  void operator()(Album* m){
    comptage++;
  }
};

struct CompteAuteur : public unary_function<Auteur*,void>{
  int comptage;
  CompteAuteur():comptage(0){};
  void operator()(Auteur* m){
    comptage++;
  }
};






#endif
