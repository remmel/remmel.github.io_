#ifndef QLECTEUR_H
#define QLECTEUR_H

#include "wlecteur.h"
#include "ensPtrMorceau.hpp"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qheader.h>
#include <qlistview.h>
#include <qlabel.h>
#include <qstring.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qvbox.h>
#include <qtimer.h>
#include <iostream>
#include <qslider.h>
#include <qcheckbox.h>
#include <stdlib.h>
using namespace std;

enum {TITRE,ARTISTE,ALBUM,ANNEE,STYLE,COMMENTAIRE,TAGTYPE};
enum {DUREE,DEBIT,ECHANTILLONNAGE};

/**
 * Classe QMorceau, c'est un morceau en mode graphique!
 * Herite de la classe QListViewItem et connait un morceau
 */
class QMorceau : public QListViewItem{
  Morceau* ptrMorceau;
  bool inexist;

 public:
  QMorceau(QListView * parent,Morceau* m,int num):QListViewItem(parent),ptrMorceau(m){
    char nb[8];
    sprintf(nb,"%d",num);
    setText( 0, nb); num++;
    setText( 1, ( m->getTitre().c_str() ) );
    setText( 2, ( m->getNomAuteur().c_str() ) );
    setText( 3, ( m->getNomAlbum().c_str() ) );
    inexist=false;

  }

  QMorceau(QListView* parent,Morceau*m):QListViewItem(parent),ptrMorceau(m){
    setText( 0, ( m->getTitre().c_str() ) );
    setText( 1, ( m->getNomAuteur().c_str() ) );
    setText( 2, ( m->getNomAlbum().c_str() ) );
  }

  QMorceau(QListViewItem* parent,Morceau*m):QListViewItem(parent),ptrMorceau(m){
    setText(  0, ( m->getTitre().c_str() ) );
  }
  

  Morceau* getMorceau(){
    return ptrMorceau;
  }

  bool inexistant(){
	return inexist;
}


  /**
   * Cette fonction permet de selectionner
   * le morceau en cours de lecture
   */
  void selection(bool estSelection){
    setSelected(estSelection);
    if(inexist==false)
    if(estSelection)
      setText( 1, ( ("> "+ptrMorceau->getTitre()).c_str()));
    else
      setText( 1, ( (ptrMorceau->getTitre()).c_str()));
  }

  void morceauInexistant(){
   inexist=true;
   cout<<"morceau inexistant"<<endl;
    setText( 1, ( ("/!\\ "+ptrMorceau->getTitre()).c_str()));
  }


  /**
   * Permet de comparer 2 morceaux.
   * deux morceaux sont egaux s'ils ont le meme chemin
   */
  bool operator==(QMorceau &m){
    return ( m.getMorceau()->getChemin() == ptrMorceau->getChemin() );
  }

};




class QLecteur : public WLecteur, public PlayList
{
  Q_OBJECT
    QPopupMenu* menu;
  QAction* playListSupprimer;
  QAction* playListSupprimerSelect;
  QAction* playListSupprimerTout;
  QListViewItem* itemPopup;
  QMorceau* morceauCourant;
  int nbQMorceau;

 private:
  QTimer* timer;
 //  int visualisationActiver;
  unsigned int positionSeconde;
  unsigned int nbSecondeMorceau;
 public:

  QLecteur( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 ) : WLecteur(parent,name,fl)
    {
      ////////////////////////
      //PLAYLIST
      ////////////////////////

      nbQMorceau=0;
      /*largeur des colonnes (pas de redimention auto + fixe dimension par defaut)*/
      playlist->setColumnWidthMode(1,QListView::Manual);
      playlist->setColumnWidthMode(2,QListView::Manual);
      playlist->setColumnWidthMode(3,QListView::Manual);
      playlist->setColumnWidth (1, 100);
      playlist->setColumnWidth (2, 100);
      playlist->setColumnWidth (3, 100);
      //playlist->setSorting (-1,TRUE);

      /*initialisation du popop (popup clic droit sur un morceau) */
      itemPopup=NULL;
      menu=new QPopupMenu(this);
      playListSupprimer= new QAction( this, "fileSaveAction" );
      playListSupprimerSelect = new QAction( this, "playListPlay" );
      playListSupprimerTout = new QAction( this, "supprtout" );
      //Supprimer
      playListSupprimer->setText( tr( "Supprimer" ) );
      playListSupprimer->setMenuText( tr( "&Supprimer" ) );
      playListSupprimer->addTo( menu );
      //Supprimer Selection
      playListSupprimerSelect->setText( tr( "Supprimer selection" ) );
      playListSupprimerSelect->setMenuText( tr( "S&upprimer selection" ) );
      playListSupprimerSelect->addTo( menu );
      //Supprimer tout
      playListSupprimerTout->setText( tr( "Tout Supprimer" ) );
      playListSupprimerTout->setMenuText( tr( "&Tout Supprimer" ) );
      playListSupprimerTout->addTo( menu );
 
      /* mode de selection de la playlist : selection multiple*/
      playlist->setSelectionMode(QListView::Extended);

      morceauCourant=NULL;


      /////////////////////////////////////////
      //LECTEUR
      /////////////////////////////////////////
      QString chaineTMP;
      timer= new QTimer();
      positionSeconde=0;
      //visualisationActiver=false;
      LABEL_Volume->setText(chaineTMP.setNum(getVolume()));


      /* les connects: */
      connect( BTN_Play, SIGNAL( clicked(void) ), this, SLOT( play() ) );
      connect( BTN_Pause, SIGNAL( clicked(void) ), this, SLOT( pause() ) );
      connect( BTN_Stop, SIGNAL( clicked(void) ), this, SLOT( stop() ) );
      connect( BTN_Precedent, SIGNAL( clicked(void) ), this, SLOT( precedent() ) );
      connect( BTN_Suivant, SIGNAL( clicked() ), this, SLOT( suivant() ) );
      connect( BTN_VolumePlus, SIGNAL( clicked() ), this, SLOT( volumePlus() ) );
      connect( BTN_VolumeMoins, SIGNAL( clicked() ), this, SLOT( volumeMoins() ) );
      connect( BTN_Muet, SIGNAL( clicked() ), this, SLOT( volumeMuet() ) );
   //   connect( CHKBOX_Visualisation, SIGNAL( statusChanged(int) ), this, SLOT( visuOpenGL(int) ) );
      connect( (QObject*)POTENTIO_Balance, SIGNAL( valueChanged(int) ), this, SLOT( balance(int) ) );
      connect((QObject*)timer, SIGNAL(timeout()), this,SLOT(affichagePosition() ));
      connect((QObject*)SLIDER_Position, SIGNAL(sliderMoved(int)), this,SLOT(modifierPosition(int) ));


      connect( playlist, SIGNAL( doubleClicked( QListViewItem*, const QPoint &, int) ), this, SLOT(doubleClicMorceau(QListViewItem *) ) );

      connect( playlist, SIGNAL( rightButtonClicked ( QListViewItem*, const QPoint &, int) ), this, SLOT( popupClickDroit(QListViewItem*, const QPoint &, int) ) );
      connect( playListSupprimer, SIGNAL( activated() ), this, SLOT( supprimer() ) );
      connect( playListSupprimerSelect, SIGNAL( activated() ), this, SLOT( supprimerSelectionne() ) );
      connect( playListSupprimerTout, SIGNAL( activated() ), this, SLOT( clear() ) );
      /*initialisation d'une sequence de nombre aleatoire*/
      srandom(1);

      
    }

  ~QLecteur( )
    {
      delete(timer);
    }


  /**
   * teste si un morceau est deja present dans la
   * qlistview (playlist) 
   */
  bool existeQMorceau(QMorceau* m2){
    QListViewItem *item=playlist->firstChild();
    QMorceau* m=dynamic_cast<QMorceau*>(item);
    while(m){ /* tant qu'aucun morceau correspondant a ce chemin n'a ete trouve */
      if(*m2 == *m) return true;
      else m=dynamic_cast<QMorceau*>(m->itemBelow());
    }
    return false;
  }   


  /**
   * Test si tout les morceaux sont inexistant pour eviter une
   * boucle infini lors du mode repeat playlist
   * Des qu'il y a un morceau existant, retourne faux. A la fin retourne true
   */
   bool tousInexistant(){
      QListViewItem *item=playlist->firstChild();
      QMorceau *qmorceau;
      while(item){
        qmorceau=dynamic_cast<QMorceau*>(item);
        if(qmorceau==NULL) return true; //ne devrait jamais arriver!
	if(qmorceau->inexistant()==false) return false;
	item=item->itemBelow(); 
      }
      cout<<"pas de morceau ixistant"<<endl;
      return true; //tous les morceaux n'existe par reellement 
      
  }
  

  protected slots:
    virtual void languageChange(){}

  public slots:
    
    ////////////////////////////////////////////
    ////METHODES PLAYLIST
    ///////////////////////////////////////////
    /**
     * Slot permettant d'ajoute un QMorceau a la qlistview playlist 
     */
    virtual void ajoutMorceau(QListViewItem *item)
    {
      if(item){
	QMorceau*  qptrmorceau=dynamic_cast<QMorceau*>(item);
	if(!qptrmorceau) return; //si ce n'est pas un QMorceau*, on sort (ne devrait jamais arriver!)
	
	Morceau* m=qptrmorceau->getMorceau();
	if(m)
	  if(!existeQMorceau(qptrmorceau)){
	    QMorceau* itemAdd = new QMorceau( playlist,m,nbQMorceau);
	    nbQMorceau++;
	    if(!morceauCourant) morceauCourant=itemAdd;
	  }
      }
    }

  /**
   * Supprime toute la playliste
   */
  void clear(){
    stop();
    morceauCourant=NULL;
    playlist->clear();
    nbQMorceau=0;
    
  }

  /**
   * Slot permettant d'afficher un menu lors d'un clic droit
   */
  virtual void popupClickDroit(QListViewItem *item, const QPoint &point, int entier){
    if(item!=NULL){
      itemPopup=item;

      menu->popup ( point, 0 ) ;
    }
  }

  /**
   * Slot permettant de supprimer un morceau
   */
  virtual void supprimer(){
    if(itemPopup){
	if( morceauCourant==(QMorceau*)itemPopup){
	   stop();
	   morceauCourant=NULL;
	}
      playlist->takeItem(itemPopup);
      }
  }

    /**
   * Slot permettant de supprimer la selection de morceaux
   */
  virtual void supprimerSelectionne(){
    QListViewItem *item=playlist->firstChild();
    QMorceau *qmorceau;
    while(item){
      qmorceau=dynamic_cast<QMorceau*>(item);
      if(qmorceau && qmorceau->isSelected()){
	if(morceauCourant)
	  if(!(*qmorceau==*morceauCourant)){
	    stop();
	    morceauCourant=NULL;
	  }
	  playlist->takeItem(qmorceau);
	  item=playlist->firstChild();
	
      }
      item=item->itemBelow(); 
    }
  }
  
 
  ////////////////////////////////////////////
  ////METHODES LECTEUR
  ///////////////////////////////////////////
  virtual void play()
    {

      if(!morceauCourant) return; //il n'y a pas de morceau courant
      string chemin=morceauCourant->getMorceau()->getChemin();
	FILE* fd=fopen(chemin.c_str(),"r");
	if(fd==NULL) { /* morceau non present sur le disque*/
		morceauCourant->morceauInexistant();
		suivant(); /* passe a la suite */
		return; 

	}

	fclose(fd);	

      if(chemin != "")
	{
	  QString chaine=" / ",chaineTMP;
	  unsigned int minute=0,seconde,heure=0;

	  if(getLectureActive())
	    stop();
	
	  nbSecondeMorceau=getInfoMorceau(chemin,DUREE);   
	  SLIDER_Position->setMaxValue(nbSecondeMorceau);	
	  if(nbSecondeMorceau >=60)
	    minute=(nbSecondeMorceau/60);
	  if(minute>=60)
	    {
	      heure=minute/60;
	      minute-=heure*60;
	    }
	  seconde=(nbSecondeMorceau-minute*60);
	  
	  if(heure !=0)
	    chaine+=chaineTMP.setNum(heure)+" : ";
	  chaine+=chaineTMP.setNum(minute)+" : ";
	  chaine+=chaineTMP.setNum(seconde);  	
	  LABEL_AffDuree->setText(chaine);
	  LABEL_Artiste->setText(getTagInfo(chemin,ARTISTE));
	  LABEL_Titre->setText(getTagInfo(chemin,TITRE));
	
	  morceauCourant->selection(true);
	  if(morceauCourant)
	    {
	      timer->start(1000);//timer declencher toutes les secondes
	      Fmod::play(chemin);
	      //if( visualisationActiver==1)
	      Fmod::visualisation();
	    }
	}
    }
    
  virtual void pause()
    {
      if(getLectureActive() )
	{
	  if(getPauseActive())
	    timer->start(1000);
	  else
	    timer->stop();
	  Fmod::pause();
	}
    }
		
  virtual void stop()
    {
      if( getLectureActive() )
	{
	  timer->stop();
	  positionSeconde=0;
	  Fmod::stop();
	  affichagePosition();
	}
    }
       
  virtual void suivant()
    {
      if(morceauCourant)
	{
	  QMorceau *m=(QMorceau*)morceauCourant->itemBelow();
	  
	  if(repeatMorceau->isChecked ()){ /*mode repete un*/
	    if(morceauCourant->inexistant()) return; /*evite boucle infini*/
	    play();
	    return;
	  }

	  if(repeatAll->isChecked() && !m){ /*mode repete tout*/
	    if(tousInexistant()) return; /*sort, aucun morceau n'existe*/
	    morceauCourant->selection(false);
	    morceauCourant=dynamic_cast<QMorceau*>(playlist->firstChild ());
	    play();
	    return;
	  }
	

	  if( aleatoire->isChecked() ){  /* mode aleatoire*/
	    if(tousInexistant()) return; /*sort, aucun morceau n'existe*/
	    int nbMusique=0;
	    QListViewItem *l=playlist->firstChild();
	    cout<<"r"<<endl;
	    if(l==NULL) return;

	    /* compte le nombre de morceau present */
	    //for(QListViewItem *l=playlist->firstChild();l;l=l->itemBelow())
	    //  nbMusique++;
	    nbMusique=playlist->childCount();
	    
	    /* calcule un nombre aleatoire entre 0 et nbMusique */
	    int nbAlea=random()%nbMusique;
	    

	    /* prend ce ieme morceau */
	    l=playlist->firstChild();
	    for(int i=0;i<nbAlea;i++){
	      if(l==NULL) return; //ne devrait jamais arriver!
	      l=l->itemBelow();
	    }
	    
	    if(l){ /* joue ce ieme morceau */
	      morceauCourant->selection(false);
	      morceauCourant=(QMorceau*)l;
	      play();
	      return;
	    }
	  }

	  
	  if(m){
	    morceauCourant->selection(false);
	    morceauCourant=m;
	    play();
	  } 
	else {
	   morceauCourant->selection(false);
	   stop();
        }
	}
    }
  
  virtual void precedent()
    {
      if(morceauCourant){
	QMorceau *m=(QMorceau*)(morceauCourant->itemAbove());
	if(m){
	  morceauCourant->selection(false);
	  morceauCourant=m;
	  play();
	  
	}
      } 
    }
	      
  virtual void balance(int valeur)
    {	 
      setHpBalance(valeur);
    }

  
  virtual void affichagePosition()
    {	 
      QString chaine,chaineTMP;
      unsigned int minute=0,seconde,heure=0;
		
      SLIDER_Position->setValue(positionSeconde);	
      if(positionSeconde >=60)
	minute=(positionSeconde/60);
      if(minute>=60)
	heure=minute/60;
      seconde=(positionSeconde-minute*60);
      if(heure !=0)
	chaine=chaineTMP.setNum(heure)+" : ";
      chaine+=chaineTMP.setNum(minute)+" : ";
      chaine+=chaineTMP.setNum(seconde);
      LABEL_AffPosition->setText(chaine);
      if(positionSeconde >= nbSecondeMorceau)
      {
	stop();
	suivant();
    }     
      else
	positionSeconde++;
    }
	     
  virtual void modifierPosition(int position)
    {	 
      if(getLectureActive())
	{
	  setPositionIndicateur(position);
	  positionSeconde=position;
	}
	 
    } 

  virtual void volumePlus()
    {	 
      QString chaineTMP;
      augmenterVolume(10);   
      LABEL_Volume->setText(chaineTMP.setNum(getVolume()));
    }
		     
  virtual void volumeMoins()
    {	 
      QString chaineTMP;
      reduireVolume(10);
      LABEL_Volume->setText(chaineTMP.setNum(getVolume()));
	          
    }
			     
  virtual void volumeMuet()
    {	 
      QString chaineTMP;
      static bool etat=false;
      muet();
      etat=!etat;
      if(etat)
	LABEL_Volume->setText("Muet");
      else
	LABEL_Volume->setText(chaineTMP.setNum(getVolume()));
	          
    }
  
  virtual void doubleClicMorceau(QListViewItem *item){
    qWarning("ajout");
    if(item){
      QMorceau*  qmorceau=dynamic_cast<QMorceau*>(item);
      if(!qmorceau) return; //si ce n'est pas un QMorceau*, on sort (ne devrait jamais arriver!)
      if(morceauCourant) morceauCourant->selection(false);
      morceauCourant=qmorceau;
      play();
    }
    
    }
    /*
      virtual void visuOpenGL(int etat)
    {
	     visualisationActiver=etat;
  }  */
  

    
  
  
};




#endif
