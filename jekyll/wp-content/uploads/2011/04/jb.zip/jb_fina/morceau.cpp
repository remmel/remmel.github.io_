#include "morceau.hpp"
#include <id3/tag.h>
///#include <taglib/tag.h>

enum {TITRE,ARTISTE,ALBUM,ANNEE,STYLE,COMMENTAIRE,TAGTYPE};

Morceau::Morceau(const string &ch){
 chemin=ch;
}


string Morceau::getTitre(){
  return titre;
  //return chemin;
}

string Morceau::getNomAlbum(){
  return album;
}

string Morceau::getNomAuteur(){
  return artiste;
}

void Morceau::chargerTAG()
{

	titre="titre inconnu";
	artiste="artiste inconnu";
	album="album inconnu";


char buf[1024];
  ID3_Tag myTag;
  myTag.Link ( chemin.c_str() );

  ID3_Frame *myFrame;
  char buff[ 1024 ];



	  if ( (myFrame = myTag.Find ( ID3FID_TITLE )) )
    { 
      myFrame->Field ( ID3FN_TEXT ).Get ( buff, 1024 );
      titre=buff;
    }
  
  if ( (myFrame = myTag.Find ( ID3FID_ALBUM)) )
    { 
      myFrame->Field ( ID3FN_TEXT ).Get ( buff, 1024 );
      album=buff;
      
    }
  
  if ( (myFrame = myTag.Find ( ID3FID_LEADARTIST)) )
    { 
      myFrame->Field ( ID3FN_TEXT ).Get ( buff, 1024 );
      artiste=buff;
    }
  
  if ( (myFrame = myTag.Find ( ID3FID_TIME))) // ID3FID_SONGLEN ID3_V1_LEN ) )
    { 
      myFrame->Field ( ID3FN_TEXT ).Get ( buff, 1024 );
      cout << "duree: " << buff << endl;      
    }

  if ( (myFrame = myTag.Find ( ID3FID_YEAR )))
    { 
      myFrame->Field ( ID3FN_TEXT ).Get ( buff, 1024 );
      annee=buff;
      }


	/*TagLib_File *file;
  	TagLib_Tag *tag;
  	const TagLib_AudioProperties *properties;
	   
	file = taglib_file_new(chemin.c_str());
	
	tag = taglib_file_tag(file);
    properties = taglib_file_audioproperties(file);
	
	titre=taglib_tag_title(tag);
	artiste=taglib_tag_artist(tag);
	album=taglib_tag_album(tag);
	annee=taglib_tag_year(tag);
    commentaire=taglib_tag_comment(tag);
    genre=taglib_tag_genre(tag);*/





}
