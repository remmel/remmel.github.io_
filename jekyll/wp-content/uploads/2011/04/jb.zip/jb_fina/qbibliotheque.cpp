#include "qbibliotheque.h"


QBibliotheque::QBibliotheque( QWidget* parent, const char* name, WFlags fl) : WBibliotheque(parent,name,fl){
  lesMorceaux.ajouterM3U("jbconf.m3u");
  generer();
   
  /* parametre d'affiche de la bibliotheque */
  nonGroupe->setColumnWidthMode(0,QListView::Manual);
  nonGroupe->setColumnWidthMode(1,QListView::Manual);
  nonGroupe->setColumnWidthMode(2,QListView::Manual);
  nonGroupe->setColumnWidth (0, 100);
  nonGroupe->setColumnWidth (1, 100);
  nonGroupe->setColumnWidth (2, 100);
  nonGroupe->setSelectionMode(QListView::Extended);
  listView->setSelectionMode(QListView::Extended);

}

void QBibliotheque::clear(){
  lesMorceaux.nettoyer();
  listView->clear();
  nonGroupe->clear();
}

void QBibliotheque::generer(){
  Collection::generer(&lesMorceaux);
  lesMorceaux.sauvegarderM3U("jbconf.m3u");

  listView->clear();
  listView->clear();
  nonGroupe->clear();

  QListViewItem * item_artiste;
  QListViewItem * item_album;
  QListViewItem * item_morceau;
  Album *album;
  Auteur *auteur;
  Morceau *morceau;

  int nbAuteur=nombreDAuteur();
  int nbAlbum, nbMorceau;
    
  for(int iAuteur=0; iAuteur<nbAuteur;iAuteur++){
      
    item_artiste = new QListViewItem(listView);
    item_artiste->setText( 0, tr( ((*this)[iAuteur]->getNomAuteur()).c_str() )  );
    item_artiste->setOpen( TRUE );
      
      
    nbAlbum=(*this)[iAuteur]->nombreDAlbum();
      
    for(int iAlbum=0;iAlbum<nbAlbum;iAlbum++){
      item_album = new QListViewItem( item_artiste);
      auteur=((*this)[iAuteur]);
      album=(*auteur)[iAlbum];
      item_album->setText( 0, tr( (  album->getNomAlbum()   ).c_str() ) );
      item_album->setText( 0, tr( ((*((*this)[iAuteur]))[iAlbum]->getNomAlbum()).c_str() ) );
      item_album->setOpen( TRUE );

	
      nbMorceau=album->nombreDeMorceau();
      
      for(int iMorceau=0; iMorceau<nbMorceau;iMorceau++){
	morceau=(*album)[iMorceau];
	item_morceau = new QMorceau( item_album, morceau);
      }
    }

  }
  QListViewItem* itemAdd;
  int nbMorceaux = lesMorceaux.nombreDeMorceau();
  for(int i=0;i<nbMorceaux ; i++){
    itemAdd = new QMorceau( nonGroupe,lesMorceaux[i]);
  }
	

}


void QBibliotheque::genererBibliotheque(){
  QFileDialog* fd = new QFileDialog( this, "Choississez le dossier a partir duquel vous voulez scannez vos musiques", TRUE );
  fd->setMode( QFileDialog::Directory );
  QString fileName;
  if ( fd->exec() == QDialog::Accepted ){
    fileName = fd->selectedFile();
    lesMorceaux.genererListe(fd->selectedFile());
    generer();
  }
}
