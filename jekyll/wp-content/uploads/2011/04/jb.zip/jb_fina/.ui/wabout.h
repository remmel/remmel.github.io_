/****************************************************************************
** Form interface generated from reading ui file 'wabout.ui'
**
** Created: mar jan 23 17:49:08 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef ABOUT_H
#define ABOUT_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;

class About : public QDialog
{
    Q_OBJECT

public:
    About( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~About();

    QLabel* textLabel1;
    QLabel* pixmapLabel2;

protected:
    QGridLayout* AboutLayout;
    QSpacerItem* spacer4;
    QSpacerItem* spacer12;
    QSpacerItem* spacer3;

protected slots:
    virtual void languageChange();

};

#endif // ABOUT_H
