/****************************************************************************
** Form implementation generated from reading ui file 'wlecteur.ui'
**
** Created: mar jan 23 18:04:47 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "wlecteur.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qheader.h>
#include <qlistview.h>
#include <qslider.h>
#include <qpushbutton.h>
#include <qdial.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a WLecteur as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
WLecteur::WLecteur( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "WLecteur" );
    setMinimumSize( QSize( 600, 600 ) );
    setBaseSize( QSize( 600, 600 ) );

    LABEL_Artiste = new QLabel( this, "LABEL_Artiste" );
    LABEL_Artiste->setGeometry( QRect( 20, 90, 220, 20 ) );

    LABEL_Titre = new QLabel( this, "LABEL_Titre" );
    LABEL_Titre->setGeometry( QRect( 30, 60, 210, 20 ) );

    LABEL_AffDuree = new QLabel( this, "LABEL_AffDuree" );
    LABEL_AffDuree->setGeometry( QRect( 90, 30, 80, 20 ) );

    LABEL_AffPosition = new QLabel( this, "LABEL_AffPosition" );
    LABEL_AffPosition->setGeometry( QRect( 40, 30, 50, 20 ) );

    playlist = new QListView( this, "playlist" );
    playlist->addColumn( trUtf8( "\x4e\xc2\xb0" ) );
    playlist->addColumn( tr( "Titre" ) );
    playlist->addColumn( tr( "Artiste" ) );
    playlist->addColumn( tr( "Album" ) );
    playlist->addColumn( tr( "Duree" ) );
    playlist->setEnabled( TRUE );
    playlist->setGeometry( QRect( 10, 240, 570, 340 ) );
    playlist->setFrameShape( QListView::StyledPanel );
    playlist->setFrameShadow( QListView::Sunken );
    playlist->setMargin( 0 );
    playlist->setResizePolicy( QScrollView::Manual );
    playlist->setAllColumnsShowFocus( FALSE );
    playlist->setResizeMode( QListView::NoColumn );
    playlist->setDefaultRenameAction( QListView::Reject );

    LABEL_Volume = new QLabel( this, "LABEL_Volume" );
    LABEL_Volume->setGeometry( QRect( 270, 100, 70, 20 ) );

    SLIDER_Position = new QSlider( this, "SLIDER_Position" );
    SLIDER_Position->setGeometry( QRect( 10, 130, 350, 24 ) );
    SLIDER_Position->setOrientation( QSlider::Horizontal );

    BTN_Precedent = new QPushButton( this, "BTN_Precedent" );
    BTN_Precedent->setGeometry( QRect( 10, 160, 70, 70 ) );
    BTN_Precedent->setPixmap( QPixmap::fromMimeSource( "precedent.png" ) );
    BTN_Precedent->setFlat( TRUE );

    BTN_Play = new QPushButton( this, "BTN_Play" );
    BTN_Play->setGeometry( QRect( 80, 160, 70, 70 ) );
    BTN_Play->setPixmap( QPixmap::fromMimeSource( "play.png" ) );
    BTN_Play->setFlat( TRUE );

    BTN_Pause = new QPushButton( this, "BTN_Pause" );
    BTN_Pause->setGeometry( QRect( 150, 160, 70, 70 ) );
    BTN_Pause->setPixmap( QPixmap::fromMimeSource( "pause.png" ) );
    BTN_Pause->setFlat( TRUE );

    BTN_Stop = new QPushButton( this, "BTN_Stop" );
    BTN_Stop->setGeometry( QRect( 220, 160, 70, 70 ) );
    BTN_Stop->setPixmap( QPixmap::fromMimeSource( "stop.png" ) );
    BTN_Stop->setFlat( TRUE );

    BTN_Suivant = new QPushButton( this, "BTN_Suivant" );
    BTN_Suivant->setGeometry( QRect( 290, 160, 72, 70 ) );
    BTN_Suivant->setPixmap( QPixmap::fromMimeSource( "suivant.png" ) );
    BTN_Suivant->setFlat( TRUE );

    IMG_Son = new QLabel( this, "IMG_Son" );
    IMG_Son->setGeometry( QRect( 280, 20, 64, 64 ) );
    IMG_Son->setPixmap( QPixmap::fromMimeSource( "enceinte.png" ) );
    IMG_Son->setScaledContents( TRUE );

    POTENTIO_Balance = new QDial( this, "POTENTIO_Balance" );
    POTENTIO_Balance->setGeometry( QRect( 400, 30, 50, 50 ) );
    POTENTIO_Balance->setCursor( QCursor( 2 ) );
    POTENTIO_Balance->setMinValue( -100 );
    POTENTIO_Balance->setMaxValue( 100 );

    BTN_VolumeMoins = new QPushButton( this, "BTN_VolumeMoins" );
    BTN_VolumeMoins->setGeometry( QRect( 350, 50, 40, 30 ) );
    BTN_VolumeMoins->setPixmap( QPixmap::fromMimeSource( "VolumeMoins.png" ) );
    BTN_VolumeMoins->setFlat( TRUE );

    BTN_VolumePlus = new QPushButton( this, "BTN_VolumePlus" );
    BTN_VolumePlus->setGeometry( QRect( 350, 20, 40, 30 ) );
    BTN_VolumePlus->setPixmap( QPixmap::fromMimeSource( "VolumePlus.png" ) );
    BTN_VolumePlus->setFlat( TRUE );

    BTN_Muet = new QPushButton( this, "BTN_Muet" );
    BTN_Muet->setGeometry( QRect( 350, 80, 40, 23 ) );
    BTN_Muet->setFlat( TRUE );

    aleatoire = new QCheckBox( this, "aleatoire" );
    aleatoire->setGeometry( QRect( 371, 120, 127, 19 ) );

    repeatMorceau = new QCheckBox( this, "repeatMorceau" );
    repeatMorceau->setGeometry( QRect( 371, 154, 127, 19 ) );

    repeatAll = new QCheckBox( this, "repeatAll" );
    repeatAll->setGeometry( QRect( 371, 188, 127, 19 ) );
    languageChange();
    resize( QSize(600, 600).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
WLecteur::~WLecteur()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void WLecteur::languageChange()
{
    setCaption( tr( "Form1" ) );
    LABEL_Artiste->setText( QString::null );
    LABEL_Titre->setText( QString::null );
    LABEL_AffDuree->setText( QString::null );
    LABEL_AffPosition->setText( QString::null );
    playlist->header()->setLabel( 0, trUtf8( "\x4e\xc2\xb0" ) );
    playlist->header()->setLabel( 1, tr( "Titre" ) );
    playlist->header()->setLabel( 2, tr( "Artiste" ) );
    playlist->header()->setLabel( 3, tr( "Album" ) );
    playlist->header()->setLabel( 4, tr( "Duree" ) );
    LABEL_Volume->setText( QString::null );
    BTN_Precedent->setText( QString::null );
    BTN_Play->setText( QString::null );
    BTN_Pause->setText( QString::null );
    BTN_Stop->setText( QString::null );
    BTN_Suivant->setText( QString::null );
    BTN_VolumeMoins->setText( QString::null );
    BTN_VolumePlus->setText( QString::null );
    BTN_Muet->setText( tr( "Mute" ) );
    aleatoire->setText( tr( "aleatoire" ) );
    repeatMorceau->setText( tr( "repete morceau" ) );
    repeatAll->setText( tr( "repete playlist" ) );
}

void WLecteur::playlist_onViewport()
{
    qWarning( "WLecteur::playlist_onViewport(): Not implemented yet" );
}

