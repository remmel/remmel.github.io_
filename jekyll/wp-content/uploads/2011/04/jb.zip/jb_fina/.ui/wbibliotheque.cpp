/****************************************************************************
** Form implementation generated from reading ui file 'wbibliotheque.ui'
**
** Created: mar jan 23 17:49:15 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "wbibliotheque.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qtabwidget.h>
#include <qheader.h>
#include <qlistview.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a WBibliotheque as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
WBibliotheque::WBibliotheque( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "WBibliotheque" );
    WBibliothequeLayout = new QGridLayout( this, 1, 1, 11, 6, "WBibliothequeLayout"); 

    classeur = new QTabWidget( this, "classeur" );

    tab = new QWidget( classeur, "tab" );
    tabLayout = new QGridLayout( tab, 1, 1, 11, 6, "tabLayout"); 

    listView = new QListView( tab, "listView" );
    listView->addColumn( tr( "Artiste / Album" ) );

    tabLayout->addWidget( listView, 0, 0 );
    classeur->insertTab( tab, QString::fromLatin1("") );

    tab_2 = new QWidget( classeur, "tab_2" );
    tabLayout_2 = new QGridLayout( tab_2, 1, 1, 11, 6, "tabLayout_2"); 

    nonGroupe = new QListView( tab_2, "nonGroupe" );
    nonGroupe->addColumn( tr( "Titre" ) );
    nonGroupe->header()->setResizeEnabled( FALSE, nonGroupe->header()->count() - 1 );
    nonGroupe->addColumn( tr( "Artiste" ) );
    nonGroupe->addColumn( tr( "Album" ) );

    tabLayout_2->addWidget( nonGroupe, 0, 0 );
    classeur->insertTab( tab_2, QString::fromLatin1("") );

    WBibliothequeLayout->addWidget( classeur, 0, 0 );

    buttonAjout = new QPushButton( this, "buttonAjout" );

    WBibliothequeLayout->addWidget( buttonAjout, 1, 0 );
    languageChange();
    resize( QSize(405, 430).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
WBibliotheque::~WBibliotheque()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void WBibliotheque::languageChange()
{
    setCaption( tr( "Form2" ) );
    listView->header()->setLabel( 0, tr( "Artiste / Album" ) );
    classeur->changeTab( tab, tr( "Artiste / Album" ) );
    nonGroupe->header()->setLabel( 0, tr( "Titre" ) );
    nonGroupe->header()->setLabel( 1, tr( "Artiste" ) );
    nonGroupe->header()->setLabel( 2, tr( "Album" ) );
    classeur->changeTab( tab_2, trUtf8( "\x4e\x6f\x6e\x20\x67\x72\x6f\x75\x70\xc3\xa9" ) );
    buttonAjout->setText( tr( "--->" ) );
}

