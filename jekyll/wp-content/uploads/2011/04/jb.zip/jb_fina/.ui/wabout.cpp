/****************************************************************************
** Form implementation generated from reading ui file 'wabout.ui'
**
** Created: mar jan 23 17:49:19 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "wabout.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a About as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
About::About( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "About" );
    AboutLayout = new QGridLayout( this, 1, 1, 11, 6, "AboutLayout"); 
    spacer4 = new QSpacerItem( 37, 90, QSizePolicy::Expanding, QSizePolicy::Minimum );
    AboutLayout->addItem( spacer4, 0, 0 );

    textLabel1 = new QLabel( this, "textLabel1" );
    textLabel1->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter ) );

    AboutLayout->addMultiCellWidget( textLabel1, 1, 1, 0, 2 );
    spacer12 = new QSpacerItem( 20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding );
    AboutLayout->addItem( spacer12, 2, 1 );
    spacer3 = new QSpacerItem( 39, 81, QSizePolicy::Expanding, QSizePolicy::Minimum );
    AboutLayout->addItem( spacer3, 0, 2 );

    pixmapLabel2 = new QLabel( this, "pixmapLabel2" );
    pixmapLabel2->setPixmap( QPixmap::fromMimeSource( "logo.png" ) );
    pixmapLabel2->setScaledContents( TRUE );

    AboutLayout->addWidget( pixmapLabel2, 0, 1 );
    languageChange();
    resize( QSize(210, 198).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
About::~About()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void About::languageChange()
{
    setCaption( tr( "A Propos" ) );
    textLabel1->setText( trUtf8( "\x4a\x75\x6b\x65\x42\x6f\x78\x20\x66\x6f\x6e\x63\x74\x69\x6f\x6e\x6e\x65\x6c\x2c\xa"
    "\x72\xc3\xa9\x61\x6c\x69\x73\xc3\xa9\x20\x70\x61\x72\x20\xa\x20\x20\x52\xc3\xa9"
    "\x6d\x79\x20\x4d\x65\x6c\x6c\x65\x74\x20\x65\x74\xa\x20\x20\x44\x61\x6d\x69\x65"
    "\x6e\x20\x4e\x65\x73\x74\x65\x6c\x68\x75\x74" ) );
}

