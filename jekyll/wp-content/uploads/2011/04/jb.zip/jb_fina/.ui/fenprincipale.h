/****************************************************************************
** Form interface generated from reading ui file 'fenprincipale.ui'
**
** Created: mar jan 23 18:04:42 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FENPRINCIPALE_H
#define FENPRINCIPALE_H

#include <qvariant.h>
#include <qpixmap.h>
#include <qmainwindow.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;
class QBibliotheque;
class QLecteur;
class QSplitter;

class FenPrincipale : public QMainWindow
{
    Q_OBJECT

public:
    FenPrincipale( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~FenPrincipale();

    QSplitter* splitter1;
    QBibliotheque* bibliotheque;
    QLecteur* lecteur;
    QMenuBar *about;
    QPopupMenu *fileMenu;
    QPopupMenu *Collection;
    QPopupMenu *A_Propos;
    QAction* fileNewAction;
    QAction* fileOpenAction;
    QAction* fileSaveAction;
    QAction* fileSaveAsAction;
    QAction* filePrintAction;
    QAction* exit;
    QAction* filenew_itemAction;
    QAction* genererCollection;
    QAction* fileajout_direct_dans_playlistAction;
    QAction* ajoutDirect;
    QAction* genererCollection_;
    QAction* Nettoyer;
    QAction* aproposOK;

public slots:
    virtual void fileNew();
    virtual void fileOpen();
    virtual void fileSave();
    virtual void fileSaveAs();
    virtual void filePrint();
    virtual void fileExit();

protected:
    QGridLayout* FenPrincipaleLayout;

protected slots:
    virtual void languageChange();

private:
    QPixmap image0;

};

#endif // FENPRINCIPALE_H
