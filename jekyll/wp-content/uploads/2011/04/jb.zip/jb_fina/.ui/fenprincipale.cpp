/****************************************************************************
** Form implementation generated from reading ui file 'fenprincipale.ui'
**
** Created: mar jan 23 18:04:48 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "fenprincipale.h"

#include <qvariant.h>
#include <qsplitter.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>

#include "qbibliotheque.h"
#include "qlecteur.h"
/*
 *  Constructs a FenPrincipale as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 */
FenPrincipale::FenPrincipale( QWidget* parent, const char* name, WFlags fl )
    : QMainWindow( parent, name, fl )
{
    (void)statusBar();
    if ( !name )
	setName( "FenPrincipale" );
    setCentralWidget( new QWidget( this, "qt_central_widget" ) );
    FenPrincipaleLayout = new QGridLayout( centralWidget(), 1, 1, 11, 6, "FenPrincipaleLayout"); 

    splitter1 = new QSplitter( centralWidget(), "splitter1" );
    splitter1->setOrientation( QSplitter::Horizontal );

    bibliotheque = new QBibliotheque( splitter1, "bibliotheque" );

    lecteur = new QLecteur( splitter1, "lecteur" );
    lecteur->setMinimumSize( QSize( 600, 600 ) );

    FenPrincipaleLayout->addWidget( splitter1, 0, 0 );

    // actions
    fileNewAction = new QAction( this, "fileNewAction" );
    fileNewAction->setIconSet( QIconSet( QPixmap::fromMimeSource( "filenew" ) ) );
    fileOpenAction = new QAction( this, "fileOpenAction" );
    fileOpenAction->setIconSet( QIconSet( QPixmap::fromMimeSource( "fileopen" ) ) );
    fileSaveAction = new QAction( this, "fileSaveAction" );
    fileSaveAction->setIconSet( QIconSet( QPixmap::fromMimeSource( "filesave" ) ) );
    fileSaveAsAction = new QAction( this, "fileSaveAsAction" );
    filePrintAction = new QAction( this, "filePrintAction" );
    filePrintAction->setIconSet( QIconSet( QPixmap::fromMimeSource( "print" ) ) );
    exit = new QAction( this, "exit" );
    filenew_itemAction = new QAction( this, "filenew_itemAction" );
    genererCollection = new QAction( this, "genererCollection" );
    fileajout_direct_dans_playlistAction = new QAction( this, "fileajout_direct_dans_playlistAction" );
    ajoutDirect = new QAction( this, "ajoutDirect" );
    genererCollection_ = new QAction( this, "genererCollection_" );
    Nettoyer = new QAction( this, "Nettoyer" );
    aproposOK = new QAction( this, "aproposOK" );


    // toolbars


    // menubar
    about = new QMenuBar( this, "about" );


    fileMenu = new QPopupMenu( this );
    exit->addTo( fileMenu );
    about->insertItem( QString(""), fileMenu, 1 );

    Collection = new QPopupMenu( this );
    genererCollection_->addTo( Collection );
    Nettoyer->addTo( Collection );
    about->insertItem( QString(""), Collection, 2 );

    A_Propos = new QPopupMenu( this );
    aproposOK->addTo( A_Propos );
    about->insertItem( QString(""), A_Propos, 3 );

    languageChange();
    resize( QSize(629, 667).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( fileNewAction, SIGNAL( activated() ), this, SLOT( fileNew() ) );
    connect( fileOpenAction, SIGNAL( activated() ), this, SLOT( fileOpen() ) );
    connect( fileSaveAction, SIGNAL( activated() ), this, SLOT( fileSave() ) );
    connect( fileSaveAsAction, SIGNAL( activated() ), this, SLOT( fileSaveAs() ) );
    connect( filePrintAction, SIGNAL( activated() ), this, SLOT( filePrint() ) );
    connect( genererCollection_, SIGNAL( activated() ), bibliotheque, SLOT( genererBibliotheque() ) );
    connect( exit, SIGNAL( activated() ), this, SLOT( close() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
FenPrincipale::~FenPrincipale()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void FenPrincipale::languageChange()
{
    setCaption( tr( "JB le gucboks" ) );
    fileNewAction->setText( tr( "New" ) );
    fileNewAction->setMenuText( tr( "&New" ) );
    fileNewAction->setAccel( tr( "Ctrl+N" ) );
    fileOpenAction->setText( tr( "Open" ) );
    fileOpenAction->setMenuText( tr( "&Open..." ) );
    fileOpenAction->setAccel( tr( "Ctrl+O" ) );
    fileSaveAction->setText( tr( "Save" ) );
    fileSaveAction->setMenuText( tr( "&Save" ) );
    fileSaveAction->setAccel( tr( "Ctrl+S" ) );
    fileSaveAsAction->setText( tr( "Save As" ) );
    fileSaveAsAction->setMenuText( tr( "Save &As..." ) );
    fileSaveAsAction->setAccel( QString::null );
    filePrintAction->setText( tr( "Print" ) );
    filePrintAction->setMenuText( tr( "&Print..." ) );
    filePrintAction->setAccel( tr( "Ctrl+P" ) );
    exit->setText( tr( "Exit" ) );
    exit->setMenuText( tr( "E&xit" ) );
    exit->setAccel( QString::null );
    filenew_itemAction->setText( tr( "new item" ) );
    filenew_itemAction->setMenuText( tr( "new item" ) );
    genererCollection->setText( tr( "Construire Collection" ) );
    genererCollection->setMenuText( tr( "Construire Collection" ) );
    fileajout_direct_dans_playlistAction->setText( tr( "ajout direct dans playlist" ) );
    fileajout_direct_dans_playlistAction->setMenuText( tr( "ajout direct dans playlist" ) );
    ajoutDirect->setText( tr( "Ajouter Des Medias" ) );
    ajoutDirect->setMenuText( tr( "Ajouter Des Medias" ) );
    genererCollection_->setText( tr( "Generer" ) );
    genererCollection_->setMenuText( tr( "Generer" ) );
    Nettoyer->setText( tr( "Nettoyer" ) );
    Nettoyer->setMenuText( tr( "Nettoyer" ) );
    aproposOK->setText( tr( "OK" ) );
    aproposOK->setMenuText( tr( "OK" ) );
    if (about->findItem(1))
        about->findItem(1)->setText( tr( "&File" ) );
    if (about->findItem(2))
        about->findItem(2)->setText( tr( "Collection" ) );
    if (about->findItem(3))
        about->findItem(3)->setText( tr( "A Propos" ) );
}

void FenPrincipale::fileNew()
{
    qWarning( "FenPrincipale::fileNew(): Not implemented yet" );
}

void FenPrincipale::fileOpen()
{
    qWarning( "FenPrincipale::fileOpen(): Not implemented yet" );
}

void FenPrincipale::fileSave()
{
    qWarning( "FenPrincipale::fileSave(): Not implemented yet" );
}

void FenPrincipale::fileSaveAs()
{
    qWarning( "FenPrincipale::fileSaveAs(): Not implemented yet" );
}

void FenPrincipale::filePrint()
{
    qWarning( "FenPrincipale::filePrint(): Not implemented yet" );
}

void FenPrincipale::fileExit()
{
    qWarning( "FenPrincipale::fileExit(): Not implemented yet" );
}

