/****************************************************************************
** Form interface generated from reading ui file 'wlecteur.ui'
**
** Created: mar jan 23 18:04:42 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef WLECTEUR_H
#define WLECTEUR_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QListView;
class QListViewItem;
class QSlider;
class QPushButton;
class QDial;
class QCheckBox;

class WLecteur : public QWidget
{
    Q_OBJECT

public:
    WLecteur( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~WLecteur();

    QLabel* LABEL_Artiste;
    QLabel* LABEL_Titre;
    QLabel* LABEL_AffDuree;
    QLabel* LABEL_AffPosition;
    QListView* playlist;
    QLabel* LABEL_Volume;
    QSlider* SLIDER_Position;
    QPushButton* BTN_Precedent;
    QPushButton* BTN_Play;
    QPushButton* BTN_Pause;
    QPushButton* BTN_Stop;
    QPushButton* BTN_Suivant;
    QLabel* IMG_Son;
    QDial* POTENTIO_Balance;
    QPushButton* BTN_VolumeMoins;
    QPushButton* BTN_VolumePlus;
    QPushButton* BTN_Muet;
    QCheckBox* aleatoire;
    QCheckBox* repeatMorceau;
    QCheckBox* repeatAll;

public slots:
    virtual void playlist_onViewport();

protected:

protected slots:
    virtual void languageChange();

};

#endif // WLECTEUR_H
