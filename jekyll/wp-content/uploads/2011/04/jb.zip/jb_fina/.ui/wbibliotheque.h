/****************************************************************************
** Form interface generated from reading ui file 'wbibliotheque.ui'
**
** Created: mar jan 23 17:49:07 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef WBIBLIOTHEQUE_H
#define WBIBLIOTHEQUE_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QTabWidget;
class QListView;
class QListViewItem;
class QPushButton;

class WBibliotheque : public QWidget
{
    Q_OBJECT

public:
    WBibliotheque( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~WBibliotheque();

    QTabWidget* classeur;
    QWidget* tab;
    QListView* listView;
    QWidget* tab_2;
    QListView* nonGroupe;
    QPushButton* buttonAjout;

protected:
    QGridLayout* WBibliothequeLayout;
    QGridLayout* tabLayout;
    QGridLayout* tabLayout_2;

protected slots:
    virtual void languageChange();

};

#endif // WBIBLIOTHEQUE_H
